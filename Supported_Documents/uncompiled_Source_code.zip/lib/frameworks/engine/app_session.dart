
// ignore: camel_case_types
import 'dart:ui';

import 'package:flutter/foundation.dart';

import '../maasss_helper.dart';


enum Internet_Connection {
  OFFLINE,
  ONLINE
}

/*enum UserType {
  Expert(2),
  Requester(3);
}*/


class App_Session
{

  /*App_Session._privateConstructor();
  static App_Session _instance = App_Session._privateConstructor();
  App_Session._internal();
  static App_Session getInstance()
  {
    if (_instance == null)
    {
      _instance = App_Session._internal();
    }
    return _instance;
  }*/



  static String myAppVersion = "1.0.0";
  static String myCity = "";
  static String myDeviceUniqueId = "12345678yut78";
  static String userName = "";
  static String userId = '0';
  static String email = "";
  static String firstName = "";
  static String lastName = "";
  static String userTypes = '';
  static String gender = "";
  static String address = "";
  static String myIpAddress = "";
  static String myDeviceType = "2";
  static String myCountry = "";
  static String myDeviceToken = "";
  static String myDeviceName = "Samsung";
  static int selectedTabIndex = 0;
  static int selectedZoomIndex = 7;
  static String surpriseDateTime = '';
 // static UserType userType = UserType.Requester;
  static String adminId = "4";
  static int numberOfDogs = 0;

  static var expertTabArray = [];
  static var requesterTabArray = [];
  static var loadedTabArray = [];

  static Color appThemeColor = const Color(0xFF966F00);

  static String notificationTitle = 'SURPRISE';
  static String notificationBody = 'Win and get magical hints.';

  static Map<String, dynamic> myKeychainData = Map<String, dynamic>();


}
