
import 'package:dogcare/frameworks/managers/hardware_manager.dart';
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';

import '../../main.dart';
import '../maasss_helper.dart';
import '../managers/api_manager.dart';
import '../managers/notification_manager.dart';
import '../managers/progress_manager.dart';
import '../managers/socket_manager.dart';
import '../managers/sqldb_manager.dart';
import '../widget_helper.dart';
import 'app_profile.dart';
import 'app_session.dart';

/*
 1. Copy frameworks in lib folder

 2. Change all packege from all class (change app name only)

 3. Remove all code from App Session class

 4. Remove error code from App_Engine class

 5. Copy 'shared_preferences: ^2.0.5' in dependencies: in pubspec.yaml file // Then run pubget command

 6. Copy 'http: any' in dependencies: in pubspec.yaml file // Then run pubget command

 7. Remove error code from API_Manager class

 8. Copy this code 'static APP_Engine appEngine = new APP_Engine();' in MyApp class

 9. add this line in pubspec.yaml 'audioplayers: ^0.19.1'

*/

// ignore: camel_case_types
class Interface_API_Response_From_Engine_To_UI
{
  // ignore: non_constant_identifier_names
  void api_Response_To_UI
      (
      Map<String, dynamic> responseDictionary, String apiName)
  {

  }

  void api_Response_Error(String apiName, var response)
  {

  }
}


// ignore: camel_case_types
class APP_Engine implements Interface_Api_Response
{

  /// ignore: non_constant_identifier_names
  late API_Manager api_manager;

  /// ignore: non_constant_identifier_names
  Interface_API_Response_From_Engine_To_UI
  interface_API_Response_From_Engine_To_UI =
  Interface_API_Response_From_Engine_To_UI();

  /// ignore: non_constant_identifier_names
  late Socket_Manager socket_manager;

  /// ignore: non_constant_identifier_names
 // late AdManager adManager;

  /// Network_Manager Setup
  // late NetworkManager networkManager;

  /// Inapp Purchase
  //late InAppPurchaseManager inAppPurchaseManager;

  /// DataBase
  late SQLDBManager sqlDBManager;

  /// Progress Bar
  late ProgressManager progressManager;

  /// Hardware setup
  late HardwareManager hardwareManager;

  /// Notification Setup
  late NotificationManager notificationManager;

  late MaasssWidgetHelper maasssWidgetHelper;



  APP_Engine()
  {
    api_manager = API_Manager(); // API Manager
    api_manager.interface_api_response = this;

    socket_manager = Socket_Manager(); // Socket

    AppProfile.getDocumentDirectoryPath();

    //sqlDBManager = SQLDBManager();

    progressManager = ProgressManager();

    hardwareManager = HardwareManager();

    notificationManager = NotificationManager(); // local notification setup

    maasssWidgetHelper = MaasssWidgetHelper();

    tabSettings();

  }

  ///////////////////////////////////////
  //                                   //
  // Project based api request  method //
  //                                   //
  ///////////////////////////////////////
  void api_Request(Map<String, dynamic> requestData, String appendURL, String apiName)
  {
    api_manager.api_Request_Method(requestData, appendURL, apiName);
  }

  void apiRequestForFileUpload(String filepath, Map<String, dynamic> requestData, String apiName, List<int> fileBytes)
  {
    api_manager.apiRequestForFileUpload(filepath, requestData, apiName, fileBytes);
  }


  ///////////////////////////////////////
  //                                   //
  // Project based api response method //
  //                                   //
  ///////////////////////////////////////
  @override
  void web_Service_Response(
      Map<String, dynamic> responseDictionary, String apiName)
  {
    if (apiName == 'Country_Request')
    {
      App_Session.myIpAddress = responseDictionary['ip'];
      App_Session.myCountry = responseDictionary['country'];
    }
    else
    {
      interface_API_Response_From_Engine_To_UI.api_Response_To_UI(responseDictionary, apiName);
    }
  }

  @override
  void web_Service_Response_Error(String apiName, response)
  {
    // TODO: implement web_Service_Response_Error
    interface_API_Response_From_Engine_To_UI.api_Response_Error(
        apiName, response);
  }

  tabSettings()
  {
    Map<String,dynamic> tab1= Map<String,dynamic>();
    tab1['tabname'] ='Request';
    App_Session.expertTabArray.add(tab1);

    Map<String,dynamic> tab3= Map<String,dynamic>();
    tab3['tabname'] ='Settings';
    App_Session.expertTabArray.add(tab3);


    Map<String,dynamic> tab11= Map<String,dynamic>();
    tab11['tabname'] ='DogList';
    App_Session.requesterTabArray.add(tab11);

    Map<String,dynamic> tab22= Map<String,dynamic>();
    tab22['tabname'] ='Request';
    App_Session.requesterTabArray.add(tab22);

    Map<String,dynamic> tab33= Map<String,dynamic>();
    tab33['tabname'] ='Settings';
    App_Session.requesterTabArray.add(tab33);

  }

  String getSinglePetImage(String petImages) {
    String singleImage = '';
    final splitImageArray = petImages.split(',');
    singleImage = splitImageArray[0];
    return singleImage;
  }

  String dateDifference(String dob)
  {
    String age = '';

    List dobDateIndex = dob.split('-');
    int dobYear = int.parse(dobDateIndex[0].toString());
    int dobMonth = int.parse(dobDateIndex[1].toString());
    int dobDay = int.parse(dobDateIndex[2].toString());

    String currentDateString = DateFormat('yyyy-MM-dd').format(DateTime.now());
    List currentDateIndex = currentDateString.split('-');

    int currentYear = int.parse(currentDateIndex[0].toString());
    int currentMonth = int.parse(currentDateIndex[1].toString());
    int currentDay = int.parse(currentDateIndex[2].toString());

    DateTime dobDate = DateTime(dobYear, dobMonth, dobDay);
    DateTime currentDate = DateTime(currentYear, currentMonth, currentDay);
    int totalDays = currentDate.difference(dobDate).inDays;
    int years = totalDays ~/ 365;
    double monthInYear = 0;
    if(years>0){

    }
    int months = (totalDays-years*365) ~/ 30;
    if(months>0){
      monthInYear = months/12;
    }
    int days = totalDays-years*365-months*30;
    if(days>0 && years == 0 && months==0){
      return days.toString() + ' Days ';
    }
    if (kDebugMode) {
      print("$years $months $days $totalDays");
    }
    double netAge = years+monthInYear;
    netAge =  double.parse((netAge). toStringAsFixed(2));

    return netAge.toString() + ' Year ';

  }

  String getDistanceBetween(String vetLatitude, String vetLongitude)
  {
    double distanceKG = Geolocator.distanceBetween(
        double.parse(MyApp.appEngine.hardwareManager.myCurrentLatitude),
        double.parse(MyApp.appEngine.hardwareManager.myCurrentLongitude),
        double.parse(vetLatitude),
        double.parse(vetLongitude));

    distanceKG = distanceKG / 1000;
    String distance = distanceKG.toStringAsFixed(2);
    return distance + ' KM';
  }

}
