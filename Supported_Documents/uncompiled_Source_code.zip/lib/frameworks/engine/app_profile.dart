
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:device_info/device_info.dart';
import 'package:dogcare/frameworks/engine/app_session.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:package_info/package_info.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_archive/flutter_archive.dart';

import '../maasss_helper.dart';

class AppProfile
{

  static String appProfileFolderName = 'event';
  static String approverEventFolderName = 'approver';
  static String imageDocumentFolderPath = '';

  static late String internalMemoryDataInString = '';
  static const storage = FlutterSecureStorage();
  static final DeviceInfoPlugin deviceInfoPlugin =  DeviceInfoPlugin();

  /// Write data in keychain
  static Future<void> saveDataINKeychain() async
  {
    String myKey = 'MySecureKey';
    String dataInJsonString = jsonEncode(App_Session.myKeychainData);
    await storage.write(key: myKey, value: dataInJsonString);
  }

  /// Read data from keychain
  static Future<void> readDataFromKeychain() async
  {
    App_Session.myKeychainData.clear();
    String myKey = 'MySecureKey';
    String? jsonDataString = await storage.read(key: myKey);
    if(jsonDataString.toString().length>10){
      var keyChainReturnData = jsonDecode(jsonDataString!);
      App_Session.myKeychainData.addAll(keyChainReturnData);
    }
  }


  /// Delete data from keychain
  static void deleteKeyChainData() async
  {
    String myKey = 'MySecureKey';
    await storage.delete(key: myKey);
  }

  /// Get Device ID
  static Future<void> getDeviceInfo() async
  {
    String deviceName;
    String deviceVersion;
    String identifier = "";
    String appName;
    String packageName;
    String version = "";
    String buildNumber;

    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    await readDataFromKeychain();

    try
    {
      if (Platform.isAndroid)
      {
        var build = await deviceInfoPlugin.androidInfo;
        deviceName = build.model;
        deviceVersion = build.version.toString();
        if(App_Session.myKeychainData.isEmpty)
        {
          identifier = build.androidId;  //UUID for Android
          App_Session.myKeychainData['myDeviceId'] = identifier;
          saveDataINKeychain();
        }
        else{
          identifier = App_Session.myKeychainData['myDeviceId'];
        }
        App_Session.myDeviceType = '2';
      }
      else if (Platform.isIOS)
      {
        var data = await deviceInfoPlugin.iosInfo;
        deviceName = data.name;
        deviceVersion = data.systemVersion;
        if(App_Session.myKeychainData.isEmpty){
          identifier = data.identifierForVendor;
          App_Session.myKeychainData['myDeviceId'] = identifier;
          saveDataINKeychain();
        }
        else{
          identifier = App_Session.myKeychainData['myDeviceId'];
        }
        App_Session.myDeviceType = '1';
      }
      App_Session.myDeviceUniqueId= identifier;

      appName = packageInfo.appName;
      packageName = packageInfo.packageName;
      version = packageInfo.version;
      buildNumber = packageInfo.buildNumber;
      App_Session.myAppVersion = version;

    } on PlatformException {
      if (kDebugMode) {
        print('Failed to get platform version');
      }
    }
  }


  /// Get Documentory Path
  static Future<String> getDocumentDirectoryPath() async
  {
    //Get this App Document Directory
    final directory = await getApplicationDocumentsDirectory();
    //App Document Directory + folder name

    //get app doc  directory path
    imageDocumentFolderPath = directory.path.toString();
    return imageDocumentFolderPath;
;
  }

  static saveDataInInternalMemory()
  {
    Map<String, dynamic> internalMemoryData = <String, dynamic>{};
    internalMemoryData['userId'] = App_Session.userId.toString();
    internalMemoryData['email'] =  App_Session.email.toString();
    internalMemoryData['firstName'] =  App_Session.firstName.toString();
    internalMemoryData['lastName'] =  App_Session.lastName.toString();
    internalMemoryData['address'] = App_Session.address.toString();
    internalMemoryData['userType'] = App_Session.userTypes.toString();

    String jsonString = maasssHelperMapToJson(internalMemoryData);
    maasss_Helper_WriteDataInFile(jsonString,'settings.txt');
  }

  static readDataFromInternalMemory()
  {
    if(internalMemoryDataInString.isNotEmpty)
    {
      Map<String, dynamic> internalMemoryData = maasssHelperJsonToMap(internalMemoryDataInString);
      if(internalMemoryData!=null)
      {
        App_Session.userId = internalMemoryData['userId'].toString();
        App_Session.email = internalMemoryData['email'].toString();
        App_Session.firstName = internalMemoryData['firstName'].toString();
        App_Session.lastName = internalMemoryData['lastName'].toString();
        App_Session.address = internalMemoryData['address'].toString();
        App_Session.userTypes = internalMemoryData['userType'].toString();

      }
    }
  }

  /// Create Folder inside Internal Memory
  static Future<String> createFolderInInternalMemory(String folderName) async
  {
    //Get this App Document Directory
    Directory appDocDir = await getApplicationDocumentsDirectory();
    //App Document Directory + folder name
    Directory appDocDirFolder =  Directory('${appDocDir.path}/$folderName/');

    late String filepath ;
    if(await appDocDirFolder.exists())
    { //if folder already exists return path
      if (kDebugMode) {
        print("Folder Already Exist");
      }
      filepath = appDocDirFolder.path.toString();
    }
    else
    {//if folder not exists create folder and then return its path
      Directory appDocDirNewFolder=await appDocDirFolder.create(recursive: true);
      if (kDebugMode) {
        print(appDocDirNewFolder.path);
      }
      filepath = appDocDirNewFolder.path.toString();
    }
    return filepath;//get app doc  directory path

  }

/// Delete Folder In Internal Memory
  static Future<bool> deleteFolderInInternalMemory(String folderName) async
  {
    //Get this App Document Directory
    Directory appDocDir = await getApplicationDocumentsDirectory();
    //App Document Directory + folder name
    Directory appDocDirFolder =  Directory('${appDocDir.path}/$folderName/');


    if(await appDocDirFolder.exists())
    { //if folder already exists return path
      appDocDirFolder.deleteSync(recursive: true);
      print("Folder Deleted");
      return true;
    }
    else
    {//if folder not exists create folder and then return its path
      print("Folder Not Found");
      return false;
    }  //get app doc  directory path

  }

  //// save Text file into internal memory
  static saveStringInInternalMemory(String folderName, String fileName, String fileDataString ) async
  {

    //Get this App Document Directory
    Directory appDocDir = await getApplicationDocumentsDirectory();
    Directory appDocDirFolder;
    //App Document Directory + folder name
    if(folderName.isEmpty){
      appDocDirFolder =  Directory('${appDocDir.path}/');
    }
    else{
      appDocDirFolder =  Directory('${appDocDir.path}/$folderName/');
    }


    late String filepath ;
    if(await appDocDirFolder.exists())
    {//if folder already exists return path
       filepath = appDocDirFolder.path.toString()+fileName.toString();
    }
    else
    {//if folder not exists create folder and then return its path
      Directory appDocDirNewFolder=await appDocDirFolder.create(recursive: true);
      print(appDocDirNewFolder.path);
      filepath = appDocDirNewFolder.path.toString()+fileName.toString();
    }   //get app doc  directory path
    late File ourFile;
    if(await File(filepath).exists())
    {
      print("File Already Exist");
      ourFile = File(filepath);
    }
    else
    {
      ourFile = File(filepath);
      appDocDir.listSync();
    }

    ourFile.writeAsString(fileDataString);
  }

  //// Read Text File From Internal Memory
  static Future<String> readStringFromInternalMemory(String folderName, String fileName ) async
  {

    String readData = '';

    //Get this App Document Directory
    Directory appDocDir = await getApplicationDocumentsDirectory();
    Directory appDocDirFolder;

    if(folderName.isEmpty){
      appDocDirFolder =  Directory('${appDocDir.path}/');
    }
    else{
      appDocDirFolder =  Directory('${appDocDir.path}/$folderName/');
    }

    if(await appDocDirFolder.exists())
    {

      String filepath = appDocDirFolder.path.toString()+fileName.toString();
      late File ourFile;
      if(await File(filepath).exists())
      {
        print("File Already Exist");
        ourFile = File(filepath);
        try {
          final file = await ourFile;

          // Read the file
          final contents = await file.readAsString();
          print(contents);
          readData = contents;


        } catch (e) {
          print(e)  ;
          // If encountering an error, return 0

        }

      }
      else {
        print("File Not Found");
      }

    }    //get app doc  directory path
    return readData;
  }

/// Delete Text File From Internal Memory
  static Future<String> deleteFileFromFolderInternalMemory(String folderName, String fileName ) async
  {

    String readData = '';

    //Get this App Document Directory
    Directory appDocDir = await getApplicationDocumentsDirectory();
    Directory appDocDirFolder;

    if(folderName.isEmpty){
      appDocDirFolder =  Directory('${appDocDir.path}/');
    }
    else{
      appDocDirFolder =  Directory('${appDocDir.path}/$folderName/');
    }

    if(await appDocDirFolder.exists())
    { //if folder already exists return path

      String filepath = appDocDirFolder.path.toString()+fileName.toString();
      late File ourFile;
      if(await File(filepath).exists())
      {
        await File(filepath).delete();
        print("File Deleted");
        readData = 'File Deleted';

      }
      else {
        print("File Not Found");
        readData = 'File Not Found';
      }

    }
    else {
      print("Folder Not Available");//get app doc  directory path
    }
    return readData;
  }

  /// Delete File From Internal Memory if u have full path
  static Future<bool> deleteFileFromFolderWithFullPath(String filepath ) async
  {
    bool isFileDelete = false;
    if(await File(filepath).exists())
    {
      await File(filepath).delete();
      if (kDebugMode) {
        print("File Deleted");
      }
      isFileDelete = true;
    }
    else {
      if (kDebugMode) {
        print("File Not Found");
      }
      isFileDelete = false;
    }
    return isFileDelete;

  }

/// Save Byte File Inside Internal Memory
  static saveFilesByBytesInInternalMemory(String folderName, String fileName, String fileUrl) async
  {

    late Uint8List fileDataBytes;
    try{
      fileDataBytes = await File(fileUrl).readAsBytes();
    }
    catch (e){
      if (kDebugMode) {
        print(e);
      }
    }
    final buffer = fileDataBytes.buffer;
    //Get this App Document Directory
    Directory appDocDir = await getApplicationDocumentsDirectory();
    Directory appDocDirFolder;
    if(folderName.isEmpty){
      appDocDirFolder =  Directory('${appDocDir.path}/');
    }
    else{
      appDocDirFolder =  Directory('${appDocDir.path}/$folderName/');
    }

    late String filepath ;
    if(await appDocDirFolder.exists())
    { //if folder already exists return path
      print("Folder Already Exist");
      filepath = appDocDirFolder.path.toString()+fileName.toString();
    }
    else
    {//if folder not exists create folder and then return its path
      Directory appDocDirNewFolder=await appDocDirFolder.create(recursive: true);
      print(appDocDirNewFolder.path);
      filepath = appDocDirNewFolder.path.toString()+fileName.toString();
    }   //get app doc  directory path
    late File ourFile;
    if(await File(filepath).exists())
    {
      print("File Already Exist");
      ourFile = File(filepath);
    }
    else
    {
      ourFile = File(filepath);
      appDocDir.listSync();
    }
// Write File in byte code
    // ByteData byteData = await rootBundle.load('assets/images/imageload.png');
    // conversion in byte code

    ourFile.writeAsBytes(
        buffer.asUint8List(fileDataBytes.offsetInBytes, fileDataBytes.lengthInBytes));
  }

  /// Read Byte File Inside Internal Memory
  static Future<File> getLocalFile(String folderName, String filename) async
  {
    String dir = (await getApplicationDocumentsDirectory()).path;
    File f = File('$dir/$folderName/$filename');
    f.readAsBytesSync();
    return f;
  }

  static Future<String> moveFileFromFolderInternalMemory(String sourceFolderName, String destinationFolderName, String fileName ) async
  {

    String readData = '';

    //Get this App Document Directory
    Directory appDocDir = await getApplicationDocumentsDirectory();
    Directory appDocDirFolder;

    Directory desDocFolder;
    desDocFolder =  Directory('${appDocDir.path}/$destinationFolderName/');
    String destFilepath = desDocFolder.path.toString();

    if(sourceFolderName.isEmpty)
    {
      appDocDirFolder =  Directory('${appDocDir.path}/');
    }
    else{
      appDocDirFolder =  Directory('${appDocDir.path}/$sourceFolderName/');
    }

    if(await appDocDirFolder.exists())
    { //if folder already exists return path

      String sourceFilepath = appDocDirFolder.path.toString()+fileName;
      if(await File(sourceFilepath).exists())
      {

         var file = File(sourceFilepath);
        file.copy(destFilepath+'/'+fileName);
         await File(sourceFilepath).delete();

        print("File Move Successfully");
        readData = 'File Move Successfully';

      }
      else {
        print("File Not Found");
        readData = 'File Not Found';
      }


    }
    else {
      if (kDebugMode) {
        print("Folder Not Available");
      }//get app doc  directory path
    }
    return readData;
  }

  static Future<String> copyFileFromFolderInternalMemory(String sourceFolderName, String destinationFolderName, String fileName ) async
  {

    String readData = '';
    //Get this App Document Directory
    Directory appDocDir = await getApplicationDocumentsDirectory();
    Directory appDocDirFolder;

    Directory desDocFolder;
    desDocFolder =  Directory('${appDocDir.path}/$destinationFolderName/');
    String destFilepath = desDocFolder.path.toString();

    if(sourceFolderName.isEmpty){
      appDocDirFolder =  Directory('${appDocDir.path}/');
    }
    else{
      appDocDirFolder =  Directory('${appDocDir.path}/$sourceFolderName/');
    }

    if(await appDocDirFolder.exists())
    { //if folder already exists return path

      String sourceFilepath = appDocDirFolder.path.toString()+fileName;
      if(await File(sourceFilepath).exists())
      {
        var file = File(sourceFilepath);
        file.copy(destFilepath+'/'+fileName);

        if (kDebugMode) {
          print("File Copied");
        }
        readData = 'File Copied';
      }
      else {
        if (kDebugMode) {
          print("File Not Found");
        }
        readData = 'File Not Found';
      }
    }
    else {
      if (kDebugMode) {
        print("Folder Not Available");
      }//get app doc  directory path
    }
    return readData;
  }

  static Future<File> createZipOfFiles(List<PickedFile> filepathArray)
  async {
    List<File> files = [];
    const _dataFilesBaseDirectoryName = "uploadImageFolder";
    for(PickedFile file in filepathArray)
    {
      files.add(File(file.path));
    }
    final storeDir = Directory("${Directory.systemTemp.path}${"/$_dataFilesBaseDirectoryName"}");

    if (storeDir.existsSync())
    {
      storeDir.deleteSync(recursive: true);
    }
    storeDir.createSync();
    final filesArray = <File>[];
    for (int i=0; i<files.length;i++)
    {
      var ms = (DateTime.now()).millisecondsSinceEpoch;
      var currentTimeInSecond = (ms / 1000).round();

      String fileName = currentTimeInSecond.toString()+i.toString()+'.jpg';

      final file = File("${storeDir.path}/$fileName");
      files[i].copy("${storeDir.path}/$fileName");
      filesArray.add(file);
    }

    String zipFileName = 'uploadZipFiles.zip';
    final zipFilePath = "${Directory.systemTemp.path}/$zipFileName";
    final zipFile = File(zipFilePath);

    if (zipFile.existsSync()) {
      if (kDebugMode) {
        print("Deleting existing zip file: ${zipFile.path}");
      }
      zipFile.deleteSync();
    }

    if (kDebugMode) {
      print("Writing files to zip file: ${zipFile.path}");
    }

    try {
      await ZipFile.createFromFiles(
          sourceDir: storeDir,
          files: filesArray,
          zipFile: zipFile,
          includeBaseDirectory: true);
    } on PlatformException
    catch (e)
    {
      if (kDebugMode)
      {
        print(e);
      }
    }

    return zipFile;
  }
}