
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import '../maasss_helper.dart';

// ignore: camel_case_types
class Interface_Api_Response
{
  // ignore: non_constant_identifier_names
  void web_Service_Response_Error(String apiName, var response)
  {

  }

  // ignore: non_constant_identifier_names
  void web_Service_Response(Map<String, dynamic> responseDic, String apiName)
  {
      //print(responseDic);
  }
}

// ignore: camel_case_types
class API_Manager
{
  static const String BASE_URL_TEST = 'http://159.203.183.64/Live/API/CorePHPAPIS/'; //Test url
  static const String BASE_URL_LIVE = 'https://www.maasss.com/apis/'; //Live url
  static const String BASE_URL_APPLY = BASE_URL_TEST; //Live url

  // ignore: non_constant_identifier_names
  Interface_Api_Response interface_api_response = new Interface_Api_Response();

  apiUploadFileWithDataByPost(String filepath, List<int> fileBytes, Map<String, dynamic> inputData, String requestUrl, String apiName, String fileName, String fileType) async
  {
    var request = http.MultipartRequest(
        "POST", Uri.parse(requestUrl));

    for (dynamic key in inputData.keys)
    {
      request.fields[key] = inputData[key];
    }

    if(filepath.isEmpty)
    {
      request.files.add(http.MultipartFile.fromBytes(fileName, fileBytes, contentType: MediaType(fileName, fileType)));
    }
    else {
      request.files.add(await http.MultipartFile.fromPath('files', filepath));
    }

    var streamedResponse = await request.send();
    var response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode == 200)
    {
      final String responseBody = response.body;
      Map<String, dynamic> responseDic = maasssHelperJsonToMap(responseBody.trim());
      // response handler
      api_Response(responseDic,apiName);
    }
    else {
      // response error handler
      api_Response_Error(apiName, response);
    }
  }

  // ignore: non_constant_identifier_names
  api_Handle_By_Post_With_String_Input(String inputData, String url, String apiName )
  async {
    var mBody = inputData;
    final response = await http.post(Uri.parse(url) , body: mBody);
    if (response.statusCode == 200)
    {
      final String responseBody = response.body;
      print(response.body);
      Map<String, dynamic> responseDic = maasssHelperJsonToMap(responseBody.trim());

      // response handler
      api_Response(responseDic,apiName);
    }
    else {
      // response error handler
      api_Response_Error(apiName,response);
    }
  }

  // ignore: non_constant_identifier_names
  api_Handle_By_Post(Map<String, dynamic> inputData, String url, String apiName,int isJson)
  async {
    var mBody;
    if(isJson==1)
    {
      mBody = maasssHelperMapToJson(inputData);
    }
    else{
      mBody = inputData;
    }

    final response = await http.post(Uri.parse(url) , body: mBody);
    if (response.statusCode == 200)
    {
      final String responseBody = response.body;
      print(response.body);
      Map<String, dynamic> responseDic = maasssHelperJsonToMap(responseBody.trim());

      // response handler
      api_Response(responseDic,apiName);
    }
    else {
      // response error handler
      api_Response_Error(apiName ,response);
    }
  }

  // ignore: non_constant_identifier_names
  api_Handle_Authorization_Bearer_By_Post(Map<String, dynamic> inputData, String url, String token, String apiName )
  async{

    var mBody = jsonEncode(inputData);

    final response = await http.post(Uri.parse(url), headers:
    {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer $token',
    }, body:mBody);

    if (response.statusCode == 200)
    {
      final String responseBody = response.body;
      print(response.body);
      Map<String, dynamic> responseDic = maasssHelperJsonToMap(responseBody.trim());
      // response handler
      api_Response(responseDic,apiName);
    }
    else {
      // response error handler
      api_Response_Error(apiName ,response);
    }
  }

  // ignore: non_constant_identifier_names
  api_Handle_Authorization_Bearer_By_Get(String url, String token, String apiName)
  async{

    final response = await http.get(Uri.parse(url), headers:
    {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ' + token,
    });

    if (response.statusCode == 200)
    {
      final String responseBody = response.body;
      if (kDebugMode) {
        print(response.body);
      }
      Map<String, dynamic> responseDic = maasssHelperJsonToMap(responseBody.trim());

      // response handler
      api_Response(responseDic,apiName);
    }
    else
    {
      // response error handler
      api_Response_Error(apiName ,response);
    }
    if (kDebugMode)
    {
      print(response);
    }
  }

  // ignore: non_constant_identifier_names
  api_Handle_By_Get(String url, String apiName)
  async {
    final response = await http.get(Uri.parse(url));
    if (kDebugMode)
    {
      print(response.body);
    }
    if (response.statusCode == 200)
    {
      final String loginResponse = response.body;
      Map<String, dynamic> responseDic = maasssHelperJsonToMap(loginResponse.trim());

      // response handler
      api_Response(responseDic, apiName);
      //App_Session.myCountry = responseDic['country'];
    }
    else
    {
      // response error handler
      api_Response_Error(apiName ,response);
    }
  }


  ///////////////////////////////////////
  //                                   //
  // Project based api request  method //
  //                                   //
  ///////////////////////////////////////

  // ignore: non_constant_identifier_names
  void api_Request_Method(Map<String, dynamic> requestData, String appendURL, String apiName)
  {
    switch(apiName)
    {
      case "Country_Request":
        {
          String url = 'https://api.myip.com';
          api_Handle_By_Get(url, apiName);
          break;
        }
      case "UserLogin":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/user_login.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "Registration":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/user_registration.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "ChangePassword":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/change_password.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "ForgotPassword":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/forgot_password.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
        case "UpdatePet":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/update_pet.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "FetchAllPetByUser":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/fetch_allpet_byuser.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "AddSymptoms":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/add_symptoms.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "SymptomsByUser":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/symptoms_byuser.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "SymptomsByExpert":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/symptoms_byexpert.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "SymptomsUpdateByExpert":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/symptom_update_byexpert.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "ExpertList":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/expertlist.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "VetList":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/vet_list.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "SymptomsList":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/symptoms.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "ExpertReply":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/expert_reply.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "ListOfMyDogRequests":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/fetch_mydog_requests.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "ListOfAllRequests":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/fetch_all_requests.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "UpdateProfile":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/update_profile.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "FetchConcludeHistory":
        {
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/fetch_conclude_history.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      case "GoogleApi":
        {
          //String url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?keyword=dog%20vet&location=55.775551%2C-4.047560&radius=1500&key=AIzaSyDfAHLA2paXtrLM0dcFk2NxJ6UDY53QKcY";
          String url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?keyword=dog%20vet&"+appendURL+"&radius=6000&key=AIzaSyDfAHLA2paXtrLM0dcFk2NxJ6UDY53QKcY";
          api_Handle_By_Get(url, apiName);
          break;
        }
      case "Pet_Detail":
        {//
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/pet_detail.php";
          api_Handle_By_Post(requestData, url, apiName,1);
          break;
        }
      default:
        {
          break;
        }
    }
  }

  void apiRequestForFileUpload(String filepath, Map<String, dynamic> requestData, String apiName, List<int> fileBytes) {
    switch(apiName)
    {
      case "CreatePet":
        {
          String fileName = 'files';
          String fileType = 'zip';
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/create_pet.php";

          apiUploadFileWithDataByPost(filepath, fileBytes, requestData, url, apiName, fileName, fileType);
          break;
        }
      case "CreateRequest":
        {
          String fileName = 'files';
          String fileType = 'zip';
          String url = "http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/create_request.php";

          apiUploadFileWithDataByPost(filepath, fileBytes, requestData, url, apiName, fileName, fileType);
          break;
        }
      default:
        {
          break;
        }
    }
  }


  ///////////////////////////////////////
  //                                   //
  // Project based api response method //
  //                                   //
  ///////////////////////////////////////

  // ignore: non_constant_identifier_names
  void api_Response(Map<String, dynamic> responseDictionary, String apiName )
  {
    interface_api_response.web_Service_Response(responseDictionary, apiName);
  }

  // ignore: non_constant_identifier_names
  void api_Response_Error(String apiName ,var response)
  {
    interface_api_response.web_Service_Response_Error(apiName, response);
  }
}