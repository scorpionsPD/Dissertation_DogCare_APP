
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import '../engine/app_profile.dart';
class SQLDBManager
{
  static const dataBaseName = "dogcare.db";
  static const dataBaseFolder = "appdata";
  static const dataBaseVersion = 1;
  static const String columnUniqueID ='column_id';

  static Database? databaseObject;

  SQLDBManager.privateConstructor();
  static final SQLDBManager instance = SQLDBManager.privateConstructor();

  SQLDBManager()
  {
    getDatabaseObject(dataBaseName);
    projectTables();
  }

  Future<Database?> getDatabaseObject(String databaseName) async
  {
    if(databaseObject != null) return databaseObject;
    databaseObject = await initDatabase(dataBaseName);
    return databaseObject;
  }

  initDatabase(String databaseName) async
  {
    String folder = await AppProfile.createFolderInInternalMemory(dataBaseFolder);

    String path = join(folder, databaseName);
    if (kDebugMode) {
      print('DatabasePath: '+path);
    }
    return await openDatabase(path, version: dataBaseVersion);
  }

  Future createTable(String tableName, List<String> tableColumns) async
  {
    Database? db = await instance.getDatabaseObject(dataBaseName);

    String columnSetup = '$columnUniqueID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, ';
    for(int i=0; i<tableColumns.length; i++)
    {
      columnSetup = columnSetup + tableColumns[i].toString() + ' ';
      columnSetup = columnSetup + 'TEXT NOT NULL';
      if(i+1!=tableColumns.length) {
        columnSetup = columnSetup + ', ';
      }
    }
    String createTableQuery = 'CREATE TABLE $tableName ($columnSetup)';
    try{
      await db?.execute(
          '''
      $createTableQuery
      '''
      );
    }
    catch(e){
      if (kDebugMode) {
        print(e);
      }
    }

  }
  // function to insert , query, update and delete
  Future<int?> insertOneRowInTable(Map<String, dynamic> row, String tableName) async
  {
    Database? db = await instance.getDatabaseObject(dataBaseName);
    try
    {
      await db?.insert(tableName, row);
      return 1;
    }
    catch(e){
      return 0;
    }
  }

// Query all rows
  Future<List<Map<String, dynamic>>?> fetchAllTableData(String tableName) async
  {
    Database? db = await instance.getDatabaseObject(dataBaseName);
    var output = await db?.query(tableName);
    return output;
  }

  // Query Specific
  Future<List<Map<String, dynamic>>?> fetchSelectedDataFromTable(String sqlQuery) async
  {
    Database? db = await instance.getDatabaseObject(dataBaseName);
    ////// inbuilt function to get specific query/////
    //var res = await db?.query(tableName, where: "age > ?", whereArgs: [age]);

    //// raw query to get specific query
    // eg: 'SELECT * FROM $tableName WHERE age >?'
    var res = await db?.rawQuery(sqlQuery);
    return res;
  }
//// delete row with where clause
  Future<int?> deleteData(String deleteQuery) async
  {
    Database? db = await instance.getDatabaseObject(dataBaseName);
    ////// inbuilt function to get specific query/////
    //var res = await db?.delete(tableName, where: "id = ?", whereArgs: [id]);
    //// raw query to get specific query
    // eg: 'DELETE FROM my_table WHERE id =?'
    if (kDebugMode) {
      print(deleteQuery);
    }
     var res = await db?.rawDelete(deleteQuery);

    return res;
  }

  //// update with where clause
  Future<int?> updateData(Map<String, dynamic> row, String tableName, int columnId) async
  {

    Database? db = await instance.getDatabaseObject(dataBaseName);
    ////// inbuilt function to get specific query/////
    //var res = await db?.update(tableName, { "name": "Biswajeet", "age": 32},where: "id = ?", whereArgs: [id]);

    String updateQuery = "update $tableName set ";
    List updateColumn = row.keys.toList();
    for(int i=0; i<updateColumn.length; i++)
    {
      updateQuery = updateQuery + updateColumn[i].toString() + ' ';
      updateQuery = updateQuery + ' = ';
      var value = row[updateColumn[i]];
      updateQuery = updateQuery + "'$value'";
      if(i+1!=updateColumn.length)
      {
        updateQuery = updateQuery + ', ';
      }
    }
    String updateTableQuery = updateQuery + " where $columnUniqueID = $columnId";

    //// raw query to get specific query
    // eg: 'UPDATE my_table SET name = ?, age = ? WHERE id =?'
     var res = await db?.rawUpdate(updateTableQuery);

    return res;
  }

  ////////////////////////////
  ////////////////////////////
  /// Project Related ////////
  ////////////////////////////
  ////////////////////////////

   String tableConclude = "ConcludeTable";

   String concludeTableColumnSymptomsData = 'symptomsdata';
   String concludeTableColumnDogId = 'dogid';
   String concludeTableColumnVet = 'vet';
   String concludeTableColumnConcludedResult = 'concludedresult';
   String concludeTableColumnCreatedDate = 'createddate';



  //// Event Query
  String fetchSelectedPhotoFromEventQuery = 'select * from ConcludeTable where dogid =';
  //static String deleteSelectedPhotoFromEventQuery = 'delete from $tableMyEventPhotos where $eventPhotosTableColumnEventEventPhotoName=';
  //static String deleteEventQuery = 'delete from $tableMyEvents where $eventPhotosTableColumnEventEventPhotoName=';
  //static String updateEventTableQuery = 'update $tableMyEventPhotos where $eventPhotosTableColumnEventEventID=';


  void projectTables() async
  {
      List<String> concludeTableColumns = [concludeTableColumnSymptomsData, concludeTableColumnDogId, concludeTableColumnVet, concludeTableColumnConcludedResult, concludeTableColumnCreatedDate];
      await  createTable(tableConclude, concludeTableColumns);
  }
}