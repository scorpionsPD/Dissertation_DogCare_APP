

import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class ProgressManagerButtonInterface
{
   void progressManagerButtonPressed(String buttonTitle){}
}

// ignore: camel_case_types
class ProgressManager
{
  ProgressManagerButtonInterface progressManagerButtonInterface = ProgressManagerButtonInterface();

   static void showAlertDialog(BuildContext context, String message)
  {
    AlertDialog alert=AlertDialog(
      content: Row(
        children: [
          const CircularProgressIndicator(),
          Container(margin: EdgeInsets.only(left: 10),child:Text(message)),
        ],),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
    );

    showDialog(barrierDismissible: false,
      context:context,
      builder:(BuildContext context){
        return alert;
      },
    );
  }

  // ignore: non_constant_identifier_names
   static void showAlertDialogWithAutoDismiss(BuildContext context, String message, int dismissTimer, int afterLoadingProgress)
  {
    if(afterLoadingProgress == 1)
    {
      //Navigator.of(context).pop(AlertDialog);
      Navigator.of(context, rootNavigator: true).pop(AlertDialog);
    }

    showDialog(
        context: context,
        builder: (context)
        {
          Future.delayed(Duration(seconds: dismissTimer), ()
          {
            Navigator.of(context).pop(false);
          });
          return AlertDialog(
            title: Text(message,
            textAlign: TextAlign.center,),
          );
        });
  }

   /// alert dialog with one button android Style
   static showDefaultAlertDialogWithOneButtonAndroidStyle(BuildContext context,String titleString,String messageString,String button1Tittle)
   {
     // set up the button
     AlertDialog alert = AlertDialog(

       title: Center(child: Text(titleString)),

       titleTextStyle:
       const TextStyle(
           fontWeight: FontWeight.bold,
           color: Colors.black,fontSize: 20),
       actionsOverflowButtonSpacing: 20,
       actions: [
         Row(
           mainAxisAlignment: MainAxisAlignment.center,
           children: [
             Padding(
               padding: EdgeInsets.all(20.0),
               child: ElevatedButton(onPressed: ()
               {
                 //progressManagerButtonInterface.progressManagerButtonPressed(button1Tittle);
                 Navigator.of(context).pop();
               }, child: Text(button1Tittle)),
             ),
           ],
         ),
       ],
       shape: RoundedRectangleBorder(
           borderRadius: BorderRadius.all(Radius.circular(20))
       ),

       content: Text(messageString, textAlign: TextAlign.center,),
     );
     // show the dialog
     showDialog(
       context: context,
       builder: (BuildContext context) {
         return alert;
       },
     );
   }

   /// alert dialog with Two button android Style
   static showDefaultAlertDialogWithTwoButtonAndroidStyle(BuildContext context,String titleString,String messageString,)
   {
     // set up the button

     AlertDialog alert = AlertDialog(

       title: Center(child: Text(titleString)),

       titleTextStyle:
       const TextStyle(
           fontWeight: FontWeight.bold,
           color: Colors.black,fontSize: 20),
       actionsOverflowButtonSpacing: 20,
       actions: [
         Row(
           mainAxisAlignment: MainAxisAlignment.center,
           children: [
             Padding(
               padding: const EdgeInsets.all(20.0),
               child: ElevatedButton(onPressed: (){
                 Navigator.of(context).pop();
               }, child: Text("Back")),
             ),

             Padding(
               padding: const EdgeInsets.all(20.0),
               child: ElevatedButton(onPressed: (){
                 Navigator.of(context).pop();
               }, child: Text("Next")),
             ),
           ],
         ),

       ],
       shape: RoundedRectangleBorder(
           borderRadius: BorderRadius.all(Radius.circular(20))
       ),

       content: Text(messageString, textAlign: TextAlign.center,),
     );

     // show the dialog
     showDialog(
       context: context,
       builder: (BuildContext context) {
         return alert;
       },
     );
   }

   /// alert dialog with Two button with text field android Style
   static showDefaultAlertDialogWithTwoButtonWithTextfiledAndroidStyle(BuildContext context,String titleString)
   {
     // set up the button
     TextEditingController _textFieldController = TextEditingController();

     AlertDialog alert = AlertDialog(

       title: Center(child: Text(titleString)),

       titleTextStyle:
       TextStyle(
           fontWeight: FontWeight.bold,
           color: Colors.black,fontSize: 20),
       actionsOverflowButtonSpacing: 20,
       actions: [
         Row(
           mainAxisAlignment: MainAxisAlignment.center,
           children: [
             Padding(
               padding: const EdgeInsets.all(20.0),
               child: ElevatedButton(onPressed: (){
                 Navigator.of(context).pop();
               }, child: Text("OK")),
             ),

             Padding(
               padding: const EdgeInsets.all(20.0),
               child: ElevatedButton(onPressed: (){
                 Navigator.of(context).pop();
               }, child: Text("Cancel")),
             ),
           ],
         ),

       ],
       shape: RoundedRectangleBorder(
           borderRadius: BorderRadius.all(Radius.circular(20))
       ),

       content: TextField(
         controller: _textFieldController,
         textInputAction: TextInputAction.go,
         keyboardType: TextInputType.numberWithOptions(),
         decoration: InputDecoration(hintText: "Enter your Password"),
         textAlign: TextAlign.center,
       ),

     );

     // show the dialog
     showDialog(
       context: context,
       builder: (BuildContext context) {
         return alert;
       },
     );
   }

   /// alert dialog with one button iphone Style
   static showDefaultAlertDialogWithOneButtonIphoneStyle(BuildContext context,String titleString,String messageString,)
   {
     // set up the button
     Widget okButton = TextButton(
       child: Text("OK"),
       onPressed: () {
         Navigator.of(context).pop();
       },
     );

     // set up the AlertDialog
     CupertinoAlertDialog cuperalert = CupertinoAlertDialog(
       title: Text(titleString),
       content: Text(messageString),
       actions: [
         okButton,
       ],
     );

     // show the dialog
     showDialog(
       context: context,
       builder: (BuildContext context) {
         return cuperalert;
       },
     );
   }

   /// alert dialog with Two button iphone Style
   static showDefaultAlertDialogWithTwoButtonIphoneStyle(BuildContext context,String titleString,String messageString,) {
     // set up the button
     Widget okButton = TextButton(
       child: Text("OK"),
       onPressed: () {
         Navigator.of(context).pop();
       },
     );
     Widget cancelButton = TextButton(
       child: Text("Cancel"),
       onPressed: () {
         Navigator.of(context).pop();
       },
     );

     // set up the AlertDialog
     CupertinoAlertDialog cuperalert = CupertinoAlertDialog(
       title: Text(titleString),
       content: Text(messageString),
       actions: [
         okButton,cancelButton,
       ],
     );

     // show the dialog
     showDialog(
       context: context,
       builder: (BuildContext context) {
         return cuperalert;
       },
     );
   }

   /// custom alert dialog with one button iphone Style
   static customDialogWithOneButton(BuildContext context,String titleString,String messageString,) {
     Dialog alert = Dialog(
       elevation: 0,
      // backgroundColor: Colors.limeAccent,
       shape: RoundedRectangleBorder(
           borderRadius: BorderRadius.circular(30.0)),
       child: Padding(
         padding: const EdgeInsets.all(20.0),
         child: Container(
           height: 300,
           child: Column(
             mainAxisAlignment: MainAxisAlignment.spaceBetween,
             children: [
               Text(
                 titleString,
                 style: TextStyle(fontSize: 20),
               ),
               Text(
                 messageString,
                 style: TextStyle(fontSize: 20),
               ),
               ElevatedButton(
                   onPressed: () {
                     Navigator.of(context).pop();
                   },
                   child: Text("Close"))
             ],
           ),
         ),
       ),
     );
       // show the dialog
       showDialog(
         context: context,
         builder: (BuildContext context) {
           return alert;
         },
       );


   }

   /// custom alert dialog with Two button iphone Style
   static customDialogWithTwoButton(BuildContext context,String titleString,String messageString,) {
     Dialog alert = Dialog(
       elevation: 0,
       backgroundColor: Colors.pink.shade50,
       shape: RoundedRectangleBorder(
           borderRadius: BorderRadius.circular(30.0)),
       child: Container(
         height: 400,
         child: Column(
           mainAxisAlignment: MainAxisAlignment.spaceBetween,
           children: [
             Text(
               titleString,
               style: TextStyle(fontSize: 20),
             ),
             FlutterLogo( size: 150,),
             Text(
               messageString,
               style: TextStyle(fontSize: 20),
             ),
             ElevatedButton(
                 onPressed: () {
                   Navigator.of(context).pop();
                 },
                 child: Text("Close")),
             ElevatedButton(
                 onPressed: () {
                   Navigator.of(context).pop();
                 },
                 child: Text("OK"))
           ],
         ),
       ),
     );
     // show the dialog
     showDialog(
       context: context,
       builder: (BuildContext context) {
         return alert;
       },
     );


   }

   /// custom alert dialog with Two button iphone Style
   customDialogWithDeleteButtonOption(BuildContext context,String titleString,String messageString,String imageFilePath,String button1String, String button2String)
   {
     // show the dialog
     BuildContext dialogContext;
     showDialog(
       context: context,
       builder: (BuildContext context)
       {
         dialogContext = context;
         return Dialog(
           elevation: 0,
           backgroundColor: Colors.pink.shade50,
           shape: RoundedRectangleBorder(
               borderRadius: BorderRadius.circular(30.0)),
           child: Container(
             height: 400,
             child: Column(
               mainAxisAlignment: MainAxisAlignment.spaceBetween,
               children: [
                 Padding(
                   padding: const EdgeInsets.only(top: 15),
                   child: Text(
                     titleString,
                     style: const TextStyle(fontSize: 20,fontWeight: FontWeight.bold),
                   ),
                 ),
                 if(imageFilePath.isNotEmpty)
                   Image.file(File(imageFilePath),width:MediaQuery.of(context).size.width-30,height: 200, fit: BoxFit.cover),
                 Text(
                   messageString,
                   style: TextStyle(fontSize: 20),
                 ),
                 Padding(
                   padding: const EdgeInsets.only(bottom: 20.0),
                   child: Row(
                     mainAxisAlignment: MainAxisAlignment.center,
                     children: [
                       Padding(
                         padding: const EdgeInsets.only(left: 50.0),
                         child: ElevatedButton(
                             onPressed: ()
                             {
                               Navigator.of(dialogContext).pop();
                               progressManagerButtonInterface.progressManagerButtonPressed(button1String);
                             },
                             child: Text(button1String)),
                       ),
                       Spacer(),
                       Padding(
                         padding: const EdgeInsets.only(right: 50.0),
                         child: ElevatedButton(
                             onPressed: () {
                               Navigator.of(dialogContext).pop();
                               progressManagerButtonInterface.progressManagerButtonPressed(button2String);
                             },
                             child: Text(button2String)),
                       ),
                     ],
                   ),
                 )
               ],
             ),
           ),
         );
       },
     );


   }

   /// progressbar example
   static void showAlertDialogTimer(BuildContext context, String message)
   {
     showDialog(
       context: context,
       barrierDismissible: false,
       builder: (BuildContext context) {
         return Dialog(
           child: new Row(
             mainAxisSize: MainAxisSize.min,
             children: [
               new CircularProgressIndicator(),
               new Text(message),
             ],
           ),
         );
       },
     );
     new Future.delayed(new Duration(seconds: 3), () {
       Navigator.pop(context); //pop dialog
       print("Loading successful");
     });
   }

   /// Circular progressbar example
   static void circularProgressIndicator(BuildContext context, String message)
   {
     showDialog(
       context: context,
       barrierDismissible: false,
       builder: (BuildContext context) {
         return Dialog(backgroundColor: Colors.transparent,
           child: new Column(
             mainAxisSize: MainAxisSize.min,
             children: [
               new CircularProgressIndicator(
                 valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
                 strokeWidth: 4,
               ),
               new Text(message),
             ],
           ),
         );
       },
     );
     new Future.delayed(new Duration(seconds: 3), () {
       Navigator.pop(context); //pop dialog
       print("Loading successful");
     });
   }
   /// Linear progressbar example
   static void linearProgressIndicator(BuildContext context, String message)
   {
     showDialog(
       context: context,
       barrierDismissible: false,
       builder: (BuildContext context) {
         return Dialog(backgroundColor: Colors.transparent,
           child: new Column(
             mainAxisSize: MainAxisSize.min,
             children: [
               new LinearProgressIndicator(
                 valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
               ),
               new Text(message),
             ],
           ),
         );
       },
     );
     new Future.delayed(new Duration(seconds: 3), () {
       Navigator.pop(context); //pop dialog
       print("Loading successful");
     });
   }

   /// Circular progressbar example
   static void circularProgressIndicatorTransparentBg(BuildContext context, String message,  int duration) {
     showDialog(
       context: context,
       barrierDismissible: false,
       builder: (BuildContext context) {
         return Container(
           alignment: Alignment.center,
            height: 100,
             width: MediaQuery.of(context).size.width,
             color: Colors.transparent,
             child: new Column(
               mainAxisSize: MainAxisSize.min,
               children: [
                 new CircularProgressIndicator(
                   valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                   strokeWidth: 4,
                 ),
                 Padding(
                   padding: const EdgeInsets.all(12.0),
                   child: new Text(message, style: TextStyle(color: Colors.blue, fontSize: 18,decoration: TextDecoration.none)),
                 ),
               ],
             ),
         );
       },
     );
     new Future.delayed(new Duration(seconds: duration), () {
       Navigator.pop(context); //pop dialog
       print("Loading successful");
     });
   }


}