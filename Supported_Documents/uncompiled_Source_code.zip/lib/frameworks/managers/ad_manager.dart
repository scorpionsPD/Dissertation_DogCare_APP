
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'dart:io' show Platform;


class InterfaceForGoogleAdActivity
{
  void interfaceForRewardActivity(int rewardDisplayCheck)
  {
    //rewardDisplayCheck = 0 // For Incomplete Reward // Loaded but not show
    //rewardDisplayCheck = 1 // For get Reward
    //rewardDisplayCheck = 2 // For complete Reward Video
    //rewardDisplayCheck = 3 // For failed Reward Video
    //rewardDisplayCheck = 4 // For Show Reward Video
  }
}



 // for khojein
 //app_id: ca-app-pub-7205485202017189~1771510692 // ios
// app_id: ca-app-pub-7205485202017189~2694025065 // android
// app_id: ca-app-pub-3940256099942544/1033173712 // Test

//const String ANDROID_BANNER_UNIT_ID = 'ca-app-pub-7205485202017189/3391959918'; // test
const String ANDROID_BANNER_UNIT_ID = 'ca-app-pub-7205485202017189/9115411846'; //Live url khojien
//const String ANDROID_REWARD_UNIT_ID = 'ca-app-pub-7205485202017189/4080174918'; //Live url khojien
//const String ANDROID_VIDEO_UNIT_ID = 'ca-app-pub-7205485202017189/4080174918'; //Live url
//const String ANDROID_INTERSTITIAL_UNIT_ID = 'ca-app-pub-7205485202017189/9332501597'; //Live url

const String iOS_BANNER_UNIT_ID = 'ca-app-pub-7205485202017189/1400573351'; //Live url
//const String iOS_REWARD_UNIT_ID = 'ca-app-pub-7205485202017189/1127964431'; //Live url
//const String iOS_VIDEO_UNIT_ID = 'ca-app-pub-7205485202017189/5043550645'; //Live url
//const String iOS_INTERSTITIAL_UNIT_ID = 'ca-app-pub-7205485202017189/5043550645'; //Live url




/////////////////////////////////
//       Android work          //
/////////////////////////////////
/*
1. Regisster app and get App_Id

2. Copy this line of code in AndroidMainfest class

        <meta-data
           android:name="com.google.android.gms.ads.APPLICATION_ID"
           android:value="ca-app-pub-7205485202017189~8859506727"/>

3. Change new appId in 2. meta-data

4. Make Uncomment Ad_Manger code from AppEngine

5. Change banner id, video ad id, reward ad id on top of this class.

6. Copy this line of code in pubspec.yaml class

    google_mobile_ads: ^0.13.2 // and do pub get. find latest

7.  defaultConfig {
        multiDexEnabled true
    }

8. dependencies {
    implementation "androidx.multidex:multidex:2.0.1"
}

*/

/////////////////////////////////
//       iOS work              //
/////////////////////////////////
/*
1. Regisster app and get App_Id
A
2. Copy this line of code in info.plist -> Runner class

         <key>GADApplicationIdentifier</key>
    <string>ca-app-pub-3940256099942544~1458002511</string>
    <key>SKAdNetworkItems</key>
     <array>
        <dict>
          <key>SKAdNetworkIdentifier</key>
          <string>cstr6suwn9.skadnetwork</string>
        </dict>
      </array>

3. Change new appId in 2.

4. Make Uncomment Ad_Manger code from AppEngine

5. Change banner id, video ad id, reward ad id on top of this class.



6. copy this line of code in AppDelegate.swift class

     import GoogleMobileAds

    GADMobileAds.sharedInstance().requestConfiguration.testDeviceIdentifiers =
        [ "2077ef9a63d2b398840261c8221a0c9b" ] // Sample device ID

7.

*/
