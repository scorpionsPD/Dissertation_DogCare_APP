import 'dart:async';
import 'package:geolocator/geolocator.dart';

class HardwareManager
{
  /// /////////////////////////
  /// GET CURRENT LOCATION ////
  /// /////////////////////////

  /// 1. Copy In Pub spec: geolocator: ^8.2.0
  /// 2. For Android:- Copy below code in manifest file
  ///
  // <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
  // <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
  // <uses-permission android:name="android.permission.ACCESS_BACKGROUND_LOCATION" />
  ///
  /// 3. For iPhone: - copy this code in info.plist file
  ///
  /// <key>NSLocationWhenInUseUsageDescription</key>
  // <string>This app needs access to location when open.</string>
  // <key>NSLocationAlwaysUsageDescription</key>
  // <string>This app needs access to location when in the background.</string>


  String myCurrentLatitude = '0.0';
  String myCurrentLongitude = '0.0';
  late var hasLocationPermission;
  late var currentLocation;

  final GeolocatorPlatform _geolocatorPlatform = GeolocatorPlatform.instance;
  static const String _kPermissionGrantedMessage = 'Permission granted.';
  static const String _kLocationServicesDisabledMessage =
      'Location services are disabled.';
  static const String _kPermissionDeniedMessage = 'Permission denied.';
  static const String _kPermissionDeniedForeverMessage =
      'Permission denied forever.';
  final List<_LocationItem> _positionItems = <_LocationItem>[];
  StreamSubscription<Position>? _positionStreamSubscription;
  StreamSubscription<ServiceStatus>? _serviceStatusStreamSubscription;
  bool positionStreamStarted = false;

  HardwareManager(){
    initCurrentLocation();
  }

  initCurrentLocation() async {
     hasLocationPermission = await _handleLocationPermission();
     currentLocation = await _geolocatorPlatform.getCurrentPosition();
  }
  
  getMyCurrentLocation() async
  {
    if (!hasLocationPermission)
    {
      return;
    }

    myCurrentLatitude = currentLocation.latitude.toString();
    myCurrentLongitude = currentLocation.longitude.toString();
    _updatePositionList(
      _LocationType.position,
      currentLocation.toString(),
    );
  }

  Future<bool> _handleLocationPermission() async
  {
    bool serviceEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await _geolocatorPlatform.isLocationServiceEnabled();
    if (!serviceEnabled)
    {
      // Location services are not enabled don't continue
      // accessing the position and request users of the
      // App to enable the location services.
      _updatePositionList(
        _LocationType.log,
        _kLocationServicesDisabledMessage,
      );
      return false;
    }

    permission = await _geolocatorPlatform.checkPermission();
    if (permission == LocationPermission.denied)
    {
      permission = await _geolocatorPlatform.requestPermission();
      if (permission == LocationPermission.denied)
      {
        // Permissions are denied, next time you could try
        // requesting permissions again (this is also where
        // Android's shouldShowRequestPermissionRationale
        // returned true. According to Android guidelines
        // your App should show an explanatory UI now.
        _updatePositionList(
          _LocationType.log,
          _kPermissionDeniedMessage,
        );
        return false;
      }
    }

    if (permission == LocationPermission.deniedForever)
    {
      // Permissions are denied forever, handle appropriately.
      _updatePositionList(
        _LocationType.log,
        _kPermissionDeniedForeverMessage,
      );
      return false;
    }

    // When we reach here, permissions are granted and we can
    // continue accessing the position of the device.
    _updatePositionList(
      _LocationType.log,
      _kPermissionGrantedMessage,
    );
    return true;
  }
  void _updatePositionList(_LocationType type, String displayValue)
  {
    _positionItems.add(_LocationItem(type, displayValue));
  }
}

//
enum _LocationType {
  log,
  position,
}

class _LocationItem {
  _LocationItem(this.type, this.displayValue);

  final _LocationType type;
  final String displayValue;
}
