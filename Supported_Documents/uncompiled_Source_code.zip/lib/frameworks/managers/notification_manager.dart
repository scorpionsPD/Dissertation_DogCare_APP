
/*
Setup 1 add dependency in pubspac.
  flutter_local_notifications: ^9.5.2  // get pubget.

Setup 2
 */
import 'dart:async';
import 'dart:io' show File, Platform;

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_core/firebase_core.dart';
import '../engine/app_session.dart';

class InterfaceNotificationReceiver
{
  void surpriseNotificationReceived() {
  }
}

class NotificationManager
{
  InterfaceNotificationReceiver interfaceNotificationReceiver = InterfaceNotificationReceiver();
  late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
  FlutterLocalNotificationsPlugin();

  NotificationManager()
  {
    _requestIOSPermission();
    initializePlatformSpecifics();
    initPushNotification();
  }
  _requestIOSPermission()
  {
    flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
        IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(
      alert: false,
      badge: true,
      sound: true,
    );
  }

  initializePlatformSpecifics() async
  {
    var initializationSettingsAndroid =
    const AndroidInitializationSettings('newlogo');
    var initializationSettingsIOS = IOSInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: false,
      onDidReceiveLocalNotification: (id, title, body, payload) async
      {
        interfaceNotificationReceiver.surpriseNotificationReceived();
      },
    );
    var initializationSettings = InitializationSettings(
        android: initializationSettingsAndroid, iOS: initializationSettingsIOS);

    flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onSelectNotification: localNotificationClickCallback(),
    );
  }

  Future<void> showDailyNotificationAtTime(String title, String body) async
  {
    var time =  const Time(00,01,59); // final time 11:30:00 pm

    AndroidNotificationDetails androidChannelSpecifics = const AndroidNotificationDetails(
      'CHANNEL_ID 4',
      'CHANNEL_NAME 4',
      importance: Importance.high,
      priority: Priority.high,
      enableVibration: true,
      channelShowBadge: true,
      sound: UriAndroidNotificationSound('assets/audio/local_notification_sound.mp3'),
    );

    var iosChannelSpecifics = const IOSNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      badgeNumber:1,
      sound: ('assets/audio/local_notification_sound.wav'),
    );
    var platformChannelSpecifics =
    NotificationDetails(android: androidChannelSpecifics, iOS: iosChannelSpecifics);

    await flutterLocalNotificationsPlugin.showDailyAtTime(
      1,
      title,
      body, //null
      time,
      platformChannelSpecifics,
      payload: 'Dogcare',
    );
  }

  localNotificationClickCallback()
  {
    interfaceNotificationReceiver.surpriseNotificationReceived();
  }

  /// /////////////////////// ///
  /// Push Notification Setup ///
  /// /////////////////////// ///
  ///   firebase_core: ^1.17.1 need to add in pubsprc.yaml
  ///     firebase_messaging: ^11.4.1


  /// For iOS Extra Work ///
  /// ////////////////// ///

  /// Import in AppDelegate Class in iOS Folder ///
  // import Firebase
  // import FirebaseMessaging
  // import UserNotifications
  /// //////// Copy In didFinishLaunching Fucntion in AppDelegete ///
  //   Messaging.messaging().delegate = self;
  //   FirebaseApp.configure()
  //   GeneratedPluginRegistrant.register(with: self)
  //   Messaging.messaging().isAutoInitEnabled = true;
  //   self.registerForFirebaseNotification(application: application);
  ///  Copy these Function on App Delegete Class
  /*
      override func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken : Data)
    {
        print("X__APNS: \(String(describing: deviceToken))")
           Messaging.messaging().apnsToken = deviceToken;
        Messaging.messaging().setAPNSToken(deviceToken, type:MessagingAPNSTokenType.prod )
        }

    override func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("X_ERR",error);
    }

    func registerForFirebaseNotification(application : UIApplication){
    //    Messaging.messaging().delegate     = self;
        if #available(iOS 10.0, *) {
            //UNUserNotificationCenter.current().delegate = self ;
            let authOpt : UNAuthorizationOptions = [.alert, .badge, .sound];
            UNUserNotificationCenter.current().requestAuthorization(options: authOpt, completionHandler: {_, _ in})
            UNUserNotificationCenter.current().delegate = self ;
        }else{
            let settings : UIUserNotificationSettings = UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
            application.registerUserNotificationSettings(settings);
        }
        application.registerForRemoteNotifications();
    }
   */
  ///  Copy this Extension Function outside of App Delegete Class
  /*
  extension AppDelegate : MessagingDelegate{
        func messaging(_messagin : Messaging, didRecieveRegistrationToken fcmToken : String){
            self.firebaseToken = fcmToken;
            print("X__FCM: \(String(describing: fcmToken))")
        }
        func messaging(_messagin : Messaging, didRecieve remoteMessage : Any){
            //self.firebaseToken = fcmToken;
            print("REMOTE__MSG: \(remoteMessage)")
        }
        func application(_ application : UIApplication,didRecieveRemoteNotification uinfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void){
            print("WITH__APN: \(uinfo)")
        }
    }

  */
  /// Create GoogleService-info file firbase and import in project.

  /// /////////////////////// ///
  /// For Android ///
  /// /////////////////////// ///
  /*
  Enter In Android/build.gradle:
  dependencies {
           classpath 'com.google.gms:google-services:4.3.10'
    }
  */
  /* Register Android app On Firebase and import json file on project.*/
  /*
    Enter In Android/App/build.gradle:

    dependencies {
    implementation 'com.google.firebase:firebase-messaging:23.0.5'
  }
  */

  Future<void> initPushNotification()
  async {

    //WidgetsFlutterBinding.ensureInitialized(); enter in main() method
    await Firebase.initializeApp();
    FirebaseMessaging firebaseMessaging = FirebaseMessaging.instance;

    // request permissions for showing notification in iOS
    firebaseMessaging.requestPermission(alert: true, badge: true, sound: true);

    // add listener for foreground push notifications
    FirebaseMessaging.onMessage.listen((remoteMessage)
    {
      //log('[onMessage] message: $remoteMessage');
      //showNotification(remoteMessage);
    });

    // set listener for push notifications, which will be received when app in background or killed

    String? token;
    if (Platform.isAndroid || kIsWeb) {
      token = await firebaseMessaging.getToken();
    } else if (Platform.isIOS || Platform.isMacOS) {
      token = await firebaseMessaging.getAPNSToken();
    }

    App_Session.myDeviceToken = token.toString();
    print('Device Token: '+token.toString());
    firebaseMessaging.onTokenRefresh.listen((newToken)
    {

    });
  }


/////*******************************************************//////
/////*************     Push Notification helping command ***//////
//////////////////////////////////////////////////////////////////

//// 1. openssl x509 -in cer.cer -inform der -out cer.pem ////
//// 2. openssl pkcs12 -nocerts -out pcer.pem -in pcer.p12 /
//// 3.  /////////cat cer.pem pcer.pem > SimplySocial.pem
//// 4. cd ~/Desktop/                                    /////////
}


