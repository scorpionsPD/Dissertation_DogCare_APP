
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class InterfaceAlertView{
  void alertViewButtonClicked(String buttonName)
  {}
}

// ignore: camel_case_types
class MaasssWidgetHelper
{
  InterfaceAlertView interfaceAlertView = InterfaceAlertView();

  MaasssWidgetHelper(){

  }

  Widget alertViewButtonAndMessage(BuildContext context, String title, String message, String button1Title, String button2Title)
  {
    double containerHeight = 15+25+30+(22*(message.length/25+message.length%25==0?0:1))+30+1+60+9+25;
    return Container(height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: Colors.black38,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Align(
          alignment: Alignment.center,
          child: Container(
            height: containerHeight,
            width: MediaQuery.of(context).size.width-100,
            decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.all(Radius.circular(12))),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 15.0),
                  child: Text(
                    title,
                    style: TextStyle(
                        color: Colors.white, letterSpacing: 1, fontSize: 25,fontWeight: FontWeight.w600),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 30.0),
                  child: Container(
                    width: MediaQuery.of(context).size.width-150,
                    child: Text(
                      message,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.white, letterSpacing: 1, fontSize: 21),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 30.0),
                  child: Column(
                    children: [
                      Container(
                        height: 1,
                        width: MediaQuery.of(context).size.width-100,
                        color: Colors.white,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          GestureDetector(
                              child: Text(
                                button1Title,
                                style: TextStyle(color: Colors.blue,fontSize: 22),
                              ),
                              onTap: () {
                                interfaceAlertView.alertViewButtonClicked(button1Title);
                              }),
                          Container(
                            height: 60,
                            width: 1,
                            color: Colors.white,
                          ),
                          GestureDetector(
                              child: Text(
                                button2Title,
                                style: TextStyle(color: Colors.blue,fontSize: 22),
                              ),
                              onTap: () {
                                interfaceAlertView.alertViewButtonClicked(button2Title);
                              }),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ));
  }
}