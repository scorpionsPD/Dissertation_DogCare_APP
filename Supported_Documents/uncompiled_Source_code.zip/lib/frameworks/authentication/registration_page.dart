import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../main.dart';
import '../engine/app_engine.dart';
import '../engine/app_session.dart';
import '../maasss_helper.dart';
import '../managers/progress_manager.dart';

class Ragistration_page extends StatefulWidget {
  @override
  _StateRagistration_page createState() => _StateRagistration_page();
}

class _StateRagistration_page extends State<Ragistration_page> implements Interface_API_Response_From_Engine_To_UI {

  TextEditingController firstnameTextEdit = TextEditingController();
  TextEditingController lastnameTextEdit = TextEditingController();
  TextEditingController emailTextEdit = TextEditingController();
  TextEditingController passTextEdit = TextEditingController();
  TextEditingController addressTextEdit = TextEditingController();
  TextEditingController userTypeTextEdit = TextEditingController();

  bool _obscureText = true;
  late BuildContext buildContext;
  String dropdownvalue = 'Pet Owner';
  var items = ['Expert','Pet Owner'];

  Register() {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
  }

  @override
  void initState() {
    maasssHelperGetUniqueDeviceID().toString();
    super.initState();
    setState(() {
    });
  }

  @override
  Widget build(BuildContext context) {
    buildContext = context;
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Scaffold(
      resizeToAvoidBottomInset: false,

      body: SafeArea(
        child: SingleChildScrollView(
          reverse: true,
          padding: EdgeInsets.only(bottom: bottom),
          child: Column(
            children: [
              appBar(context),
              imageDog(context),
              listOfSignupForms(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget appBar(BuildContext context){
    return Container(
      color: Color.fromRGBO(90, 53, 190, 1),
      height: 61,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: IconButton(
              icon:
              Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ),
          Text(
            'Registration',
            style: TextStyle(fontSize: 22,color: Colors.white),
          ),

          // Useless code
          Padding(
            padding:
            const EdgeInsets.only(right: 10.0, top: 10),
            child: Container(
              height: 40,
              width: 40,
            ),
          )
        ],
      ),
    );
  }

  Widget imageDog(BuildContext context){
    return Padding(
      padding: const EdgeInsets.only(top: 20.0),
      child: Container(
        height: 180,
        width: 180,
        child:  ClipRRect(
          borderRadius: BorderRadius.all(Radius.circular(25)),
          child: Image.asset('assets/images/finallogo.png',height: 160,width: 160,),),
      ),
    );
  }

  Widget listOfSignupForms(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding:
          const EdgeInsets.only(left: 20.0, right: 20.0,top: 10),
          child: Container(
            height: 50,
            child: TextFormField(
              controller: firstnameTextEdit,
              keyboardType: TextInputType.text,
              validator: (val) {
                return val!.isEmpty
                    ? 'Please enter firstname'
                    : null;
              },
              decoration: InputDecoration(
                labelText: "First Name",
                labelStyle: TextStyle(
                    color: Colors.black),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(
              left: 20.0, right: 20.0),
          child: Stack(
            children: [
              Container(
                height: 50,
                child: TextFormField(
                  controller: lastnameTextEdit,
                  keyboardType: TextInputType.text,
                  validator: (val) {
                    return val!.isEmpty
                        ? 'Please enter last name'
                        : null;
                  },
                  decoration: InputDecoration(
                    labelText: "Last Name",
                    labelStyle:
                    TextStyle(color: Colors.black),
                  ),
                ),
              )],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(
              left: 20.0, right: 20.0),
          child: Stack(
            children: [
              Container(
                height: 50,
                child: TextFormField(
                  controller: emailTextEdit,
                  keyboardType: TextInputType.emailAddress,
                  // obscureText: _obscureText,
                  validator: (val) {
                    return val!.isEmpty ? 'Please enter email' : null;
                  },
                  decoration: InputDecoration(
                    labelText: 'Email Id',
                    labelStyle:
                    TextStyle(color: const Color(0xFF424242)),
                  ),
                ),
              )],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(
              left: 20.0, right: 20.0),
          child: Container(
            height: 50,
            child: TextFormField(
              controller: passTextEdit,
              obscureText: _obscureText,
              inputFormatters: [
                LengthLimitingTextInputFormatter(8)
              ],
              validator: (val) {
                return val!.isEmpty
                    ? 'Please enter password'
                    : null;
              },
              decoration: InputDecoration(
                labelText: 'Password',
                labelStyle:
                TextStyle(color: const Color(0xFF424242),
                ),
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscureText
                        ? Icons.visibility_off
                        : Icons.visibility,
                    color: Colors.grey,
                  ),
                  onPressed: () {
                    setState(() {
                      _obscureText = !_obscureText;
                    });
                  },
                  color: Colors.black,
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(
              left: 20.0, right: 20.0),
          child: Stack(
            children: [
              Container(
                height: 54,
                child: TextFormField(
                  controller: addressTextEdit,
                  //maxLength: 30,
                  inputFormatters: [
                    LengthLimitingTextInputFormatter(30)
                  ],
                  // obscureText: _obscureText,
                  validator: (val) {
                    return val!.isEmpty ? 'Please enter address' : null;
                  },
                  decoration: InputDecoration(
                    labelText: 'Address',
                    labelStyle:
                    TextStyle(color: const Color(0xFF424242)),
                  ),
                ),
              )],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(
              left: 20.0, right: 20.0),
          child: Stack(
            children: [
              Container(
                height: 50,
                child: TextFormField(
                  controller: userTypeTextEdit,
                  readOnly: true,
                  validator: (val) {
                    return val!.isEmpty ? 'Please enter user type' : null;
                  },
                  decoration: InputDecoration(
                    labelText: "User Type",
                    labelStyle: TextStyle(color: Colors.black),
                    suffixIcon: DropdownButton(
                      value: dropdownvalue,

                      icon: Icon(Icons.keyboard_arrow_down),

                      items:items.map((String items) {
                        return DropdownMenuItem(
                            value: items,
                            child: Text(items)
                        );
                      }
                      ).toList(),
                      onChanged: (newValue){
                        setState(() {
                          dropdownvalue = newValue.toString();
                          userTypeTextEdit.text = dropdownvalue;
                        });
                      },

                    ),
                  ),
                ),
              ),

            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(
              top: 15),
          child: InkWell(
            onTap: () {
              registerUserRequest();
            },
            child: Card(
              color: Color.fromRGBO(230, 229, 240, 1),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Container(
                width: 180,
                height: 50,
                child: const Padding(
                  padding: EdgeInsets.only(top: 15.0),
                  child: Text(
                    "Signup",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20.0,
                      color: Color.fromRGBO(90, 53, 190, 1),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void registerUserRequest() async {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    {
      ProgressManager.showAlertDialog(buildContext, "Loading...");

       if (firstnameTextEdit.text.length <= 0) {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, "Please enter firstname.", 3, 1);
      } else if (lastnameTextEdit.text.length <= 0) {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, "Please enter lastname.", 3, 1);
      } else if (emailTextEdit.text.length <= 0) {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, "Please enter email id.", 3, 1);
      } else if (passTextEdit.text.length <= 0 && passTextEdit.text.length<8) {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, "Please enter Password.", 3, 1);
      } else if (addressTextEdit.text.length <= 0) {
         ProgressManager.showAlertDialogWithAutoDismiss(
             buildContext, "Please enter address.", 3, 1);
       } else if (userTypeTextEdit.text.length <= 0) {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, "Please enter user type.", 3, 1);
      }
      else {
        Map<String, dynamic> requestData = new Map<String, dynamic>();
        requestData["firstname"] = firstnameTextEdit.text;
        requestData["lastname"] = lastnameTextEdit.text;
        requestData["email"] = emailTextEdit.text;
        requestData["password"] = passTextEdit.text;
        requestData["address"] = addressTextEdit.text;
        if(dropdownvalue.contains("Expert")) {
          requestData['user_type'] = '2';
        }
        else{
          requestData['user_type'] = '3';
        }
        requestData["device_token"] = App_Session.myDeviceToken;
        requestData["device_id"] = App_Session.myDeviceUniqueId;
        requestData["device_type"] = App_Session.myDeviceType;

        MyApp.appEngine.api_Request(requestData, "", "Registration");
      }
    }
  }

  @override
  Future<void> api_Response_To_UI(
      Map<String, dynamic> responseDictionary, String apiName) async {

    if (apiName.compareTo("Registration") == 0) {
      if (responseDictionary["status"] == '200') {
        Navigator.of(buildContext).pop(true);
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 3, 1);
      }
      else {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 3, 1);
      }
    }
  }

  @override
  void api_Response_Error(String apiName, response) {
  }
}
