import 'dart:async';

import 'package:dogcare/frameworks/authentication/registration_page.dart';
import 'package:dogcare/frameworks/managers/notification_manager.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../../main.dart';
import '../../tabbarcontroler.dart';
import '../engine/app_engine.dart';
import '../engine/app_profile.dart';
import '../engine/app_session.dart';
import '../maasss_helper.dart';
import 'package:http/http.dart' as http;
import '../managers/progress_manager.dart';
import 'forgot_password.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login>
    implements Interface_API_Response_From_Engine_To_UI, InterfaceNotificationReceiver
{
  TextEditingController emailTextEdit = TextEditingController();
  TextEditingController passTextEdit = TextEditingController();

  final formKey = GlobalKey<FormState>();
  late BuildContext buildContext;
  bool _obscureText = false;
  bool isTextFiledFocus = false;
  late String currentDate;
  late Timer surpriseTimer;

  @override
  void initState() {
    var now = DateTime.now();
    var formatterTime = DateFormat('dd-MM-yyyy');
    currentDate = formatterTime.format(now);

    //maasssHelperGetUniqueDeviceID().toString();
    //AppProfile.getDeviceInfo();
    super.initState();
    MyApp.appEngine.hardwareManager.getMyCurrentLocation();
    MyApp.appEngine.notificationManager.initPushNotification();

    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
  }

  @override
  void dispose() {
    super.dispose();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  Login() {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
  }

  @override
  Widget build(BuildContext context) {
    buildContext = context;
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SingleChildScrollView(
        reverse: true,
        padding: EdgeInsets.only(bottom: bottom),
        child: Stack(children: [
          Column(
            children: [
              logo(context),
              logInUser(context),
            ],
          )
        ]),
      ),
    );
  }

  Widget logo(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 30.0, top: 50),
          child: Row(
            children: const [
              Text(
                'Welcome back!',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 30.0,),
          child: Row(
            children: const [
              Text(
                'Login to continue.',
                style: TextStyle(fontSize: 25,color: Colors.grey),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 30.0),
          child: Container(
            height: 190,
            width: 190,
            child:  ClipRRect(
                borderRadius: BorderRadius.all(Radius.circular(25)),
                        child: Image.asset('assets/images/finallogo.png'),),
          ),
        ),
      ],
    );
  }

  Widget logInUser(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 30.0, right: 30),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Form(child: Column(children: [
              Padding(
                padding: const EdgeInsets.only(top: 15),
                child: Stack(
                  children: [
                    Container(
                      child: TextFormField(
                        controller: emailTextEdit,
                        keyboardType: TextInputType.emailAddress,
                        validator: (val) {
                          return val!.isEmpty
                              ? 'Please enter email'
                              : null;
                        },
                        decoration: InputDecoration(
                          labelText: "Email",
                          labelStyle:
                          TextStyle(color: Colors.grey),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Padding(
                padding:
                const EdgeInsets.only(top: 5.0),
                child: Focus(
                  child: Container(
                    height: 50,
                    child: TextFormField(
                      controller: passTextEdit,
                      inputFormatters: [
                        LengthLimitingTextInputFormatter(8)
                      ],
                      obscureText: !_obscureText,
                      validator: (val) {
                        return val!.isEmpty ? 'Please enter password' : null;
                      },
                      decoration: InputDecoration(
                          labelText: "Password",
                          labelStyle: TextStyle(
                            color: Colors.grey,
                          ),
                        suffixIcon: IconButton(
                          icon: Icon(
                            _obscureText
                                ? Icons.visibility
                                : Icons.visibility_off,
                            color: Colors.grey,
                          ),
                          onPressed: () {
                            setState(() {
                              _obscureText = !_obscureText;
                            });
                          },
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ),
                  onFocusChange: (hasFocus) {
                    setState(() {
                      isTextFiledFocus = hasFocus;
                      //_obscureText = !_obscureText;
                    });
                  },
                ),
              ),
            ],),),

            Padding(
              padding: const EdgeInsets.only( top: 5),
              child: Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    GestureDetector(
                        child: Container(
                          width: MediaQuery.of(context).size.width - 80,
                          child: Row(
                            children: const [
                              Padding(
                                padding: EdgeInsets.only(top: 8.0),
                                child: Text(
                                  "Forgot password ?",
                                  style: TextStyle(
                                      color: Color.fromRGBO(142, 223,196, 1),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18),
                                  textAlign: TextAlign.right,
                                ),
                              ),
                            ],
                          ),
                        ),
                        onTap: () {
                          jumpToForgotPassword();
                        }),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: InkWell(
                  onTap: () {
                    loginRequest(emailTextEdit.text, passTextEdit.text);
                      //  (_) => true;
                  },
                  child: Card(
                    color: Color.fromRGBO(90, 53, 190, 1),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: 50,
                      child: const Padding(
                        padding: EdgeInsets.only(top: 15.0),
                        child: Text(
                          "Login",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 20.0,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),

              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 25.0),
              child: InkWell(
                onTap: () {
                  jumpToRegister();
                },
                child: Card(
                  color: Color.fromRGBO(230, 229, 240, 1),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: 50,
                    child: const Padding(
                      padding: EdgeInsets.only(top: 15.0),
                      child: Text(
                        "Create account",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20.0,
                            color: Color.fromRGBO(90, 53, 190, 1),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  void loginRequest(String username, String password) async
  {
   await AppProfile.getDeviceInfo();
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    {
      ProgressManager.showAlertDialog(buildContext, "Loading...");

      if (emailTextEdit.text.length<=0) {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, "Please enter email.", 3, 1);
      } else if (passTextEdit.text.length<=0) {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, "Please enter password.", 3, 1);
      } else {
        Map<String, dynamic> requestData = new Map<String, dynamic>();
        requestData["email"] = emailTextEdit.text;
        requestData["password"] = passTextEdit.text;
        requestData["device_token"] = App_Session.myDeviceToken;
        requestData["device_id"] = App_Session.myDeviceUniqueId;
        requestData["device_type"] = App_Session.myDeviceType;
        requestData["latitude"] = MyApp.appEngine.hardwareManager.myCurrentLatitude.toString();
        requestData["longitude"] = MyApp.appEngine.hardwareManager.myCurrentLongitude.toString();

        MyApp.appEngine.api_Request(requestData, "", "UserLogin");
      }
    }
  }

  @override
  Future<void> api_Response_To_UI(
      Map<String, dynamic> responseDictionary, String apiName) async {
    if (apiName.compareTo("UserLogin") == 0) {
      if (responseDictionary["status"] == '200') {
        App_Session.userId = responseDictionary['user_info']['user_id'].toString();
        App_Session.email = responseDictionary['user_info']['email'].toString();
        App_Session.firstName = responseDictionary['user_info']['firstname'].toString();
        App_Session.lastName = responseDictionary['user_info']['lastname'].toString();
        App_Session.address = responseDictionary['user_info']['address'].toString();
        App_Session.userTypes = responseDictionary['user_info']['user_type'].toString();

        AppProfile.saveDataInInternalMemory();

        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
        //Timer(const Duration(seconds: 1), () {
        //});

        jumpToHome();

      } else {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 2, 1);
      }
    }
  }

  jumpToHome() {
    Navigator.of(buildContext).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => TabBarController()),
        (Route<dynamic> route) => false);
  }

  jumpToForgotPassword() {
    Navigator.push(
        buildContext, MaterialPageRoute(builder: (context) => ForgotPassword()));
  }

  jumpToRegister() {
    Navigator.push(
        buildContext, MaterialPageRoute(builder: (context) => Ragistration_page()));
  }

  @override
  void api_Response_Error(String apiName, response) {}

  @override
  void surpriseNotificationReceived()
  {
    surpriseTimer = Timer.periodic(const Duration(minutes: 1), (_)
    {
      setState(()
      {
        var now = DateTime.now();
        var formatterTime = DateFormat('dd-MM-yyyy');
        currentDate = formatterTime.format(now);
        if(currentDate.contains(App_Session.surpriseDateTime))
        {
          surpriseTimer.cancel();
        }
      });
    });
  }

}
