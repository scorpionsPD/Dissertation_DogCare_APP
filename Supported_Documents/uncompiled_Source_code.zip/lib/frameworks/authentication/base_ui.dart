

import 'package:flutter/cupertino.dart';

// ignore: camel_case_types
class Base_UI extends StatelessWidget
{
  @override
  Widget build(BuildContext context)
  {
    // TODO: implement build
    throw UnimplementedError();
  }

/////////////////////////////////
//     Wedget help             //
/////////////////////////////////
  
}

