import 'package:dogcare/frameworks/engine/app_session.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../main.dart';
import '../engine/app_engine.dart';
import '../managers/progress_manager.dart';
import '../widget_helper.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({Key? key}) : super(key: key);
  @override
  ChangePasswordState createState() => ChangePasswordState();
}

class ChangePasswordState extends State<ChangePassword>implements Interface_API_Response_From_Engine_To_UI,InterfaceAlertView {
  TextEditingController oldPassTextEdit = new TextEditingController();
  TextEditingController newPassTextEdit = new TextEditingController();
  TextEditingController confirmPassTextEdit = new TextEditingController();

  final formKey = GlobalKey<FormState>();
  late BuildContext buildContext;
  bool  yesNoAlertViewFlag = false;

  @override
  void initState() {
    super.initState();

  }

  @override
  Widget build(BuildContext context) {
    buildContext = context;
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Stack(children: [
          SingleChildScrollView(
            reverse: true,
            padding: EdgeInsets.only(bottom: bottom),
            child: Column(children: [
              forgetBackbtn(context),
              forgetLogo(context),
              forgetForm(context),
              forgetResetBtn(context),
            ],
            ),
          ),
          if(yesNoAlertViewFlag)
            MyApp.appEngine.maasssWidgetHelper.alertViewButtonAndMessage(context, 'Change Password', 'Do you want to change your password?', 'Yes', 'No')

        ],)
      ),
    );
  }

  Widget forgetBackbtn(BuildContext context)
  {
    return Container(
      color: Color.fromRGBO(90, 53, 190, 1),
      height: 64,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: IconButton(
              icon:
              Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ),
          Text(
            'Change Password',
            style: TextStyle(fontSize: 22,color: Colors.white),
          ),

          // Useless code
          Padding(
            padding:
            const EdgeInsets.only(right: 10.0, top: 10),
            child: Container(
              height: 40,
              width: 40,
            ),
          )
        ],
      ),
    );

  }

  Widget forgetLogo(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 30.0),
          child: Container(
            height: 190,
            width: 190,
            child:  ClipRRect(
              borderRadius: BorderRadius.all(Radius.circular(25)),
              child: Image.asset('assets/images/finallogo.png'),),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 20,),
          child: Row(
            children: const [
              Text(
                'Change your password?',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25,letterSpacing: 2),
              ),

            ],
          ),
        ),

      ],
    );
  }

  Widget forgetForm(BuildContext context)
  {
    return Column(
      children: [
        Padding(
            padding: const EdgeInsets.only(left: 20.0, right: 20, top: 25),
            child: Container(
              child: TextFormField(
                inputFormatters: [
                  LengthLimitingTextInputFormatter(8)
                ],
                controller: oldPassTextEdit,
                validator: (val) {
                  return val!.isEmpty
                      ? 'Please enter old password'
                      : null;
                },
                decoration: InputDecoration(
                  labelText: "Old Password",
                  labelStyle:
                  TextStyle(color: Colors.grey),
                ),
              ),
            )

        ),
        Padding(
            padding: const EdgeInsets.only(left: 20.0, right: 20,),
            child: Container(
              child: TextFormField(
                inputFormatters: [
                  LengthLimitingTextInputFormatter(8)
                ],
                controller: newPassTextEdit,
                validator: (val) {
                  return val!.isEmpty
                      ? 'Please enter new password'
                      : null;
                },
                decoration: InputDecoration(
                  labelText: "New Password",
                  labelStyle:
                  TextStyle(color: Colors.grey),
                ),
              ),
            )

        ),
        Padding(
            padding: const EdgeInsets.only(left: 20.0, right: 20,),
            child: Container(
              child: TextFormField(
                controller: confirmPassTextEdit,
                inputFormatters: [
                  LengthLimitingTextInputFormatter(8)
                ],
                validator: (val) {
                  return val!.isEmpty
                      ? 'Please enter conform password'
                      : null;
                },
                decoration: InputDecoration(
                  labelText: "Confirm Password",
                  labelStyle:
                  TextStyle(color: Colors.grey),
                ),
              ),
            )

        )

      ],
    );
  }
  Widget forgetResetBtn(BuildContext context)
  {
    return Padding(
      padding: const EdgeInsets.only(top:30.0,left: 20,right: 20),
      child: InkWell(
        onTap: () {
          changePasswordRequest();
        },
        child: Card(
          color: Color.fromRGBO(230, 229, 240, 1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Container(
            width: 180,
            height: 50,
            child: const Padding(
              padding: EdgeInsets.only(top: 15.0),
              child: Text(
                "Change Password",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20.0,
                  color: Color.fromRGBO(90, 53, 190, 1),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  yesNoAlertView(BuildContext context) {
    return showDialog(
      context: buildContext,
      builder: (BuildContext context){
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Align(
            alignment: Alignment.center,
            child: Container(
              height: 150,
              width: 280,
              decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.all(Radius.circular(12))),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 15.0,left: 5),
                    child: Text(
                      'Do you want to change Password?',
                      style: TextStyle(
                          color: Colors.white, fontSize: 19,decoration: TextDecoration.none),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 30),
                    child: Column(
                      children: [
                        Container(
                          height: 1,
                          width: 278,
                          color: Colors.white,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            GestureDetector(
                                child: Text(
                                  "Yes",
                                  style: TextStyle(color: Colors.blue,fontSize: 18,decoration: TextDecoration.none),
                                ),
                                onTap: () {
                                  changePasswordRequest();
                                }
                            ),
                            Container(
                              height:60,
                              width: 1,
                              color: Colors.white,
                            ),
                            GestureDetector(
                                child: Text(
                                  "No",
                                  style: TextStyle(color: Colors.blue,fontSize: 18,decoration: TextDecoration.none),
                                ),
                                onTap: () {
                                  Navigator.of(context).pop();
                                }),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  void alertViewButtonClicked(String buttonName)
  {
    if(buttonName=='Yes'){

      MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
      ProgressManager.showAlertDialog(buildContext, "Loading...");
      Map<String, dynamic> requestData = new Map<String, dynamic>();
      requestData["user_id"] = App_Session.userId;
      requestData["old_password"] = oldPassTextEdit.text;
      requestData["change_password"] = newPassTextEdit.text;
      MyApp.appEngine.api_Request(requestData, "" , "ChangePassword");

      setState(() {
        yesNoAlertViewFlag = false;
      });
    }
    else if(buttonName=='No'){
      setState(() {
        yesNoAlertViewFlag = false;
      });
    }
  }


  void changePasswordRequest() async
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;

    if(oldPassTextEdit.text.isEmpty)
    {
      ProgressManager.showAlertDialogWithAutoDismiss(buildContext, "Please enter old password.",2,0);
    }
    else if(newPassTextEdit.text.isEmpty)
    {
      ProgressManager.showAlertDialogWithAutoDismiss(buildContext, "Please enter new password.",2,0);
    }
    else if(confirmPassTextEdit.text!=newPassTextEdit.text)
    {
      ProgressManager.showAlertDialogWithAutoDismiss(buildContext, "password does not match.",2,0);
      newPassTextEdit.text = '';
      confirmPassTextEdit.text = '';
    }
    else
    {
      MyApp.appEngine.maasssWidgetHelper.interfaceAlertView = this;
      setState(() {
        yesNoAlertViewFlag = true;
      });
    }
  }

  @override
  Future<void> api_Response_To_UI(Map<String, dynamic> responseDictionary, String apiName)
  async {
    if(apiName.compareTo("ChangePassword")==0)
    {
      Navigator.of(buildContext).pop(true);
      if(responseDictionary["status"]=='200')
      {
        //jumpToResetPassword(responseDictionary["otp"]);
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"],2,1);
      }
      else{
        ProgressManager.showAlertDialogWithAutoDismiss(buildContext, responseDictionary["message"],3,1);
      }
    }
  }
  @override
  void api_Response_Error(String apiName, response)
  {
  }
}