import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../main.dart';
import '../engine/app_engine.dart';
import '../managers/progress_manager.dart';
import 'login_page.dart';

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({Key? key}) : super(key: key);
  @override
  ForgotPasswordState createState() => ForgotPasswordState();
}

class ForgotPasswordState extends State<ForgotPassword>implements Interface_API_Response_From_Engine_To_UI {
  TextEditingController emailTextEdit = new TextEditingController();
  final formKey = GlobalKey<FormState>();
  late BuildContext _context;

  @override
  void initState() {
    super.initState();

  }

  ForgotPassword()
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
  }
  jumpToResetPassword(String otpCode)
  {
    Navigator.push(
        _context, MaterialPageRoute(builder: (context) => ResetPassword(otpCode)));
  }

  @override
  Widget build(BuildContext context) {
    _context = context;
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: SingleChildScrollView(
          reverse: true,
          padding: EdgeInsets.only(bottom: bottom),
          child: Column(children: [
            forgetBackbtn(context),
            forgetLogo(context),
            forgetForm(context),
            forgetResetBtn(context),
          ],
          ),
        ),

      ),
    );
  }

  Widget forgetBackbtn(BuildContext context)
  {
    return Container(
      color: Color.fromRGBO(90, 53, 190, 1),
      height: 64,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: IconButton(
              icon:
              Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ),
          Text(
            'Forgot Password',
            style: TextStyle(fontSize: 22,color: Colors.white),
          ),

          // Useless code
          Padding(
            padding:
            const EdgeInsets.only(right: 10.0, top: 10),
            child: Container(
              height: 40,
              width: 40,
            ),
          )
        ],
      ),
    );

  }

  Widget forgetLogo(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 30.0),
          child: Container(
            height: 190,
            width: 190,
            child:  ClipRRect(
              borderRadius: BorderRadius.all(Radius.circular(25)),
              child: Image.asset('assets/images/finallogo.png',),),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 20,),
          child: Row(
            children: const [
              Text(
                'Forgot your password?',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 25,letterSpacing: 2),
              ),

            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 20.0, top: 20,right: 20),
          child: Row(
            children: [
              Text(
                'Please enter your registered email.',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize:18),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget forgetForm(BuildContext context)
  {
    return Padding(
      padding: const EdgeInsets.only(left: 20.0, right: 20, top: 40),
      child: Container(
        child: TextFormField(
          controller: emailTextEdit,
          keyboardType: TextInputType.emailAddress,
          validator: (val) {
            return val!.isEmpty
                ? 'Please enter email'
                : null;
          },
          decoration: InputDecoration(
            labelText: "Email",
            labelStyle:
            TextStyle(color: Colors.grey),
          ),
        ),
      )

    );
  }
  Widget forgetResetBtn(BuildContext context)
  {
    return Padding(
      padding: const EdgeInsets.only(top:35.0,left: 20,right: 20),
      child: InkWell(
          onTap: () {
            forgotPassword();
          },
        child: Card(
          color: Color.fromRGBO(230, 229, 240, 1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Container(
            width: 180,
            height: 50,
            child: const Padding(
              padding: EdgeInsets.only(top: 15.0),
              child: Text(
                "Reset Password",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20.0,
                  color: Color.fromRGBO(90, 53, 190, 1),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void forgotPassword() async
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    ProgressManager.showAlertDialog(_context, "Loading...");

    if(emailTextEdit.text.length <= 0)
    {
      ProgressManager.showAlertDialogWithAutoDismiss(_context, "Please enter registered email.",3,1);
    }
    else {
      Map<String, dynamic> requestData = new Map<String, dynamic>();
      requestData["email"] = emailTextEdit.text;

      MyApp.appEngine.api_Request(requestData, "" , "ForgotPassword");
    }
  }

  @override
  Future<void> api_Response_To_UI(Map<String, dynamic> responseDictionary, String apiName)
  async {
    if(apiName.compareTo("ForgotPassword")==0)
    {
      Navigator.of(_context).pop(true);
      if(responseDictionary["status"]=='200')
      {
        //jumpToResetPassword(responseDictionary["otp"]);
        ProgressManager.showAlertDialog(
            _context, responseDictionary["message"]);
      }
      else{
        ProgressManager.showAlertDialogWithAutoDismiss(context, responseDictionary["message"],3,1);
      }
    }
  }
  @override
  void api_Response_Error(String apiName, response)
  {
  }
}


//Reset Password
class ResetPassword extends StatefulWidget {
  //const ResetPassword({Key? key}) : super(key: key);
  late String otpCode;
  ResetPassword(String otp){
    otpCode = otp;
  }

  @override
  _ResetPasswordState createState() => _ResetPasswordState(otpCode);
}

class _ResetPasswordState extends State<ResetPassword> implements Interface_API_Response_From_Engine_To_UI {
  late String otpCode;
  _ResetPasswordState(String otp){
    otpCode = otp;
  }

  TextEditingController emailTextEdit = new TextEditingController();
  TextEditingController passTextEdit = new TextEditingController();
  TextEditingController conformPassTextEdit = new TextEditingController();
  TextEditingController otpTextEdit = new TextEditingController();
  final formKey = GlobalKey<FormState>();
  late BuildContext _context;
  bool _obscureText = true;

  @override
  void initState() {
    super.initState();
  }

  ResetPassword() {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
  }

  @override
  Widget build(BuildContext context) {
    _context = context;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(children: [
        SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 80.0),
                child: Container(
                  height: 40,
                  child: Text('Reset Password',style: TextStyle(fontSize: 22,),),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20.0, right: 20, ),
                child: TextFormField(
                  controller: emailTextEdit,
                  keyboardType: TextInputType.emailAddress,
                  validator: (val) {
                    return val!.isEmpty ? 'Please enter email' : null;
                  },
                  decoration: InputDecoration(
                    labelText: "Email",
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide(
                        color: Colors.grey,
                        width: 2.0,
                      ),
                    ),
                    suffixIcon: IconButton(
                      icon: Image.asset('assets/images/emailicongrn.png'),
                      onPressed: () {},
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10.0, left: 20, right: 20),
                child: TextFormField(
                  controller: passTextEdit,
                  obscureText: _obscureText,
                  validator: (val) {
                    return val!.isEmpty
                        ? 'Please enter new password'
                        : null;
                  },
                  decoration: InputDecoration(
                    labelText: 'New Password',
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide(
                        color: Colors.grey,
                        width: 2.0,
                      ),
                    ),
                    labelStyle: TextStyle(
                        color: const Color(0xFF424242)
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscureText ? Icons.visibility_off : Icons.visibility,
                        color: Colors.grey,),
                      onPressed: () {
                        setState(() {
                          _obscureText = !_obscureText;
                        });
                      },
                      color: Colors.black,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10.0, left: 20, right: 20),
                child: TextFormField(
                  controller: conformPassTextEdit,
                  obscureText: _obscureText,
                  validator: (val) {
                    return val!.isEmpty
                        ? 'Please enter confirm password'
                        : null;
                  },
                  decoration: InputDecoration(
                    labelText: 'Confirm Password',
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide(
                        color: Colors.grey,
                        width: 2.0,
                      ),
                    ),
                    labelStyle: TextStyle(
                        color: const Color(0xFF424242)
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscureText ? Icons.visibility_off : Icons.visibility,
                        color: Colors.grey,),
                      onPressed: () {
                        setState(() {
                          _obscureText = !_obscureText;
                        });
                      },
                      color: Colors.black,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20.0, right: 20, top: 10),
                child: TextFormField(
                  controller: otpTextEdit,
                  keyboardType: TextInputType.number,
                  validator: (val) {
                    return val!.isEmpty ? 'Please enter received OTP' : null;
                  },
                  decoration: InputDecoration(
                    labelText: "OTP",
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide(
                        color: Colors.grey,
                        width: 2.0,
                      ),
                    ),
                    suffixIcon: IconButton(
                      icon: Image.asset('assets/images/emailicongrn.png'),
                      onPressed: () {},
                    ),
                  ),
                ),
              ),
              InkWell(
                  onTap: () {
                    resetPasswordRequest();
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(top: 15.0),
                    child: Container(
                      width: 220,
                      height: 60,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage('assets/images/loginbtnbg.png'),
                              fit: BoxFit.fill
                          )
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(top: 15.0),
                        child: Text("Reset Password",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 25.0,
                              color: Colors.white,
                              fontFamily: 'astrospaceez2bg'
                          ),
                        ),
                      ),
                    ),
                  )
              ),
            ],
          ),
        )
      ]),
    );
  }

  void resetPasswordRequest() async
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    ProgressManager.showAlertDialog(context, "Loading...");
    if (emailTextEdit.text.isEmpty) {
      ProgressManager.showAlertDialogWithAutoDismiss(
          _context, "Please enter registered email.", 3, 1);
    }
    else if (passTextEdit.text.isEmpty) {
      ProgressManager.showAlertDialogWithAutoDismiss(
          _context, "Please enter new password.", 3, 1);
    }
    else if (otpTextEdit.text.isEmpty) {
      ProgressManager.showAlertDialogWithAutoDismiss(
          context, "Please enter your received otp on email.", 3, 1);
    }
    else {
      if (passTextEdit.text.contains(conformPassTextEdit.text)) {
        if(otpTextEdit.text == otpCode){
          Map<String, dynamic> requestData = new Map<String, dynamic>();
          requestData["email"] = emailTextEdit.text;
          requestData["newpassword"] = passTextEdit.text;

          MyApp.appEngine.api_Request(requestData, "", "ResetPassword_Request");
        }
        else {
          ProgressManager.showAlertDialogWithAutoDismiss(
              _context, "Please enter valid otp.", 3, 1);
        }
      }
      else {
        ProgressManager.showAlertDialogWithAutoDismiss(
            _context, "Password do not match, please try again.", 3, 1);
      }
    }
  }

  @override
  Future<void> api_Response_To_UI(Map<String, dynamic> responseDictionary, String apiName)
  async {
    if(apiName.compareTo("ResetPassword_Request")==0)
    {
      if(responseDictionary["status"]=='200')
      {
        Navigator.of(_context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (context) => Login()),
                (Route<dynamic> route) => false);

        ProgressManager.showAlertDialogWithAutoDismiss(
            _context, responseDictionary["message"],3,1);
      }
      else {
        ProgressManager.showAlertDialogWithAutoDismiss(
            _context, responseDictionary["message"],3,1);
      }
    }
  }
  @override
  void api_Response_Error(String apiName, response)
  {
  }
}

