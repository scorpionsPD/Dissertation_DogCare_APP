import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../engine/app_session.dart';


class UserProfile extends StatefulWidget {
  const UserProfile({Key? key}) : super(key: key);

  @override
  State<UserProfile> createState() => _UserProfileState();
}

class _UserProfileState extends State<UserProfile>
{

  TextEditingController firstnameTextEdit = new TextEditingController();
  TextEditingController lastnameTextEdit = new TextEditingController();
  TextEditingController emailTextEdit = new TextEditingController();
  TextEditingController mobileTextEdit = new TextEditingController();
  TextEditingController dobTextEdit = new TextEditingController();
  TextEditingController genderTextEdit = new TextEditingController();
  TextEditingController eventTextEdit = new TextEditingController();

  bool _obscureText = true;
  bool view = false;
  bool styleOBJ = false;
  bool styleOBJ1 = false;

  String str = "Male";
  String str1 = "Female";
  String gender = 'Male';

  DateTime selectedDate = DateTime.now();

  List<PickedFile> documentList = [];


  bool _decideWhichDayToEnable(DateTime day) {
    if ((day.isAfter(DateTime.now().subtract(Duration(days: 1))) &&
        day.isBefore(DateTime.now().add(Duration(days: 31))))) {
      return true;
    }
    return false;
  }
  _selectDate(BuildContext context) {
    final ThemeData theme = Theme.of(context);
    assert(theme.platform != null);
    switch (theme.platform) {
      case TargetPlatform.android:
      case TargetPlatform.fuchsia:
      case TargetPlatform.linux:
      case TargetPlatform.windows:
        return buildMaterialDatePicker(context);
      case TargetPlatform.iOS:
      case TargetPlatform.macOS:
        return buildCupertinoDatePicker(context);
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              child: Image.asset("assets/images/backgroundimg.png"),
            ),
            Column(
              children: [
                appBar(context),
                userProfileDetail(context),
                Expanded(
                  child: listOfPcForms(context),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
  Widget appBar(BuildContext context)
  {
    return Container(
      height: 64,
      color: Colors.white54,
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Image.asset(
                      'assets/images/backicon.png',
                      height: 30,
                    ),
                  ),
                  onTap: () {
                    Navigator.of(context).pop(false);
                  }),
              Container(
                child: Text(
                  "My Detail",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.black, fontSize: 20),
                ),
              ),
              Container(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset(
                    'assets/images/logoonly.png',
                    height: 35,
                  ),
                ),
              ),

            ],
          ),
          Container(
            height: 3,
            width: MediaQuery.of(context).size.width,
            color: App_Session.appThemeColor,
          ),
        ],
      ),
    );
  }

  Widget userProfileDetail(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      child: Stack(
        children: [
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 10, right: 20,),
                child: documentList.length == 1
                    ? Image.file(File(documentList[0]!.path),height: 105,)
                    : Image.asset('assets/images/profileimgicon.png',height: 105,),
              ),
              InkWell(
                  child: Padding(
                    padding:
                    const EdgeInsets.only(left: 10, right: 20),
                    child: Container(
                      width: 100,
                      height: 35,
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage('assets/images/btnbg.png'),
                          fit: BoxFit.fill,
                        ),
                        //  shape: BoxShape.circle,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(top:10.0),
                        child: Text(
                          "Upload",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 12,
                              color: Colors.white,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                  onTap: () {
                    _showChoiceDialog(context);
                  }),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Padding(
                  padding: const EdgeInsets.only(right: 20.0),
                  child: Container(
                    height: 130,
                    width: MediaQuery.of(context).size.width / 1.5,
                    child: Column(
                      children: [
                        TextFormField(
                          controller: firstnameTextEdit,
                          keyboardType: TextInputType.text,
                          validator: (val) {
                            return val!.isEmpty
                                ? 'Please enter firstname'
                                : null;
                          },
                          decoration: new InputDecoration(
                            labelText: "First Name",
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: BorderSide(
                                color: App_Session.appThemeColor,
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: BorderSide(
                                color: App_Session.appThemeColor,
                                width: 2.0,
                              ),
                            ),
                            labelStyle: new TextStyle(
                              //color: const Color(0xFF424242)
                                color: App_Session.appThemeColor),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top:10.0),
                          child: TextFormField(
                            controller: lastnameTextEdit,
                            keyboardType: TextInputType.text,
                            validator: (val) {
                              return val!.isEmpty
                                  ? 'Please enter last name'
                                  : null;
                            },
                            decoration: InputDecoration(
                              labelText: "Last Name",
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: BorderSide(
                                  color: App_Session.appThemeColor,
                                  width: 2.0,
                                ),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10.0),
                                borderSide: BorderSide(
                                  color: App_Session.appThemeColor,
                                  width: 2.0,
                                ),
                              ),
                              labelStyle: new TextStyle(color: App_Session.appThemeColor),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget listOfPcForms(BuildContext context)
  {
    return Padding(
      padding: const EdgeInsets.only(left: 20, right: 20,),
      child: ListView(
        children: [
          Form(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    top: 10.0,
                  ),
                  child: TextFormField(
                    controller: emailTextEdit,
                    // obscureText: _obscureText,
                    validator: (val) {
                      return val!.isEmpty ? 'Please enter email' : null;
                    },
                    decoration: InputDecoration(
                      labelText: 'email',
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        borderSide: BorderSide(
                          color: App_Session.appThemeColor,
                          width: 2.0,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        borderSide: BorderSide(
                          color: App_Session.appThemeColor,
                          width: 2.0,
                        ),
                      ),
                      labelStyle: new TextStyle(color: App_Session.appThemeColor),
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.only(top: 10.0,),
                  child: Container(
                    child: TextFormField(
                      controller: mobileTextEdit,
                      keyboardType: TextInputType.text,
                      validator: (val) {
                        return val!.isEmpty ? 'Mobile Number' : null;
                      },
                      decoration: new InputDecoration(
                        labelText: "Mobile Number",
                        //  contentPadding: new EdgeInsets.symmetric(vertical: 35.0, horizontal: 10.0),

                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide(
                            width: 2.0,
                            color: App_Session.appThemeColor,
                          ),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                          borderSide: BorderSide(
                            color:App_Session.appThemeColor,
                            width: 2.0,
                          ),
                        ),
                        labelStyle: new TextStyle(color: App_Session.appThemeColor),
                      ),
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: Stack(
                    children: [
                      Container(
                        // height: 55,
                        // width: 195,
                        child: TextFormField(
                          controller: dobTextEdit,
                          keyboardType: TextInputType.text,
                          validator: (val) {
                            return val!.isEmpty ? 'Dob' : null;
                          },
                          decoration: new InputDecoration(
                            labelText: 'Dob',
                            //  contentPadding: new EdgeInsets.symmetric(vertical: 35.0, horizontal: 10.0),

                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: BorderSide(
                                width: 2.0,
                                color: App_Session.appThemeColor,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: BorderSide(
                                color: App_Session.appThemeColor,
                                width: 2.0,
                              ),
                            ),
                            labelStyle: new TextStyle(color: App_Session.appThemeColor,),
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top:3,right:5),
                            child:  Container(
                              width: 115,
                              height: 55,
                              decoration: const BoxDecoration(
                                image: DecorationImage(
                                  image:
                                  AssetImage('assets/images/btnbg.png'),
                                  fit: BoxFit.fill,
                                ),
                                //  shape: BoxShape.circle,
                              ),
                              child: Padding(
                                padding: const EdgeInsets.only(top: 18.0),
                                child: Text(
                                  "CALLENDER",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontSize: 15,
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),


                Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: Stack(
                    children: [
                      Container(
                        // height: 55,
                        // width: 195,
                        child: TextFormField(
                          controller: genderTextEdit,
                          keyboardType: TextInputType.text,
                          validator: (val) {
                            return val!.isEmpty ? 'Gender' : null;
                          },
                          decoration: InputDecoration(
                            labelText: 'Gender',
                            //  contentPadding: new EdgeInsets.symmetric(vertical: 35.0, horizontal: 10.0),

                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: BorderSide(
                                width: 2.0,
                                color: App_Session.appThemeColor,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10.0),
                              borderSide: BorderSide(
                                color: App_Session.appThemeColor,
                                width: 2.0,
                              ),
                            ),
                            labelStyle: TextStyle( color: App_Session.appThemeColor,),
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 10.0),
                            child: InkWell(
                                child: view
                                    ? Image.asset(
                                  'assets/images/femaleicon.png',
                                  width: 100,
                                )
                                    : Image.asset(
                                  'assets/images/maleicon.png',
                                  width: 100,
                                ),
                                onTap: () {
                                  setState(() {
                                    view = !view;
                                    styleOBJ = !styleOBJ;
                                    styleOBJ1 = !styleOBJ1;
                                    if (gender.contains('Female'))
                                      gender = 'Male';
                                    else
                                      gender = 'Female';
                                  });
                                }),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              width: 100,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  Text(
                                    str,
                                    style: styleOBJ1
                                        ? TextStyle(
                                        color: Colors.grey,
                                        fontSize: 13,
                                        fontWeight: FontWeight.bold)
                                        : TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    str1,
                                    style: styleOBJ
                                        ? TextStyle(
                                      color: Colors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold,
                                    )
                                        : TextStyle(
                                      color: Colors.grey,
                                      fontSize: 13,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 10.0),
                      child: Stack(
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width/2.5,
                            child: TextFormField(
                              //    controller: RollTextEdit,
                              keyboardType: TextInputType.text,
                              validator: (val) {
                                return val!.isEmpty ? 'Role' : null;
                              },
                              decoration: new InputDecoration(
                                labelText: "Requester",
                                //  contentPadding: new EdgeInsets.symmetric(vertical: 35.0, horizontal: 10.0),

                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide: BorderSide(
                                    width: 2.0, color: App_Session.appThemeColor,
                                  ),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide: BorderSide(
                                    color: App_Session.appThemeColor,
                                    width: 2.0,
                                  ),
                                ),
                                labelStyle: new TextStyle( color: App_Session.appThemeColor,),
                              ),
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(top:20,left: 115),
                                child: Container(
                                  width: 40,
                                  height:30,
                                  color: Colors.grey,

                                  child: Padding(
                                      padding: const EdgeInsets.only(top: 10.0,left:0),
                                      child: Image.asset("assets/images/downarrowicon.png",height: 30,)
                                  ),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 10.0),
                      child:Stack(
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width/2.5,
                            child: TextFormField(
                              //    controller: RollTextEdit,
                              keyboardType: TextInputType.text,
                              validator: (val) {
                                return val!.isEmpty ? 'status' : null;
                              },
                              decoration: new InputDecoration(
                                labelText: "Active",
                                //  contentPadding: new EdgeInsets.symmetric(vertical: 35.0, horizontal: 10.0),

                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide: BorderSide(
                                    width: 2.0,
                                    color: App_Session.appThemeColor,
                                  ),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                  borderSide: BorderSide(
                                    color: App_Session.appThemeColor,
                                    width: 2.0,
                                  ),
                                ),
                                labelStyle: new TextStyle( color: App_Session.appThemeColor,),
                              ),
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(top:20,left: 115),
                                child: Container(
                                  width: 40,
                                  height:30,
                                  color: Colors.grey,

                                  child: Padding(
                                      padding: const EdgeInsets.only(top: 10.0,left:0),
                                      child: Image.asset("assets/images/downarrowicon.png",height: 30,)
                                  ),
                                ),
                              ),
                            ],
                          ),

                        ],
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top:25.0),
                  child: Container(
                    height: 50,
                    width: 180,

                    child: Card(
                      color: Colors.green,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),

                      child: Padding(
                        padding: const EdgeInsets.only(top: 12.0),
                        child: Text("UPDATE",textAlign: TextAlign.center,style: TextStyle(color: Colors.white,
                            fontSize: 18,letterSpacing: 1,fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          Container(
            height: 250,
          )
        ],
      ),
    );
  }

  buildCupertinoDatePicker(BuildContext context) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext builder) {
          return Container(
            height: MediaQuery.of(context).copyWith().size.height / 8,
            color: Colors.white,
            child: CupertinoDatePicker(
              mode: CupertinoDatePickerMode.date,
              onDateTimeChanged: (picked) {
                if (picked != null && picked != selectedDate)
                  setState(() {
                    selectedDate = picked;
                  });
              },
              initialDateTime: selectedDate,
              minimumYear: 1900,
              maximumYear: 2008,
            ),
          );
        });
  }

  buildMaterialDatePicker(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2025),
      initialEntryMode: DatePickerEntryMode.calendar,
      initialDatePickerMode: DatePickerMode.day,
      selectableDayPredicate: _decideWhichDayToEnable,
      helpText: 'Select date',
      cancelText: 'Not now',
      confirmText: 'Set',
      errorFormatText: 'Enter valid date',
      errorInvalidText: 'Enter date in valid range',
      fieldLabelText: 'Set date',
      fieldHintText: 'Month/Date/Year',
      builder: (context, child) {
        return Theme(
          data: ThemeData.light(), child: child!,
          // child: child,
        );
      },
    );
    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;
      });
  }

  Future<void> _showChoiceDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text(
              "Choose option",
              style: TextStyle(color: Colors.blue),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: [
                  Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      _openGallery(context);
                    },
                    title: Text("Gallery"),
                    leading: Icon(
                      Icons.account_box,
                      color: Colors.blue,
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      _openCamera(context);
                    },
                    title: Text("Camera"),
                    leading: Icon(
                      Icons.camera,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  void _openGallery(BuildContext context) async {
    final pickedFile = await ImagePicker().getImage(
      source: ImageSource.gallery,
    );
    setState(() {
      documentList.clear();
      documentList.add(pickedFile!);
    });

    Navigator.pop(context);
  }

  void _openCamera(BuildContext context) async {
    final pickedFile = await ImagePicker().getImage(
      source: ImageSource.camera,
    );
    setState(() {
      documentList.clear();
      documentList.add(pickedFile!);
    });
    Navigator.pop(context);
  }
}
