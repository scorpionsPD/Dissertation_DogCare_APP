import 'dart:convert';
import 'dart:ffi';
import 'dart:ui';
import 'dart:io' show File, Platform;

//import 'package:audioplayers/audioplayers.dart';
import 'package:device_info/device_info.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_sms/flutter_sms.dart';
import 'package:intl/intl.dart';
import 'package:package_info/package_info.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'engine/app_profile.dart';
import 'engine/app_session.dart';


// 1. Map To JSON
// ignore: non_constant_identifier_names
String maasssHelperMapToJson(Map<String, dynamic> inputData)
{
  String mBody = jsonEncode(inputData);
  return mBody;
}

// 2. JSON to Map
// ignore: non_constant_identifier_names
Map<String, dynamic> maasssHelperJsonToMap(String jsonString)
{
  Map<String, dynamic> dataDic = json.decode(jsonString);
  return dataDic;
}

// 3. JSON to Array List
// ignore: non_constant_identifier_names
List<Map<String, dynamic>> maasssHelperJsonToArrayList(String jsonString)
{
  List<Map<String, dynamic>> dataArray = json.decode(jsonString);
  return dataArray;
}

// 4. Hex String to Color code
// ignore: non_constant_identifier_names
Color maasssHelperHexToColor(String hexString, {String alphaChannel = 'FF'})
{
  return Color(int.parse(hexString.replaceFirst('#', '0x$alphaChannel')));
}

// 5. Set String into shared preference.
// ignore: non_constant_identifier_names
Future<void> maasssHelperSaveInSharedPreference(String key, String value)
async
{
  SharedPreferences mPref = await SharedPreferences.getInstance();
  mPref.setString(key, value);

}

// 6. Get String From shared preference.
// ignore: non_constant_identifier_names
Future<String> maasssHelperGetFromSharedPreference(String key) async
{
  SharedPreferences prefs = await SharedPreferences.getInstance();
  String saveData = prefs.getString(key).toString();
  return saveData;

}

Future<String> maasssHelperGetUniqueDeviceID()
async {
  String deviceName;
  String deviceVersion;
  String identifier = "";
  final DeviceInfoPlugin deviceInfoPlugin = new DeviceInfoPlugin();
  try
  {
    // Create storage
    const storage = FlutterSecureStorage();
    // Read value
    App_Session.myDeviceUniqueId = (await storage.read(key: 'device_id')).toString();

    if (Platform.isIOS)
    {
      var data = await deviceInfoPlugin.iosInfo;
      deviceName = data.name;
      deviceVersion = data.systemVersion;
      identifier = data.identifierForVendor;  //UUID for iOS
      App_Session.myDeviceType = '1';
    }
    else
    {
      var build = await deviceInfoPlugin.androidInfo;
      deviceName = build.model;
      deviceVersion = build.version.toString();
      identifier = build.androidId;  //UUID for Android
      App_Session.myDeviceType = '2';
    }
    if(App_Session.myDeviceUniqueId.length<10)
    {
      App_Session.myDeviceUniqueId= identifier;
      await storage.write(key: "device_id", value: identifier);
    }
  }
  on PlatformException
  {
    if (kDebugMode) {
      print('Failed to get platform version');
    }
  }
  return identifier;
}

Future<String> maasssHelperGetAppVersionInfo()
async {
  String appName;
  String packageName;
  String version = "";
  String buildNumber;

  PackageInfo packageInfo = await PackageInfo.fromPlatform();
  try
  {
    if (Platform.isIOS)
    {
      appName = packageInfo.appName;
      packageName = packageInfo.packageName;
      version = packageInfo.version;
      buildNumber = packageInfo.buildNumber;
    }
    else
    {
      appName = packageInfo.appName;
      packageName = packageInfo.packageName;
      version = packageInfo.version;
      buildNumber = packageInfo.buildNumber;
    }

    App_Session.myAppVersion = version;
  } on PlatformException {
    if (kDebugMode) {
      print('Failed to get platform version');
    }
  }
  return version;
}

Future<File> maasss_Helper_WriteDataInFile(String dataInString, String fileName) async
{
  final path = await _localPath;
  final file = File('$path/$fileName');

  // Write the file
  return file.writeAsString(dataInString);
}

void maasss_Helper_RemoveInternalFile(String fileName) async
{
  final path = await _localPath;
  final file = File('$path/$fileName');

  late File ourFile;
  if(await file.exists())
  {
    await file.delete();
    if (kDebugMode) {
      print("File Deleted");
    }

  }
  else {
    if (kDebugMode) {
      print("File Not Found");
    }
    //readData = 'File Not Found';
  }

}

Future<String> get _localPath async
{
  final directory = await getApplicationDocumentsDirectory();
  return directory.path;
}

Future maasss_Helper_ReadDataFromFile(String fileName) async
{
  try {
    final path = await _localPath;
    final file = File('$path/$fileName');

    // Read the file
    final contents = await file.readAsString();
    AppProfile.internalMemoryDataInString = contents;
    AppProfile.readDataFromInternalMemory();
  } catch (e) {
    // If encountering an error, return 0
    return '';
  }
}



/*
// 7. Play Assets audio files.
// ignore: non_constant_identifier_names
Future<void> maasss_Helper_PlayAssetAudioFilePlayer(String assetFileName)
async {
  /*
    Add 'audioplayers: ^0.19.1' in pubspec.yaml
   */

  AudioPlayer audioPlayer = AudioPlayer(mode: PlayerMode.LOW_LATENCY);
  //AudioPlayer.logEnabled = true;
  AudioCache player = AudioCache(prefix: 'assets/audio/');
  player.play(assetFileName);

}
*/
////////////////////////////////////
/// Date and Time Related Methods///
/// ////////////////////////////////

// 8. Get Current time from current Date in hour and minute.

String maasssHelperChangedDateFormat(String inputDateString, String inputDateFormat, String outputDateFormat)
{
  if(inputDateString.isNotEmpty)
  {
    DateTime parseDate = new DateFormat(inputDateFormat).parse(inputDateString);
    var inputDate = DateTime.parse(parseDate.toString());
    var outputFormat = DateFormat(outputDateFormat);
    var outputDate = outputFormat.format(inputDate);
    return outputDate;
  }
  else{
    return 'Not Available';
  }

}

// 9. Get Current  current Year.
String maasssHelperGetCurrentYear()
{
  var inputDate = DateTime.now();
  var outputFormat = DateFormat('yyyy');
  var outputDate = outputFormat.format(inputDate);
  return outputDate;

}
// 10. Get Current  Time in 24 hour format.
String maasssHelperGetCurrentTimeIn24HourFormat(){
  var inputDate = DateTime.now();
  var outputFormat = DateFormat('HH:mm:ss');
  var outputDate = outputFormat.format(inputDate);
  return outputDate;
}
// 11. Get Current  Time in 12 hour format.
String maasssHelperGetCurrentTimeIn12HourFormat(){
  var inputDate = DateTime.now();
  var outputFormat = DateFormat('hh:mm:ss a');
  var outputDate = outputFormat.format(inputDate);
  return outputDate;
}

// 12. Get Current  Day in name.
String maasssHelperGetCurrentDayInName(){
  var inputDate = DateTime.now();
  var outputFormat = DateFormat('EEEEE', 'en_US');
  var outputDate = outputFormat.format(inputDate);
  return outputDate;
}

// 13. Get Current  Day in number.
String maasssHelperGetCurrentDayInNumber()
{
  var inputDate = DateTime.now();
  var outputFormat = DateFormat('d');
  var outputDate = outputFormat.format(inputDate);
  return outputDate;
}
// 14. Get Current  Month in name.
String maasssHelperGetCurrentMonthInName(){
  var inputDate = DateTime.now();
  var outputFormat = DateFormat('MMMM');
  var outputDate = outputFormat.format(inputDate);
  return outputDate;
}
// 15. Get Current  Month in number.
String maasssHelperGetCurrentMonthInNumber(){
  var inputDate = DateTime.now();
  var outputFormat = DateFormat('M');
  var outputDate = outputFormat.format(inputDate);
  return outputDate;
}

String maasssHelperGetCurrentDateWithGivenFormat(String dateFormat){
  var inputDate = DateTime.now();
  var outputFormat = DateFormat(dateFormat);
  var outputDate = outputFormat.format(inputDate);
  return outputDate;
}

// 16. Get Current  week.
String maasssHelperGetCurrentDayWeek(){
  var inputDate = DateTime.now();
  var outputFormat = DateFormat('E');
  var outputDate = outputFormat.format(inputDate);
  return outputDate;
}
// 17. Get Current  Hour.
String maasssHelperGetCurrentHour(){
  var inputDate = DateTime.now();
  var outputFormat = DateFormat('Hm');
  var outputDate = outputFormat.format(inputDate);
  return outputDate;
}

// 18. Get Current  Date with all component.
String maasssHelperGetCurrentDateWithAllComponent(){
  var inputDate = DateTime.now();
  var outputFormat = DateFormat('dd MMMM yyyy h:mm:ss a');
  var outputDate = outputFormat.format(inputDate);
  return outputDate;
}

// 19. Get past and future date sepcific no of days.

String maasssHelperGetAnyPastOrFutureDate(int numberBeforeToday, bool pastDate)
{
  //dd MMMM yyyy h:mm:ss a
  var currentDate = DateTime.now();
  if(pastDate) {
    var newDate = DateTime(currentDate.year, currentDate.month , currentDate.day - numberBeforeToday);
    var outputFormat = DateFormat('dd MMMM yyyy h:mm:ss a');
    var outputDate = outputFormat.format(newDate);
    return outputDate;
  }
  else{
    var newDate = DateTime(currentDate.year, currentDate.month , currentDate.day + numberBeforeToday);
    var outputFormat = DateFormat('dd MMMM yyyy h:mm:ss a');
    var outputDate = outputFormat.format(newDate);
    return outputDate;
  }

}

// 20. Get date with past and future with specific days.

String maasssHelperGetAnyPastOrFutureManualDate(String inputDateString, String inputDateFormat, int numberBeforeToday, bool pastDate)
{
  //dd MMMM yyyy h:mm:ss a
  DateTime parseDate = DateFormat(inputDateFormat).parse(inputDateString);
  var inputDate = DateTime.parse(parseDate.toString());
  if(pastDate) {
    var newDate = DateTime(parseDate.year, parseDate.month , parseDate.day - numberBeforeToday);
    var outputFormat = DateFormat('dd MMMM yyyy h:mm:ss a');
    var outputDate = outputFormat.format(newDate);
    return outputDate;
  }
  else{
    var newDate = DateTime(parseDate.year, parseDate.month , parseDate.day + numberBeforeToday);
    var outputFormat = DateFormat('dd MMMM yyyy h:mm:ss a');
    var outputDate = outputFormat.format(newDate);
    return outputDate;
  }

}

// 20. Get current time in seconds.

String maasssHelperGetCurrentDateTimeInMiliseconds(){
  var inputDate = DateTime.now().microsecondsSinceEpoch;
  var outputDate = inputDate.toString();
  return outputDate;
}

// 21 get UTC Date Time
String maasssHelperGetDateTimeUTC(){
  var inputDate = DateTime.now().toUtc();
  var outputFormat = DateFormat('dd MMMM yyyy h:mm:ss a');
  var outputDate = outputFormat.format(inputDate);
  return outputDate;
}
///check email validation
bool maasssHelperValidateEmailID(String emailString)
{
  String emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
  if(!RegExp(emailRegEx).hasMatch(emailString)) {

    return false;
  }
  else{
    return true;
  }

}

///check number validation
bool maasssHelperValidateNumber(String numString)
{
  String numberRegEx = "[0-9]{10}";
  if(!RegExp(numberRegEx).hasMatch(numString)) {

    return false;
  }
  else{
    return true;
  }

}

///check number validation
bool maasssHelperValidateAge(String ageString)
{
  String numberRegEx = "[0-9]{2}";
  if(!RegExp(numberRegEx).hasMatch(ageString)) {

    return false;
  }
  else{
    return true;
  }

}

///Default Direct Call Method
Future<void> maasssHelperDefaultPhoneDirectCall(String number)
async {
  await FlutterPhoneDirectCaller.callNumber(number);
}

///Default Direct Call Method
Future<void> maasssHelperDefaultPhoneIndirectCall(String number)
async {
  launch('tel://$number');
}

///Default SMS Send By Mobile
Future<void> maasssHelperDefaultSmsSendByMobile(String sms, recipients )
async {
  String sendResult = await sendSMS(message: sms, recipients: recipients )
      .catchError((err) {
    // print(err);
  });
  if (kDebugMode) {
    print(sendResult);
  }
}

///Default SMS Send Email by Mobile
Future<bool> maasssHelperDefaultEmailSendByMobile(String email, String subject,String body)
async {
  String? encodeQueryParameters(Map<String, String> params) {
    return params.entries
        .map((e) => '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}')
        .join('&');
  }

  final Uri emailUri = Uri(
    scheme: 'mailto',
    path: email,
    query: encodeQueryParameters(
        <String, String>{'subject': subject,'body': body}),
  );
  if(await canLaunch(emailUri.toString())){
    launch(emailUri.toString());
    return true;
  }else
  {
    return false;
    // print("The action is not supported. (No Email App)");
  }
}

///Open URl in Browser
Future<void> maasssHelperOpenUrlInBrowser(String url)
async {
  if(await canLaunch(url)){
    await launch(url, forceSafariVC: false);
  }
  else {
    if (kDebugMode) {
      print("The action is not supported. (No browser app)");
    }
  }
}

///Open URl in App
Future<void> maasssHelperOpenUrlInApp(String url)
async {
  if(await canLaunch(url)){
    await launch(
      url,
      forceSafariVC: true,
      forceWebView: true,
      enableJavaScript: true,
      enableDomStorage: true,
      webOnlyWindowName: '_self',
    );
  }
  else {
    print("The action is not supported. (No broser app)");
  }
}

///Open Default map app using  address
Future<void> maasssHelperDefaultMapWithAddress(String address)
async {
  final String googleMapsUrl = "http://maps.google.com/?q=$address";
  // final String appleMapsUrl = "http://maps.apple.com/?q=$address";

  if(await canLaunch(googleMapsUrl)){
    await launch(googleMapsUrl);
  }
  // if(await canLaunch(appleMapsUrl)){
  //   await launch(appleMapsUrl);
  // }
  else {
    throw "Could not Launch URL ";

  }
}

///Open Default map app using Lat long
Future<void> maasssHelperDefaultMapWithLatAndLong(String lat, String lng)
async {
  final String googleMapsUrl = "http://maps.google.com/maps?q=$lat,$lng";
  // final String appleMapsUrl = "http://maps.apple.com/maps?q=$lat,$lng";

  if(await canLaunch(googleMapsUrl)){
    await launch(googleMapsUrl);
  }
  // if(await canLaunch(appleMapsUrl)){
  //   await launch(appleMapsUrl);
  // }
  else {
    throw "Could not Launch URL ";

  }
}

///Direction on map between two place
Future<void> maasssHelperDefaultSafariAppWithDirectionBetweenTwoPlace(String daddress, String saddress)
async {
  final String urlTextfullpath = "http://maps.google.com/?daddr=${daddress}&saddr=${saddress}";
  String urlText = urlTextfullpath.replaceAll(' ','+');

  if(await canLaunch(urlText)){
    await launch(urlText);
  }
  else {
    throw "Could not Launch URL ";

  }
}

///Default Callender app
Future<void> maasssHelperDefaultCalenderApp()
async {
  const String googleCallenderUrl = "content://com.android.calendar/time/";
  const String appleCallenderUrl = "calshow://";

  if(await canLaunch(googleCallenderUrl)){
    await launch(googleCallenderUrl);
  }
  if(await canLaunch(appleCallenderUrl)){
    await launch(appleCallenderUrl);
  }
  else {
    throw "Could not Launch URL ";

  }
}



