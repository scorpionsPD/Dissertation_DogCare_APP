

String userTypePetUser = '3';
String userTypePetExpert = '2';
String levelsInfoForMarque = '0 = never, 1 = rarely, 2 = sometimes, 3 = very often.  ';
String textServer = 'http://159.203.183.64/Live/API/CorePHPAPIS/';
String liveServer = 'http://159.203.183.64/Live/API/CorePHPAPIS/';
String applyServer = textServer;