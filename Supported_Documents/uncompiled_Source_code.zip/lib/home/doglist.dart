import 'dart:async';

import 'package:dogcare/frameworks/engine/app_engine.dart';
import 'package:dogcare/home/createpet.dart';
import 'package:dogcare/home/dogdetail.dart';
import 'package:dogcare/settings/userinfo.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../frameworks/engine/app_session.dart';
import '../frameworks/managers/progress_manager.dart';
import '../main.dart';

class DogList extends StatefulWidget {
  const DogList({Key? key}) : super(key: key);

  @override
  State<DogList> createState() => _DogListState();
}

class _DogListState extends State<DogList>
    implements Interface_API_Response_From_Engine_To_UI {
  List dogListViewArray = [];
  late BuildContext buildContext;

  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 500), () async {
      dogNameListRequest();
    });
  }


  @override
  Widget build(BuildContext context) {
    buildContext = context;
    return Scaffold(
      body: SafeArea(
          child: Container(
        color: Color.fromRGBO(81, 81, 198, 1),
        child: Stack(
          children: [
            Container(
              color: Color.fromRGBO(81, 81, 198, 1),
              height: 150,
              width: MediaQuery.of(context).size.width,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(right: 30,top: 30),
                    child: Container(
                        child: Image.asset(
                      'assets/images/finallogo.png',
                    )),
                  ),
                ],
              ),
            ),
            Center(
              child: Container(
                margin: EdgeInsets.only(left: 15, top: 155),
                width: MediaQuery.of(context).size.width,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    GestureDetector(
                      child: Text(
                        'Welcome '+App_Session.firstName,
                        style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold, color: Color.fromRGBO(88, 148, 239, 1)),
                      ),
                      onTap: (){
                        Navigator.push(
                            context, MaterialPageRoute(builder: (context) => UserInfo()));
                      },
                    ),
                    Row(
                      children: [
                        Center(
                          child: Container(
                            margin: EdgeInsets.only(),
                            height: 70,
                            width: 178,
                            child: Text(
                              'Add/Select pet to see details and track symptoms',
                              style: TextStyle(fontSize: 18, color: Colors.white),
                              textAlign: TextAlign.start,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

          ],
        ),
      )),
      floatingActionButton: FloatingActionButton(
        //Floating action button on Scaffold
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => CreatePet()));
        },
        child: Icon(
          Icons.add,
          color: Colors.white,
        ), //icon inside button
      ),

      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      //floating action button position to center

      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Color.fromRGBO(81, 81, 198, 1),
        ),
        child: BottomAppBar(
            //bottom navigation bar on scaffold
            //color:Colors.white,
            shape: CircularNotchedRectangle(),
            //shape of notch
            notchMargin: 10,
            //notche margin between floating button and bottom appbar
            child: Container(
              margin: EdgeInsets.only(top: 40),
              height: MediaQuery.of(context).size.width - 50,
              width: MediaQuery.of(context).size.width,
              color: Colors.transparent,
              child: dogNameListView(context),
            )),
      ),
    );
  }

  Widget dogNameListView(BuildContext context) {
    return ListView.builder(
      itemCount: dogListViewArray.length,
      itemBuilder: adapter,
    );
  }

  Widget adapter(BuildContext context, int index) {
    return Stack(
      children: [
        GestureDetector(
          child: Padding(
            padding: const EdgeInsets.only(left: 15.0, right: 15),
            child: Card(
              elevation: 10,
              shadowColor: Colors.grey,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    height: 70,
                    width: 130,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 18.0, left: 5),
                          child: Text(dogListViewArray[index]['pat_name'],
                              style: TextStyle(fontSize: 20)),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 5),
                          child: Row(
                            children: [
                              Text(
                                'Breed :',
                                style: TextStyle(fontSize: 14),
                              ),
                              Text(
                                dogListViewArray[index]['pat_breed'],
                                style: TextStyle(fontSize: 14),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                      height: 80,
                      child: Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(top: 40.0),
                            child: Text(
                              dateDifference(dogListViewArray[index]['age']),
                              style: TextStyle(fontSize: 18),
                            ),
                          ),
                          /* Container(
                            margin: EdgeInsets.only(left: 5,),
                              decoration: BoxDecoration(
                                shape: BoxShape.rectangle,
                                borderRadius: BorderRadius.only(topRight: Radius.circular(10),bottomRight: Radius.circular(10)),
                                ),

                              child: Image.network('http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/uploads/pets/'+'/'+getSinglePetImage(dogListViewArray[index]['pet_images']),height: 80,width: 100, fit: BoxFit.fitWidth,))*/
                          ClipRRect(
                           borderRadius: BorderRadius.only(topRight: Radius.circular(10),bottomRight: Radius.circular(10)),
                            child: Image.network('http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/uploads/pets/'+'/'+ MyApp.appEngine.getSinglePetImage(dogListViewArray[index]['pet_images']),height: 80,width: 100, fit: BoxFit.fill,))

                        ],
                      )),
                ],
              ),
            ),
          ),
          onTap: () {
            DogDetail dogDetail = DogDetail();
            dogDetail.petDetail = dogListViewArray[index];
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => dogDetail));
          },
        )
      ],
    );
  }

  String dateDifference(String dob) {
    String age = '';

    List dobDateIndex = dob.split('-');
    int dobYear = int.parse(dobDateIndex[0].toString());
    int dobMonth = int.parse(dobDateIndex[1].toString());
    int dobDay = int.parse(dobDateIndex[2].toString());

    String currentDateString = DateFormat('yyyy-MM-dd').format(DateTime.now());
    List currentDateIndex = currentDateString.split('-');

    int currentYear = int.parse(currentDateIndex[0].toString());
    int currentMonth = int.parse(currentDateIndex[1].toString());
    int currentDay = int.parse(currentDateIndex[2].toString());

    DateTime dobDate = DateTime(dobYear, dobMonth, dobDay);
    DateTime currentDate = DateTime(currentYear, currentMonth, currentDay);
    int totalDays = currentDate.difference(dobDate).inDays;
    int years = totalDays ~/ 365;
    double monthInYear = 0;
    if(years>0){

    }
    int months = (totalDays-years*365) ~/ 30;
    if(months>0){
      monthInYear = months/12;
    }
    int days = totalDays-years*365-months*30;
    if(days>0 && years == 0 && months==0){
      return days.toString() + ' Days ';
    }
    if (kDebugMode) {
      print("$years $months $days $totalDays");
    }
    double netAge = years+monthInYear;
    netAge =  double.parse((netAge). toStringAsFixed(2));

    return netAge.toString() + ' Year ';

  }


  void dogNameListRequest() async {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    {
      ProgressManager.showAlertDialog(buildContext, "Loading...");
      Map<String, dynamic> requestData = Map<String, dynamic>();

      requestData["user_id"] = App_Session.userId;

      MyApp.appEngine.api_Request(requestData, "", "FetchAllPetByUser");
    }
  }

  @override
  Future<void> api_Response_To_UI(
      Map<String, dynamic> responseDictionary, String apiName) async {
    if (apiName.compareTo("FetchAllPetByUser") == 0) {
      if (responseDictionary['status'] == '200') {
        setState(() {
          dogListViewArray = responseDictionary['data'];
          App_Session.numberOfDogs = int.parse(dogListViewArray.length.toString());
        });
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
      } else {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
      }
    }
  }

  @override
  void api_Response_Error(String apiName, response) {}
}
