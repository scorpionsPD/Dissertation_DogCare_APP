import 'dart:io';
import 'package:dogcare/frameworks/engine/app_session.dart';
import 'package:dogcare/home/doglist.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import '../frameworks/engine/app_engine.dart';
import '../frameworks/engine/app_profile.dart';
import '../frameworks/managers/progress_manager.dart';
import '../frameworks/widget_helper.dart';
import '../main.dart';

class CreatePet extends StatefulWidget {
  const CreatePet({Key? key}) : super(key: key);

  @override
  State<CreatePet> createState() => _CreatePetState();
}

class _CreatePetState extends State<CreatePet>
    implements Interface_API_Response_From_Engine_To_UI, InterfaceAlertView {
  late BuildContext buildContext;
  TextEditingController petnameTextEdit = new TextEditingController();
  TextEditingController breedTextEdit = new TextEditingController();
  TextEditingController sexTextEdit = new TextEditingController();
  TextEditingController ageTextEdit = new TextEditingController();
  TextEditingController weightTextEdit = new TextEditingController();
  TextEditingController healthTextEdit = new TextEditingController();
  String dropdownvalue = 'Male';
  var items = ['Male', 'Female'];
  List<PickedFile> hospitalImageDetailArray = [];
  int deletedImageIndex = -1;

  bool yesNoAlertViewFlag = false;

  DateTime selectedDate = DateTime.now();

  Future<DateTime> _selectDate(BuildContext context) async {
    final selected = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    if (selected != null && selected != selectedDate) {
      setState(() {
        selectedDate = selected;
        ageTextEdit.text = DateFormat('dd-MM-yyyy').format(selected);
      });
    }
    return selectedDate;
  }

  String getDate() {
    if (selectedDate == null) {
      return 'select date';
    } else {
      setState(() {});
      return DateFormat('dd-MM-yyyy').format(selectedDate);
    }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    buildContext = context;
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Scaffold(
        resizeToAvoidBottomInset: false,
        body: SafeArea(
          child: Stack(children: [
            Column(
              children: [
                Container(
                  color: Color.fromRGBO(90, 53, 190, 1),
                  height: 64,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        child: IconButton(
                          icon: Icon(Icons.arrow_back, color: Colors.white),
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                      ),
                      Text(
                        'Create Pet',
                        style: TextStyle(fontSize: 22, color: Colors.white),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 10.0, top: 10),
                        child: Container(
                          height: 40,
                          width: 40,
                        ),
                      )
                    ],
                  ),
                ),
                SingleChildScrollView(
                  reverse: true,
                  padding: EdgeInsets.only(bottom: bottom),
                  child:Column(
                    children: [
                      if(hospitalImageDetailArray.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 10),

                        child: Container(
                          height: 90,
                          width: MediaQuery.of(context).size.width - 20,
                          decoration: const BoxDecoration(
                              shape: BoxShape.rectangle,
                             // color: Colors.pink,
                              borderRadius:
                              BorderRadius.all(Radius.circular(10))),
                          child: Stack(
                            children: [
                              petImageDetailListView(context),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Center(
                                      child: Image.asset(
                                        'assets/images/foricon.png',
                                        height: 35,
                                      )),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                     /* Align(
                        alignment: Alignment.topRight,
                        child: GestureDetector(
                          child: Container(
                            height: 60,
                            width: 180,
                            decoration: const BoxDecoration(
                                image: DecorationImage(
                                    image: AssetImage(
                                      "assets/images/addhospitalicon.png",
                                    ),
                                    fit: BoxFit.contain)),
                            child: const Padding(
                              padding: EdgeInsets.only(left: 35.0, top: 17),
                              child: Text(
                                '+ Add Photo',
                                style:
                                TextStyle(fontSize: 20, color: Colors.white),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ),
                          onTap: () {
                            _showCameraDialog(context);
                          },
                        ),
                      ),*/
                      Padding(
                        padding: const EdgeInsets.only(right: 8.0,top: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            InkWell(
                              onTap: () {
                                _showCameraDialog(context);
                              },
                              child: Card(
                                color: Color.fromRGBO(230, 229, 240, 1),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                child: Container(
                                  width: 160,
                                  height: 40,
                                  child: Center(
                                    child: Text(
                                      "Add Picture",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 20.0,
                                        color: Color.fromRGBO(90, 53, 190, 1),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      Container(
                        height: MediaQuery.of(context).size.height - 303,
                        child: Column(
                          children: [
                            Padding(
                              padding:
                              const EdgeInsets.only(left: 20.0, right: 20.0),
                              child: Container(
                                child: TextFormField(
                                  controller: petnameTextEdit,
                                  keyboardType: TextInputType.text,
                                  validator: (val) {
                                    return val!.isEmpty
                                        ? 'Please enter petname'
                                        : null;
                                  },
                                  decoration: InputDecoration(
                                    labelText: "Petname",
                                    labelStyle:
                                    TextStyle(color: Colors.black),
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                left: 20.0,
                                right: 20.0,
                              ),
                              child: TextFormField(
                                controller: breedTextEdit,
                                keyboardType: TextInputType.text,
                                validator: (val) {
                                  return val!.isEmpty
                                      ? 'Please enter breed'
                                      : null;
                                },
                                decoration: InputDecoration(
                                  labelText: "Breed",
                                  labelStyle: TextStyle(color: Colors.black),
                                ),
                              ),
                            ),
                            Padding(
                              padding:
                              const EdgeInsets.only(left: 20.0, right: 20.0),
                              child: Stack(
                                children: [
                                  Container(
                                    child: TextFormField(
                                      controller: sexTextEdit,
                                      readOnly: true,
                                      validator: (val) {
                                        return val!.isEmpty
                                            ? 'Please enter sex'
                                            : null;
                                      },
                                      decoration: InputDecoration(
                                        labelText: "Sex",
                                        labelStyle:
                                        TextStyle(color: Colors.black),
                                        suffixIcon: DropdownButton(
                                          value: dropdownvalue,
                                          icon: Icon(Icons.keyboard_arrow_down),
                                          items: items.map((String items) {
                                            return DropdownMenuItem(
                                                value: items, child: Text(items));
                                          }).toList(),
                                          onChanged: (newValue) {
                                            setState(() {
                                              dropdownvalue = newValue.toString();
                                              sexTextEdit.text = dropdownvalue;
                                            });
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                              const EdgeInsets.only(left: 20.0, right: 20.0),
                              child: Stack(
                                children: [
                                  TextFormField(
                                    controller: ageTextEdit,
                                    readOnly: true,
                                    validator: (val) {
                                      return val!.isEmpty
                                          ? 'Please enter age'
                                          : null;
                                    },
                                    decoration: InputDecoration(
                                        labelText: 'Date of birth',
                                        labelStyle: TextStyle(
                                            color: const Color(0xFF424242)),
                                        suffixIcon: IconButton(
                                          icon: Icon(Icons.calendar_today),
                                          onPressed: () {},
                                        )),
                                  ),
                                  GestureDetector(
                                    child: Container(
                                      height: 60,
                                      width: MediaQuery.of(context).size.width,
                                      color: Colors.transparent,
                                    ),
                                    onTap: () {
                                      setState(() {
                                        _selectDate(context);
                                        getDate();
                                      });
                                    },
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                              const EdgeInsets.only(left: 20.0, right: 20.0),
                              child: Stack(
                                children: [
                                  Container(
                                    child: TextFormField(
                                      controller: weightTextEdit,
                                      // obscureText: _obscureText,
                                      validator: (val) {
                                        return val!.isEmpty
                                            ? 'Please enter weight'
                                            : null;
                                      },
                                      decoration: InputDecoration(
                                        labelText: 'Weight In Kg',
                                        labelStyle: TextStyle(
                                            color: const Color(0xFF424242)),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                              const EdgeInsets.only(left: 20.0, right: 20.0),
                              child: Stack(
                                children: [
                                  Container(
                                    child: TextFormField(
                                      controller: healthTextEdit,
                                      validator: (val) {
                                        return val!.isEmpty
                                            ? 'Please enter health'
                                            : null;
                                      },
                                      decoration: InputDecoration(
                                        labelText: "Health",
                                        labelStyle:
                                        TextStyle(color: Colors.black),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: InkWell(
                                onTap: () {
                                  createPetRequest();
                                },
                                child: Card(
                                  color: Color.fromRGBO(230, 229, 240, 1),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  child: Container(
                                    width: 180,
                                    height: 50,
                                    child: const Padding(
                                      padding: EdgeInsets.only(top: 15.0),
                                      child: Text(
                                        "Create",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontSize: 20.0,
                                          color: Color.fromRGBO(90, 53, 190, 1),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ) ,
                ),
              ],
            ),
            if(yesNoAlertViewFlag)
              MyApp.appEngine.maasssWidgetHelper.alertViewButtonAndMessage(context, 'Create Pet', 'Do you want to create this pet?', 'Yes', 'No')
          ],
          )
        )
    );
  }

  Widget petImageDetailListView(BuildContext context) {
    return ListView.builder(
      itemCount: hospitalImageDetailArray.length,
      scrollDirection: Axis.horizontal,
      itemBuilder: adapter,
    );
  }

  Widget adapter(BuildContext context, int index) {
    return Stack(
      children: [
        Container(
          height: 90,
          width: 130,
          decoration: BoxDecoration(shape: BoxShape.circle),
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: GestureDetector(
              child: hospitalImageDetailArray.length>0?Image.file(
                File(hospitalImageDetailArray[index].path), fit: BoxFit.cover):const Text("Take your dog photos.",style: TextStyle(fontSize: 24.0),),
            ),
          ),
        ),
        Positioned(
          top: -8,
          right: -8,
          child: IconButton(
              icon: Icon(
                Icons.cancel,
                color: Colors.red,
              ),
              onPressed: () {
                _showImageDeleteAlertDialog(context);
                deletedImageIndex = index;
              }),
        )
      ],
    );
  }

  _showCameraDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(
              "Choose option",
              style: TextStyle(color: Colors.blue),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: [
                  Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      _openGallery(context);
                    },
                    title: Text("Gallery"),
                    leading: Icon(
                      Icons.account_box,
                      color: Colors.blue,
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      _openCamera(context);
                    },
                    title: Text("Camera"),
                    leading: Icon(
                      Icons.camera,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  void _openGallery(BuildContext context) async {
    final pickedFileGallery = await ImagePicker().getImage(
      source: ImageSource.gallery,
    );
    setState(() {
      hospitalImageDetailArray.add(pickedFileGallery!);
    });
  }

  void _openCamera(BuildContext context) async {
    final pickedFileCamera = await ImagePicker().getImage(
      source: ImageSource.camera,
    );
    setState(() {
      hospitalImageDetailArray.add(pickedFileCamera!);
    });
  }

  Future<void> _showImageDeleteAlertDialog(BuildContext context)
  {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(
              "Are you sure you want to delete?",
              style: TextStyle(color: Colors.blue),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: [
                  Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      setState(() {
                        hospitalImageDetailArray.removeAt(deletedImageIndex);
                        Navigator.of(context).pop();
                      });
                    },
                    title: Text("Delete"),
                    leading: Icon(
                      Icons.delete,
                      color: Colors.blue,
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      Navigator.of(context).pop();
                      deletedImageIndex = -1;
                    },
                    title: Text("Cancel"),
                    leading: Icon(
                      Icons.cancel,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  void createPetRequest()
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    {
      //ageTextEdit.text = '2022-07-26';
      //ProgressManager.showAlertDialog(buildContext, "");
      if (petnameTextEdit.text.isEmpty) {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, "Please enter petname.", 1, 0);
      } else if (breedTextEdit.text.isEmpty) {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, "Please enter breed.", 1, 0);
      } else if (sexTextEdit.text.isEmpty) {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, "Please enter sex.", 1, 0);
      } else if (ageTextEdit.text.isEmpty) {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, "Please enter age.", 1, 0);
      } else if (weightTextEdit.text.isEmpty) {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, "Please enter weight.", 1, 0);
      } else if (healthTextEdit.text.isEmpty) {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, "Please enter health status.", 1, 0);
      } else if (hospitalImageDetailArray.isEmpty) {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, "Please take one photo.", 1, 0);
      }
      else {
        setState(() {
          MyApp.appEngine.maasssWidgetHelper.interfaceAlertView = this;
          yesNoAlertViewFlag = true;
        });
      }
    }
  }

  Future<void> createPetRequestMethod()
  async {
    ProgressManager.showAlertDialog(buildContext, "Loading...");
    Map<String, dynamic> requestData = <String, dynamic>{};
    requestData["petname"] = petnameTextEdit.text;
    requestData["breed"] = breedTextEdit.text;
    requestData["sex"] = sexTextEdit.text;
    requestData["age"] = DateFormat('yyyy-MM-dd').format(selectedDate);
    requestData["weight"] = weightTextEdit.text;
    requestData["health"] = healthTextEdit.text;
    requestData["date_acquired"] = "2022-07-21";
    requestData["user_id"] = App_Session.userId;

    File zipFilepath =
        await AppProfile.createZipOfFiles(hospitalImageDetailArray);

    List<int> fileBytes = zipFilepath.readAsBytesSync();
    MyApp.appEngine.apiRequestForFileUpload(
        zipFilepath.path, requestData, 'CreatePet', fileBytes);
  }

  @override
  void alertViewButtonClicked(String buttonName)
  {
      if(buttonName=='Yes'){
        createPetRequestMethod();
        setState(() {
          yesNoAlertViewFlag = false;
        });
      }
      else if(buttonName=='No'){
        setState(() {
          yesNoAlertViewFlag = false;
        });
      }
  }

  @override
  Future<void> api_Response_To_UI(
      Map<String, dynamic> responseDictionary, String apiName) async {
    if (apiName.compareTo("CreatePet") == 0) {
      if (responseDictionary["status"] == '200') {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, 'Pet successfully created.', 2, 1);
        jumpToHome();
      } else {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 2, 1);
      }
    }
  }

  @override
  void api_Response_Error(String apiName, response) {}

  jumpToHome() {
    Navigator.of(buildContext).pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => DogList()),
        (Route<dynamic> route) => false);
  }
}
