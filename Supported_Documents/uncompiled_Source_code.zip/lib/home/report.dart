import 'dart:async';
import 'dart:math';
import 'dart:ui' as ui;

import 'package:dogcare/frameworks/maasss_helper.dart';
import 'package:dogcare/frameworks/managers/progress_manager.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';

import 'dart:ui' as ui;
import 'dart:typed_data';
import '../main.dart';

class Report extends StatefulWidget
{
  var petDetail = Map<String, dynamic>();
  String conclusionResultMessage = '';
  List dogSymptomsArray = [];

  @override
  State<Report> createState() => _ReportState();
}

class _ReportState extends State<Report>
{
  String todayDate = '';
  String serialNumber = '';
  late BuildContext buildContext;
  final GlobalKey globalKey = GlobalKey();

  @override
  void initState()
  {
    super.initState();
    todayDate = maasssHelperGetCurrentDateWithGivenFormat('dd-MM-yyyy');
    Random rnd;
    int min = 1000;
    int max = 9999;
    rnd = new Random();
    int r = min + rnd.nextInt(max - min);
    serialNumber = r.toString();

    for(int i=0;i<widget.dogSymptomsArray.length;i++)
    {

    }
  }

  @override
  Widget build(BuildContext context)
  {
    buildContext = context;
    return Scaffold(
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            /*Padding(
              padding: const EdgeInsets.only(top: 5, left: 10),
              child: InkWell(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Report()));
                },
                child: Card(
                  color: Color.fromRGBO(230, 229, 240, 1),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Container(
                    width: 140,
                    height: 40,
                    child: Center(
                      child: Text(
                        "Print",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20.0,
                          color: Color.fromRGBO(90, 53, 190, 1),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),*/
            Padding(
              padding: const EdgeInsets.only(top: 5, right: 10),
              child: InkWell(
                onTap: () {
                  //_takeScreenshot();
                  _captureScreenShot();
                },
                child: Card(
                  color: Color.fromRGBO(230, 229, 240, 1),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Container(
                    width: 140,
                    height: 40,
                    child: Center(
                      child: Text(
                        "Save",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20.0,
                          color: Color.fromRGBO(90, 53, 190, 1),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            appbar(context),
            Expanded(
              child: RepaintBoundary(
                key: globalKey,
                child: ListView(
                  children: [
                    reportHeader(context),
                    serialNumberContainer(context),
                    petDetailContainer(context),
                    Container(
                      height: 1,
                      width: MediaQuery.of(context).size.width,
                      color: Colors.blueGrey,
                    ),
                    tableTitleContainer(context),
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Container(
                        height: 1,
                        width: MediaQuery.of(context).size.width,
                        color: Colors.blueGrey,
                      ),
                    ),
                    symptomLevelListView(context),
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Container(
                        height: 1,
                        width: MediaQuery.of(context).size.width,
                        color: Colors.blueGrey,
                      ),
                    ),
                    resultContainer(context),
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Container(
                        height: 3,
                        width: MediaQuery.of(context).size.width,
                        color: Colors.blueGrey,
                      ),
                    ),
                    noteText(context),
                  ],
                ),
              ),
            ),
          ],
        )
      ),
    );
  }

  Widget appbar(BuildContext context)
  {
    return Container(
      color: Color.fromRGBO(90, 53, 190, 1),
      height: 64,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.of(context).pop(),
          ),
          Text(
            'Report',
            style: TextStyle(fontSize: 22, color: Colors.white),
          ),
          // Useless code
          Container(
            height: 40,
            width: 40,
          )
        ],
      ),
    );
  }

  Widget reportHeader(BuildContext context)
  {
    return Container(
      color: Color.fromRGBO(230, 229, 240, 1),
      width: MediaQuery.of(context).size.width,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.asset(
            'assets/images/newlogo.png',
            height: 100,
            width: 100,
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20.0,left: 20),
            child: Text(
              'Dogcare',
              style: TextStyle(fontSize: 50),
            ),
          )
        ],
      ),
    );
  }

  Widget serialNumberContainer(BuildContext context)
  {
    return Container(
      color: Color.fromRGBO(230, 229, 230, 1),
      child: Padding(
        padding: const EdgeInsets.only(top: 0, right: 0),
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0,right: 8.0,bottom: 8.0),
          child: Row(
            children: [
              Text(
                'S.N.: ' + 'DC'+serialNumber+'CD',
                style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),
              ),
              Spacer(),
              Text(
                'Date: ' + todayDate,
                style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget petDetailContainer(BuildContext context)
  {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: 80,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 10,left: 10,right: 10),
            child: Column(
              children: [
                Row(
                  children: [
                    Text(
                      'Name: ' + widget.petDetail['pat_name'],
                      style: TextStyle(fontSize: 20),
                    ),
                    Spacer(),
                    Text(
                      'Age: ' + MyApp.appEngine.dateDifference(widget.petDetail['age']),
                      style: TextStyle(fontSize: 20),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 5.0),
                  child: Row(
                    children: [
                      Text(
                        'Breed: ' + widget.petDetail['pat_breed'],
                        style: TextStyle(fontSize: 20),
                      ),
                      Spacer(),
                      Text(
                        'Weight: ' + widget.petDetail['weight']+ ' KG ',
                        style: TextStyle(fontSize: 20),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget tableTitleContainer(BuildContext context)
  {
    return Container(
      height: 30,
      width: MediaQuery.of(context).size.width,
      child: Padding(
        padding: const EdgeInsets.only(top: 5.0,left: 10,right: 10),
        child: Row(
          children: [
            Text(
              'SYMPTOMS',
              style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),
            ),
            Spacer(),
            Text(
              'LEVELS ',
              style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }

  Widget resultContainer(BuildContext context)
  {
    return Container(
      margin: EdgeInsets.only(
        left: 15,
        right: 15,
        top: 15,
      ),
      child: Row(
        children: [
          Text(
            'Result: ',
            style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),
          ),
          Expanded(
            child: Text(widget.conclusionResultMessage,
                style: TextStyle(fontSize: 20)),
          )
        ],
      ),
    );
  }

  Widget noteText(BuildContext context)
  {
    return Container(
      margin: EdgeInsets.only(
        left: 15,
        right: 15,
        top: 15,
      ),
      child: Row(
        children: [
          Text(
            'Note: ',
            style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),
          ),
          Expanded(
            child: Text('This report is generated based on symptoms, what you filled.',
                style: TextStyle(fontSize: 20)),
          )
        ],
      ),
    );
  }

  Widget symptomLevelListView(BuildContext context)
  {
    return ListView.builder(
      padding: EdgeInsets.zero,
      shrinkWrap: true,
      itemCount: widget.dogSymptomsArray.length,
      physics: NeverScrollableScrollPhysics(),
      itemBuilder: adapter,
    );

  }

  Widget adapter(BuildContext context, int index)
  {
    return Stack(
      children: [
        Container(
          margin: EdgeInsets.only(left: 10,right: 30,top: 15),
          child: Row(
            children: [
              Expanded(
                child: Text(widget.dogSymptomsArray[index]['symptoms'].toString(),style: TextStyle(fontSize: 20),),
              ),
              //Spacer(),
              Text(widget.dogSymptomsArray[index]['level'].toString(),style: TextStyle(fontSize: 20),),
            ],
          ),
        )
      ],
    );
  }

  // This function will be triggered when the button is pressed
  void _takeScreenshot() async
  {
    ProgressManager.showAlertDialog(buildContext, 'Loading...');

    RenderRepaintBoundary boundary =
    globalKey.currentContext!.findRenderObject() as RenderRepaintBoundary;

    ui.Image image = await boundary.toImage();
    ByteData? byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    if (byteData != null) {
      Uint8List pngBytes = byteData.buffer.asUint8List();

      // Saving the screenshot to the gallery
      final result = await ImageGallerySaver.saveImage(
          Uint8List.fromList(pngBytes),
          quality: 90,
          name: 'dogcare-report-${DateTime.now()}.png');

      if (kDebugMode) {
        print(result);
      }
      setState(() {
        ProgressManager.showAlertDialogWithAutoDismiss(buildContext, "Done.", 1, 1);
      });
    }
  }

  void _captureScreenShot() async
  {
    /*RepaintBoundary(
      key: globalKey,
      //child:symptomLevelListView(buildContext),
    );*/

    ProgressManager.showAlertDialog(buildContext, 'Report saving...');

    //get paint bound of your app screen or the widget which is wrapped with RepaintBoundary.
    RenderRepaintBoundary bound = globalKey.currentContext!.findRenderObject() as RenderRepaintBoundary;
    if(bound.debugNeedsPaint)
    {
      Timer(Duration(seconds: 1),()=>_captureScreenShot());
      return null;
    }

    ui.Image image = await bound.toImage();
    ByteData? byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    // this will save image screenshot in gallery
    if(byteData != null ){
      Uint8List pngBytes = byteData.buffer.asUint8List();
      final resultsave = await ImageGallerySaver.saveImage(Uint8List.fromList(pngBytes),quality: 90,name: 'screenshot-${DateTime.now()}.png');
      print(resultsave);
      ProgressManager.showAlertDialogWithAutoDismiss(buildContext, "Report successfully saved in 'Photo App.'", 3, 1);

    }
  }

  /*
  /// Creates an image from the given widget by first spinning up a element and render tree,
  /// then waiting for the given [wait] amount of time and then creating an image via a [RepaintBoundary].
  ///
  /// The final image will be of size [imageSize] and the the widget will be layout, ... with the given [logicalSize].
  void createImageFromWidget(Widget widget, {Duration wait, Size logicalSize, Size imageSize}) async
  {
    final RenderRepaintBoundary repaintBoundary = RenderRepaintBoundary();

    logicalSize ??= ui.window.physicalSize / ui.window.devicePixelRatio;
    imageSize ??= ui.window.physicalSize;

    assert(logicalSize.aspectRatio == imageSize.aspectRatio);

    final RenderView renderView = RenderView(
      window: null,
      child: RenderPositionedBox(alignment: Alignment.center, child: repaintBoundary),
      configuration: ViewConfiguration(
        size: logicalSize,
        devicePixelRatio: 1.0,
      ),
    );

    final PipelineOwner pipelineOwner = PipelineOwner();
    final BuildOwner buildOwner = BuildOwner();

    pipelineOwner.rootNode = renderView;
    renderView.prepareInitialFrame();

    final RenderObjectToWidgetElement<RenderBox> rootElement = RenderObjectToWidgetAdapter<RenderBox>(
      container: repaintBoundary,
      child: widget,
    ).attachToRenderTree(buildOwner);

    buildOwner.buildScope(rootElement);

    if (wait != null) {
      await Future.delayed(wait);
    }

    buildOwner.buildScope(rootElement);
    buildOwner.finalizeTree();

    pipelineOwner.flushLayout();
    pipelineOwner.flushCompositingBits();
    pipelineOwner.flushPaint();

    final ui.Image image = await repaintBoundary.toImage(pixelRatio: imageSize.width / logicalSize.width);
    final ByteData? byteData = await image.toByteData(format: ui.ImageByteFormat.png);

    if(byteData != null )
    {
      Uint8List pngBytes = byteData.buffer.asUint8List();
      final resultsave = await ImageGallerySaver.saveImage(Uint8List.fromList(pngBytes),quality: 90,name: 'screenshot-${DateTime.now()}.png');
      print(resultsave);
    }

  }*/

}
