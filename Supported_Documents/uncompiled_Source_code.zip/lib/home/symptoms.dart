import 'dart:async';
import 'dart:convert';
import 'package:dogcare/frameworks/engine/app_engine.dart';
import 'package:dogcare/home/conclusion.dart';
import 'package:dogcare/home/conclusion_history.dart';
import 'package:flutter/foundation.dart';

import 'package:flutter/material.dart';
import 'package:marquee/marquee.dart';

import '../frameworks/constant.dart';
import '../frameworks/engine/app_session.dart';
import '../frameworks/managers/progress_manager.dart';
import '../main.dart';
import '../settings/dogshealthrecord.dart';

class SelectedSymptomsInterface {
  selectedSymptomsAndVet(Map<String, dynamic> selectedDic) {}
}

class Symptoms extends StatefulWidget {
  //const Symptoms({Key? key}) : super(key: key);
  SelectedSymptomsInterface selectedSymptomsInterface =
      SelectedSymptomsInterface();

  var petDetail = Map<String, dynamic>();
  var requestDetail = Map<String, dynamic>();
  late int callFromRequest = 0;

  @override
  State<Symptoms> createState() => _SymptomsState();
}

class _SymptomsState extends State<Symptoms>
    implements Interface_API_Response_From_Engine_To_UI {
  List dogSymptomsArray = [];
  List vetListArray = [];
  Map<String, dynamic> requestPetDetail = Map<String, dynamic>();

  late BuildContext buildContext;
  String disease = 'Arthritis';
  int level0 = 0;
  int level1 = 0;
  int level2 = 0;
  int level3 = 0;

  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 500), () async {
      if (widget.requestDetail.isEmpty) {
        vetListRequest();
      } else {
        setState(() {
          dogSymptomsArray.clear();
          dogSymptomsArray
              .addAll(jsonDecode(widget.requestDetail['symptom_levels']));
          petDetailRequest();
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    buildContext = context;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            appbar(context),
            topContaint(context),
            Container(
              margin: EdgeInsets.only(top: 5),
              height: 30,
              width: MediaQuery.of(context).size.width,
              child: levelDescriptionDisplay(context),
            ),
            Expanded(child: dogSymptomsListView(context)),
            if (widget.requestDetail.isEmpty)
              InkWell(
                  onTap: () {
                    if (widget.callFromRequest == 1) {
                      Map<String, dynamic> selectedDic = Map<String, dynamic>();
                      selectedDic['vet_id'] = '33';
                      selectedDic['selected_symptom'] =
                          jsonEncode(dogSymptomsArray);
                      widget.selectedSymptomsInterface
                          .selectedSymptomsAndVet(selectedDic);
                      Navigator.pop(context, true);
                    } else {
                      String conclusionResultMessage = conclusionResult();
                      Conclusion conclusionDetail = Conclusion();
                      conclusionDetail.dogSymptomsArray
                          .addAll(dogSymptomsArray);
                      conclusionDetail.petDetail = widget.petDetail;
                      conclusionDetail.conclusionResultMessage =
                          conclusionResultMessage;
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => conclusionDetail));
                    }
                  },
                  child: Stack(
                    children: [
                      Card(
                        color: Color.fromRGBO(230, 229, 240, 1),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        child: Container(
                          width: 180,
                          height: 50,
                          child: const Padding(
                            padding: EdgeInsets.only(top: 15.0),
                            child: Text(
                              "Conclude",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 20.0,
                                color: Color.fromRGBO(90, 53, 190, 1),
                              ),
                            ),
                          ),
                        ),
                      ),
                      if (widget.callFromRequest == 1)
                        Card(
                          color: Color.fromRGBO(230, 229, 240, 1),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: Container(
                            width: 180,
                            height: 50,
                            child: const Padding(
                              padding: EdgeInsets.only(top: 15.0),
                              child: Text(
                                "Submit",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 20.0,
                                  color: Color.fromRGBO(90, 53, 190, 1),
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  )),
          ],
        ),
      ),
    );
  }

  Widget appbar(BuildContext context) {
    return Container(
      color: Color.fromRGBO(90, 53, 190, 1),
      height: 64,
      child: Row(
        mainAxisAlignment: widget.requestDetail.isEmpty
            ? MainAxisAlignment.spaceBetween
            : MainAxisAlignment.start,
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.of(context).pop(),
          ),
          const Text(
            'Symptom Tracker',
            style: TextStyle(fontSize: 22, color: Colors.white),
          ),

          // Useless code
          if (widget.requestDetail.isEmpty)
            Padding(
              padding: const EdgeInsets.only(right: 10.0),
              child: Container(
                height: 40,
                width: 40,
                child: IconButton(
                  icon: const Icon(
                    Icons.history,
                    color: Colors.white,
                  ),
                  onPressed: () {
                    ConclusionHistory conclusionHistory = ConclusionHistory();
                    conclusionHistory.petDetail = widget.petDetail;
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => conclusionHistory));
                  },
                ),
              ),
            )
        ],
      ),
    );
  }

  Widget topContaint(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            if (widget.petDetail.isNotEmpty)
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text(widget.petDetail['pat_name'],
                    style:
                        TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              ),
            if (requestPetDetail.isNotEmpty)
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text(requestPetDetail['pat_name'],
                    style:
                        TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              ),
            Row(
              children: [
                Container(
                  margin: EdgeInsets.only(top: 5, left: 20),
                  height: 30,
                  width: 80,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.grey,
                      width: 1.0,
                    ),
                  ),
                  child: Center(
                      child: Text(
                    disease,
                    style: TextStyle(fontSize: 18),
                  )),
                ),
                Container(
                    margin: EdgeInsets.only(top: 5, right: 15),
                    height: 30,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.grey,
                        width: 1.0,
                      ),
                    ),
                    child: Icon(Icons.arrow_drop_down_sharp)),
              ],
            ),
          ],
        ),
        Row(
          children: [
            if (widget.petDetail.isNotEmpty)
              Padding(
                  padding: const EdgeInsets.only(left: 10.0),
                  child: Image.network(
                    'http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/uploads/pets/' +
                        MyApp.appEngine
                            .getSinglePetImage(widget.petDetail['pet_images']),
                    height: 80,
                    width: 100,
                    fit: BoxFit.fill,
                  )),
            if (requestPetDetail.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(left: 10.0),
                child: Image.network(
                  'http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/uploads/pets/' +
                      MyApp.appEngine
                          .getSinglePetImage(requestPetDetail['pet_images']),
                  height: 80,
                  width: 100,
                  fit: BoxFit.fill,
                ),
              ),
            Container(
              margin: EdgeInsets.only(left: 10),
              height: 85,
              width: MediaQuery.of(context).size.width - 120,
              //color: Colors.green,
              child: Text(
                'Dogs cannot tell you if they’re in pain, so it’s important for you to monitor their behaviour. Here are some of the common symptoms if your dog has ' +
                    disease +
                    ' please rate as you notices :',
                style: TextStyle(color: Colors.black),
              ),
            )
          ],
        ),
      ],
    );
  }

  Widget dogSymptomsListView(BuildContext context) {
    return ListView.builder(
      padding: EdgeInsets.zero,
      itemCount: dogSymptomsArray.length,
      itemBuilder: adapter,
    );
  }

  Widget adapter(BuildContext context, int index) {
    return Stack(
      children: [
        Container(
          margin: const EdgeInsets.only(top: 10, left: 10, right: 10),
          height: 90,
          decoration: BoxDecoration(
              border: Border.all(
                color: Colors.grey,
                width: 3.0,
              ),
              shape: BoxShape.rectangle,
              borderRadius: const BorderRadius.all(Radius.circular(10))),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.only(left: 10, right: 5, top: 5),
                width: MediaQuery.of(context).size.width,
                child: Text(
                  dogSymptomsArray[index]['symptoms'].toString(),
                  style: TextStyle(fontSize: 18),
                  textAlign: TextAlign.start,
                ),
              ),
              Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    height: 30,
                    width: 92,
                    margin: EdgeInsets.only(right: 10, bottom: 5),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.grey,
                        width: 1.0,
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          height: 30,
                          width: 30,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: Colors.grey,
                              width: 1.0,
                            ),
                          ),
                          child: GestureDetector(
                              onTap: () {
                                if (widget.requestDetail.isEmpty) {
                                  minusLevel(dogSymptomsArray[index], index);
                                }
                              },
                              child: const Icon(Icons.remove)),
                        ),
                        Container(
                          height: 30,
                          width: 30,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: Colors.grey,
                              width: 1.0,
                            ),
                          ),
                          child: Center(
                              child: Text(
                            dogSymptomsArray[index]['level'],
                            style: const TextStyle(fontSize: 18),
                          )),
                        ),
                        Container(
                          height: 30,
                          width: 30,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: Colors.grey,
                              width: 1.0,
                            ),
                          ),
                          child: GestureDetector(
                              onTap: () {
                                if (widget.requestDetail.isEmpty) {
                                  plusLevel(dogSymptomsArray[index], index);
                                }
                              },
                              child: Icon(Icons.add)),
                        ),
                      ],
                    ),
                  )
                ],
              )
            ],
          ),
        )
      ],
    );
  }

  void minusLevel(Map<String, dynamic> symptomDic, int index) {
    int level = int.parse(symptomDic['level']);
    level--;

    if (level == 0) {
      level0 = level0 + 1;
      level1 = level1 - 1;
    } else if (level == 1) {
      level1 = level1 + 1;
      level2 = level2 - 1;
    } else if (level == 2) {
      level2 = level2 + 1;
      level3 = level3 - 1;
    } else if (level == 3) {
      level2 = level2 + 1;
      level3 = level3 - 1;
    }

    if (kDebugMode) {
      print('Level0: ' + level0.toString());
      print('Level1: ' + level1.toString());
      print('Level2: ' + level2.toString());
      print('Level3: ' + level3.toString());
    }

    if (level <= 0) {
      level = 0;
    }

    symptomDic['level'] = level.toString();
    setState(() {
      dogSymptomsArray[index] = symptomDic;
    });
  }

  void plusLevel(Map<String, dynamic> symptomDic, int index) {
    int level = int.parse(symptomDic['level']);
    level++;

    if (level == 0) {
      level0 = level0 + 1;
    } else if (level == 1) {
      level1 = level1 + 1;
      level0 = level0 - 1;
    } else if (level == 2) {
      level2 = level2 + 1;
      level1 = level1 - 1;
    } else if (level == 3) {
      level3 = level3 + 1;
      level2 = level2 - 1;
    }

    if (kDebugMode) {
      print('Level0: ' + level0.toString());
      print('Level1: ' + level1.toString());
      print('Level2: ' + level2.toString());
      print('Level3: ' + level3.toString());
    }

    if (level >= 3) {
      level = 3;
    }

    symptomDic['level'] = level.toString();
    setState(() {
      dogSymptomsArray[index] = symptomDic;
    });
  }

  /// marquee
  Widget levelDescriptionDisplay(BuildContext context) {
    return Marquee(
      text: levelsInfoForMarque,
      style: const TextStyle(color: Colors.black, fontSize: 20),
      scrollAxis: Axis.horizontal,
      blankSpace: 20,
      velocity: 80.0,
      showFadingOnlyWhenScrolling: false,
      fadingEdgeStartFraction: 0.1,
      fadingEdgeEndFraction: 0.1,
      startPadding: 20.0,
      //decelerationDuration: Duration(milliseconds: 500),
      decelerationCurve: Curves.easeOut,
    );
  }

  String conclusionResult() {
    int netTotal = level0 + level1 + level2 + level3;
    String conclusionMessage = '';

    if (netTotal == dogSymptomsArray.length)
    {
      if (level0 == dogSymptomsArray.length)
      {
        conclusionMessage = widget.petDetail['pat_name'].toString() +
            " is absolutely fine, you are doing a great job with him and keep going. 'OR' You may not have selected any of the traits, please select the appropriate traits as you see in " +
            widget.petDetail['pat_name'].toString() +
            '.';
      } else if (level3 == 0 && level2 == 0 && level1!=0) {
        conclusionMessage = widget.petDetail['pat_name'].toString() +
            "  is fine, take a morning walk with him and give him age-appropriate neutrinos.";
      } else if (level3 == 0 && level2 != 0) {
        conclusionMessage = widget.petDetail['pat_name'].toString() +
            " needs more observation from you, take morning and evening walks with him and give his age appropriate neutrinos.";
      } else if (level3 >= 1 && level3 <= netTotal/2) {
        conclusionMessage =
            "Please note one more day, if these symptoms reappear, please contact your nearest specialist (Veterinary). You can check the specialist who is near you in the table below.";
      }  else if (level3 > netTotal / 2) {
        conclusionMessage =
            "Please contact any expert who is good dealing with " +
                disease +
                ", " +
                widget.petDetail['pat_name'].toString() +
                "'s is serious condition.";
      } else {
        conclusionMessage = "Please select symptoms once again and try.";
      }
    } else {
      conclusionMessage = "Please select symptoms once again and try.";
    }
    return conclusionMessage;
  }

  void vetListRequest() async {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    {
      Map<String, dynamic> requestData = Map<String, dynamic>();

      requestData["user_id"] = App_Session.userId;

      MyApp.appEngine.api_Request(requestData, "", "VetList");
    }
  }

  void petDetailRequest() async {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    {
      Map<String, dynamic> requestData = Map<String, dynamic>();
      requestData["pet_id"] = widget.requestDetail['pet_id'];
      MyApp.appEngine.api_Request(requestData, "", "Pet_Detail");
    }
  }

  void symptomsListRequest(String vet_id) async {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    {
      ProgressManager.showAlertDialog(buildContext, "Loading...");
      Map<String, dynamic> requestData = Map<String, dynamic>();

      requestData["user_id"] = App_Session.userId;
      requestData["vet_id"] = vet_id;

      MyApp.appEngine.api_Request(requestData, "", "SymptomsList");
    }
  }

  @override
  Future<void> api_Response_To_UI(
      Map<String, dynamic> responseDictionary, String apiName) async {
    if (apiName.compareTo("VetList") == 0) {
      if (responseDictionary['status'] == '200') {
        setState(() {
          vetListArray = responseDictionary['data'];
          symptomsListRequest(vetListArray[0]['id'].toString());
        });
      } else {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
      }
    } else if (apiName.compareTo("SymptomsList") == 0) {
      if (responseDictionary['status'] == '200') {
        setState(() {
          dogSymptomsArray.clear();
          dogSymptomsArray.addAll(responseDictionary['data']);
          for (int i = 0; i < dogSymptomsArray.length; i++) {
            Map<String, dynamic> symptomDic = dogSymptomsArray[i];
            symptomDic['level'] = '0';
            dogSymptomsArray[i] = symptomDic;
          }
          level0 = dogSymptomsArray.length;
        });
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
      } else {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
      }
    } else if (apiName.compareTo("Pet_Detail") == 0) {
      if (responseDictionary['status'] == '200') {
        setState(() {
          requestPetDetail.addAll(responseDictionary["data"]);
        });
      }
    }
  }

  @override
  void api_Response_Error(String apiName, response) {}
}
