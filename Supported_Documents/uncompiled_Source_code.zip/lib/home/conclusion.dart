import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:dogcare/frameworks/managers/progress_manager.dart';
import 'package:dogcare/home/report.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import '../frameworks/engine/app_engine.dart';
import '../frameworks/engine/app_session.dart';
import '../frameworks/maasss_helper.dart';
import '../main.dart';
import 'package:geolocator/geolocator.dart';
import '../frameworks/engine/app_profile.dart';

class Conclusion extends StatefulWidget {
  //const Conclusion({Key? key}) : super(key: key);
  var petDetail = Map<String, dynamic>();
  String conclusionResultMessage = '';
  List dogSymptomsArray = [];

  @override
  State<Conclusion> createState() => _ConclusionState();
}

class _ConclusionState extends State<Conclusion>
    implements Interface_API_Response_From_Engine_To_UI {
  late BuildContext buildContext;
  List googleVetList = [];
  List<PickedFile> createRequestImageArray = [];

  bool yesNoAlertViewFlag = false;


  @override
  void initState() {
    super.initState();
    MyApp.appEngine.hardwareManager.getMyCurrentLocation();
    Timer(const Duration(milliseconds: 500), () async {
      googleApiRequest();
    });
  }

  @override
  Widget build(BuildContext context) {
    buildContext = context;
    return Scaffold(
      body: SafeArea(
        child: Stack(children: [
            Column(
            children: [
            appbar(context),
        topText(context),
        exportSendReprtButton(context),
        Container(
          margin: EdgeInsets.only(top: 10, left: 14),
          width: MediaQuery.of(context).size.width,
          child: const Text(
            'Expert near to you',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
            textAlign: TextAlign.left,
          ),
        ),
        Expanded(
          child: conclusionListView(context),
        ),
        ],
      ),
            if(yesNoAlertViewFlag)
              yesNoAlertView(context),
        ],
        )
      ),
    );
  }

  Widget appbar(BuildContext context) {
    return Container(
      color: Color.fromRGBO(90, 53, 190, 1),
      height: 64,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.of(context).pop(),
          ),
          Text(
            'Conclusion',
            style: TextStyle(fontSize: 22, color: Colors.white),
          ),

          // Useless code
          Container(
            height: 40,
            width: 40,
          )
        ],
      ),
    );
  }

  Widget topText(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 10, left: 10, right: 10),
      height: 105,
      width: MediaQuery.of(context).size.width,
      //color: Colors.green,
      child: Text(
        widget.conclusionResultMessage.toString(),
        style: TextStyle(fontSize: 18),
      ),
    );
  }

  Widget exportSendReprtButton(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 5, left: 10),
          child: InkWell(
            onTap: () {
              Report report = Report();
              report.dogSymptomsArray = widget.dogSymptomsArray;
              report.petDetail = widget.petDetail;
              report.conclusionResultMessage = widget.conclusionResultMessage;
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => report));
            },
            child: Card(
              color: Color.fromRGBO(230, 229, 240, 1),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Container(
                width: 140,
                height: 40,
                child: Center(
                  child: Text(
                    "Export Report",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20.0,
                      color: Color.fromRGBO(90, 53, 190, 1),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 5, right: 10),
          child: InkWell(
            onTap: () {
              setState(() {
                yesNoAlertViewFlag = true;
              });
            },
            child: Card(
              color: Color.fromRGBO(230, 229, 240, 1),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Container(
                width: 140,
                height: 40,
                child: Center(
                  child: Text(
                    "Send Report",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20.0,
                      color: Color.fromRGBO(90, 53, 190, 1),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget conclusionListView(BuildContext context) {
    return ListView.builder(
      padding: EdgeInsets.zero,
      itemCount: googleVetList.length,
      itemBuilder: adapter,
    );
  }

  Widget adapter(BuildContext context, int index) {
    return Container(
      margin: EdgeInsets.only(top: 10, left: 15, right: 15),
      decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
            width: 3.0,
          ),
          shape: BoxShape.rectangle,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      child: Column(
        children: [
          Container(
            margin: EdgeInsets.only(left: 5, right: 5, top: 5),
            width: MediaQuery.of(context).size.width,
            child: Text(
              googleVetList[index]['vicinity'].toString(),
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              textAlign: TextAlign.start,
            ),
          ),
          Container(
            margin: EdgeInsets.only(left: 5, right: 5, top: 5),
            width: MediaQuery.of(context).size.width,
            child: Text(
              googleVetList[index]['name'].toString(),
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.start,
            ),
          ),
          Container(
            margin: EdgeInsets.only(left: 5, right: 5, top: 5),
            width: MediaQuery.of(context).size.width,
            child: Text(
                'Distance: ' +
                    MyApp.appEngine.getDistanceBetween(
                        googleVetList[index]['geometry']['location']['lat']
                            .toString(),
                        googleVetList[index]['geometry']['location']['lng']
                            .toString()) +
                    ', ',
                style: TextStyle(fontSize: 16)),
          ),
          Container(
            margin: EdgeInsets.all(5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                InkWell(
                  onTap: () {
                    _launchURL(index);
                  },
                  child: Card(
                    color: Color.fromRGBO(230, 229, 240, 1),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Container(
                      width: 80,
                      height: 30,
                      child: const Padding(
                        padding: EdgeInsets.only(top: 5.0),
                        child: Text(
                          "Go",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 20.0,
                            color: Colors.blue,
                            //color: Color.fromRGBO(88, 148, 239, 1),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      'Open : ',
                      style: TextStyle(fontSize: 18),
                      textAlign: TextAlign.end,
                    ),
                    Text(
                      googleVetList[index]['opening_hours']['open_now']
                                  .toString() ==
                              'false'
                          ? 'No  '
                          : 'Yes  ',
                      style: TextStyle(fontSize: 18),
                      textAlign: TextAlign.end,
                    ),

                  ],
                ),
              ],
            ),
          ),

        ],
      ),
    );
  }

  Widget yesNoAlertView(BuildContext context)
  {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Align(
        alignment: Alignment.center,
        child: Container(
          height: 150,
          width: 250,
          decoration: BoxDecoration(
              color: Colors.black87,
              borderRadius: BorderRadius.all(Radius.circular(12))),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 15.0),
                child: Text(
                  'Send Report',
                  style: TextStyle(
                      color: Colors.white, letterSpacing: 1, fontSize: 20),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Container(
                  width: 200,
                  child: Text(
                    'Do you want to send symptoms report?',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.white, letterSpacing: 1, fontSize: 15),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 32.0),
                child: Column(
                  children: [
                    Container(
                      height: 1,
                      width: 248,
                      color: Colors.white,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        GestureDetector(
                            child: Text(
                              "Yes",
                              style: TextStyle(color: Colors.blue),
                            ),
                            onTap: () {
                              createReplyRequest();
                              setState(() {
                                yesNoAlertViewFlag = false;
                              });

                            }),
                        Container(
                          height: 33,
                          width: 1,
                          color: Colors.white,
                        ),
                        GestureDetector(
                            child: Text(
                              "No",
                              style: TextStyle(color: Colors.blue),
                            ),
                            onTap: () {
                              setState(() {
                                yesNoAlertViewFlag = false;
                              });
                            }),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  void _launchURL(int index) async
  {
   // const url = 'https://maps.google.com/maps?saddr=lat,long&daddr=lat,long';
    String url = 'https://maps.google.com/maps?saddr='+MyApp.appEngine.hardwareManager.myCurrentLatitude.toString()+','+MyApp.appEngine.hardwareManager.myCurrentLongitude.toString()+'&daddr='+googleVetList[index]['geometry']['location']['lat'].toString()+','+googleVetList[index]['geometry']['location']['lat'].toString();
    //                             .toString()';
    if (await canLaunch(url)) {
      await launchUrl(Uri.parse(url));
    } else {
      throw 'Could not launch $url';
    }
  }

  void createReplyRequest() async
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    ProgressManager.showAlertDialog(buildContext, 'Loading...');
    {
      Map<String, dynamic> requestData = Map<String, dynamic>();
      requestData["user_id"] = App_Session.userId.toString();
      requestData["pet_id"] = widget.petDetail['pet_id'].toString();
      requestData["request"] = widget.conclusionResultMessage;
      requestData["symptom_levels"] = jsonEncode(widget.dogSymptomsArray);
      requestData["vet_id"] = '33';

      File zipFilepath =
          await AppProfile.createZipOfFiles(createRequestImageArray);
      List<int> fileBytes = zipFilepath.readAsBytesSync();
      MyApp.appEngine.apiRequestForFileUpload(
          zipFilepath.path, requestData, 'CreateRequest', fileBytes);
    }
  }

  void googleApiRequest() async {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    {
      ProgressManager.showAlertDialog(buildContext, "Loading...");
      Map<String, dynamic> requestData = Map<String, dynamic>();

      String appendedUrl = "location=" +
          MyApp.appEngine.hardwareManager.myCurrentLatitude.toString() +
          "%2C" +
          MyApp.appEngine.hardwareManager.myCurrentLongitude.toString();
      MyApp.appEngine.api_Request(requestData, appendedUrl, "GoogleApi");
    }
  }

  @override
  Future<void> api_Response_To_UI(
      Map<String, dynamic> responseDictionary, String apiName) async {
    if (apiName.compareTo("GoogleApi") == 0) {
      if (responseDictionary['status'] == 'OK') {
        setState(() {
          googleVetList = responseDictionary['results'];
        });
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, 'Loaded.', 2, 1);
      } else {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 2, 1);
      }
    } else if (apiName.compareTo("CreateRequest") == 0) {
      if (responseDictionary["status"] == '200') {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, 'Request successfully created.', 2, 1);
        Navigator.pop(buildContext, true);
      } else {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 2, 1);
      }
    }
  }

  @override
  void api_Response_Error(String apiName, response) {
    ProgressManager.showAlertDialogWithAutoDismiss(
        buildContext, 'No vet found near your location.', 2, 1);
  }
}
