import 'package:carousel_slider/carousel_slider.dart';
import 'package:dogcare/frameworks/engine/app_engine.dart';
import 'package:dogcare/home/symptoms.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../frameworks/managers/progress_manager.dart';
import '../main.dart';

class DogDetail extends StatefulWidget {
 // const DogDetail({Key? key}) : super(key: key);
  var petDetail = Map<String,dynamic>();


  @override
  State<DogDetail> createState() => _DogDetailState();
}

class _DogDetailState extends State<DogDetail> implements Interface_API_Response_From_Engine_To_UI{
  late BuildContext buildContext;
  List carouselListArray = [];

  @override
  void initState() {
    super.initState();
    getAllPetImage(widget.petDetail['pet_images'].toString());
  }

  @override
  Widget build(BuildContext context) {
    buildContext = context;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Container(
              color: Color.fromRGBO(90, 53, 190, 1),
              height: 64,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    child: IconButton(
                      icon:
                      Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ),
                  Text(
                    'Dog Detail',
                    style: TextStyle(fontSize: 22,color: Colors.white),
                  ),
                  Padding(
                    padding:
                    const EdgeInsets.only(right: 10.0, top: 10),
                    child: Container(
                      height: 40,
                      width: 40,
                    ),
                  )
                ],
              ),
            ),
            Container(
              height: 300,
              child: carouselSliderbuilder(context),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10,right: 10),
              child: Card(
                elevation: 50,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 20, top: 5),
                      width: MediaQuery
                          .of(context)
                          .size
                          .width,
                      child: Text(
                        widget.petDetail['pat_name'].toString(),
                        style: TextStyle(
                            fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 20, top: 5, right: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Age:',
                            style: TextStyle(fontSize: 20),
                          ),
                          Text(
                              dateDifference(widget.petDetail['age'].toString()),
                            style: TextStyle(fontSize: 20),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 20, right: 20,top: 5,bottom: 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Breed:',
                            style: TextStyle(fontSize: 20),
                          ),
                          Text(
                            widget.petDetail['pat_breed'].toString(),
                            style: TextStyle(fontSize: 20),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10.0,left: 10,right: 10),
              child: Card(
                elevation: 50,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(left: 20, right: 20,top: 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Health:',
                            style: TextStyle(fontSize: 20),
                          ),
                          Text(
                            widget.petDetail['health'].toString(),
                            style: TextStyle(fontSize: 20),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 20, right: 20,top: 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Weight:',
                            style: TextStyle(fontSize: 20),
                          ),
                          Text(
                            widget.petDetail['weight'].toString()+ ' Kg',
                            style: TextStyle(fontSize: 20),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 20, right: 20,top: 5,bottom: 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Sex:',
                            style: TextStyle(fontSize: 20),
                          ),
                          Text(
                            widget.petDetail['sex'].toString(),
                            style: TextStyle(fontSize: 20),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            GestureDetector(
              child: Padding(
                padding: const EdgeInsets.only(top: 10.0),
                child: Card(
                  color: Color.fromRGBO(230, 229, 240, 1),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Container(
                    width: 200,
                    height: 50,
                    child: const Padding(
                      padding: EdgeInsets.only(top: 15.0),
                      child: Text(
                        "Symptoms Tracker",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20.0,
                          color: Color.fromRGBO(90, 53, 190, 1),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              onTap: () {
                Symptoms symptomsDetail = Symptoms();
                symptomsDetail.petDetail = widget.petDetail;
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => symptomsDetail));
              },
            )
          ],
        ),
      ),
    );
  }

  Widget carouselSliderbuilder(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(15),
      child: CarouselSlider.builder(
        itemCount: carouselListArray.length,
        options: CarouselOptions(
          enlargeCenterPage: true,
          height: 300,
          autoPlay: true,
          autoPlayInterval: Duration(seconds: 3),
          reverse: false,
          aspectRatio: 5.0,
        ),
        itemBuilder: (context, i, id) {
          //for onTap to redirect to another screen
          return GestureDetector(
            child: Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: Colors.white,)
              ),
              //ClipRRect for image border radius
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.network('http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/uploads/pets/'+
                  carouselListArray[i],
                  width: 400,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            onTap: () {

            },
          );
        },
      ),
    );
  }

  void getAllPetImage(String petImages){
    final splitImageArray = petImages.split(',');
    setState(() {
      carouselListArray = splitImageArray;
    });
  }

  String dateDifference(String dob) {
    String age = '';

    List dobDateIndex = dob.split('-');
    int dobYear = int.parse(dobDateIndex[0].toString());
    int dobMonth = int.parse(dobDateIndex[1].toString());
    int dobDay = int.parse(dobDateIndex[2].toString());

    String currentDateString = DateFormat('yyyy-MM-dd').format(DateTime.now());
    List currentDateIndex = currentDateString.split('-');

    int currentYear = int.parse(currentDateIndex[0].toString());
    int currentMonth = int.parse(currentDateIndex[1].toString());
    int currentDay = int.parse(currentDateIndex[2].toString());

    DateTime dobDate = DateTime(dobYear, dobMonth, dobDay);
    DateTime currentDate = DateTime(currentYear, currentMonth, currentDay);
    int totalDays = currentDate.difference(dobDate).inDays;
    int years = totalDays ~/ 365;
    double monthInYear = 0;
    if(years>0){

    }
    int months = (totalDays-years*365) ~/ 30;
    if(months>0){
      monthInYear = months/12;
    }
    int days = totalDays-years*365-months*30;
    if(days>0 && years == 0 && months==0){
      return days.toString() + ' Days ';
    }
    if (kDebugMode) {
      print("$years $months $days $totalDays");
    }
    double netAge = years+monthInYear;
    netAge =  double.parse((netAge). toStringAsFixed(2));

    return netAge.toString() + ' Year ';

  }


  void updateDogDetaisListRequest() async
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    {
      ProgressManager.showAlertDialog(buildContext, "Loading...");
      Map<String, dynamic> requestData = Map<String, dynamic>();

      requestData["pet_id"] = '';
      requestData["petname"] = '';
      requestData["breed"] = '';
      requestData["sex"] = '';
      requestData["age"] = '';
      requestData["weight"] = '';
      requestData["health"] = '';

      MyApp.appEngine.api_Request(requestData, "", "UpdatePet");
    }
  }

  @override
  Future<void> api_Response_To_UI(
      Map<String, dynamic> responseDictionary, String apiName) async
  {
    if (apiName.compareTo("UpdatePet") == 0)
    {
      if (responseDictionary['status'] == '200')
      {
        setState(() {
          //expertListArray = responseDictionary['data'];
        });
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
      }
      else
      {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
      }
    }
  }

  @override
  void api_Response_Error(String apiName, response) {
  }


}
