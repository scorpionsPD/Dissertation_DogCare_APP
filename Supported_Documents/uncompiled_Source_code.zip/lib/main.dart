import 'dart:async';
import 'package:dogcare/frameworks/engine/app_profile.dart';
import 'package:dogcare/frameworks/engine/app_session.dart';
import 'package:dogcare/tabbarcontroler.dart';

import 'frameworks/authentication/login_page.dart';
import 'frameworks/engine/app_engine.dart';
import 'frameworks/maasss_helper.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

void main() {

  WidgetsFlutterBinding.ensureInitialized();

  runApp(MyApp());
}

class MyApp extends StatelessWidget
{
  static APP_Engine appEngine = APP_Engine();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dogcare',
      theme: ThemeData(
      ),
      home: FirstSplashPage(),
      debugShowCheckedModeBanner: false,

    );
  }
}

class FirstSplashPage extends StatefulWidget
{
  const FirstSplashPage({Key? key}) : super(key: key);

  @override
  FirstSplashPageState createState() => FirstSplashPageState();
}

class FirstSplashPageState extends State<FirstSplashPage>
{
  @override
  void initState()
  {
    super.initState();
    maasssHelperGetUniqueDeviceID().toString();
    maasssHelperGetAppVersionInfo();
    Map<String, dynamic> requestData = Map<String, dynamic>();
    MyApp.appEngine.api_Request(requestData, '', 'Country_Request');
    internalDataRead();

    // openLocationSetting();
    Timer(const Duration(seconds: 2), ()
    {
      AppProfile.readDataFromInternalMemory();
      int userId = int.parse(App_Session.userId);
      if((userId)>0)
      {
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_context) => TabBarController()),
                (Route<dynamic> route) => false);
      }
      else {
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (BuildContext context) => Login()));
      }
    });

  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage("assets/images/splash.png"),
          fit: BoxFit.cover,
        ),
      ),
    );
  }

  void internalDataRead() async{
    await maasss_Helper_ReadDataFromFile('settings.txt');

  }
}
