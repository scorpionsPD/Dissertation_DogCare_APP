import 'package:dogcare/frameworks/engine/app_session.dart';
import 'package:dogcare/home/doglist.dart';
import 'package:dogcare/request/request.dart';
import 'package:dogcare/settings/setting.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class TabBarController extends StatefulWidget
{
  @override
  State<TabBarController> createState() => _TabBarControllerState();
}

class _TabBarControllerState extends State<TabBarController> {

  @override
  void initState()
  {
    super.initState();
    App_Session.loadedTabArray.clear();
    if (App_Session.userTypes.contains('2'))
    {
      App_Session.loadedTabArray.addAll(App_Session.expertTabArray);
    }
    else if (App_Session.userTypes.contains('3'))
    {
      App_Session.loadedTabArray.addAll(App_Session.requesterTabArray);
    }
    else{
      App_Session.loadedTabArray.addAll(App_Session.requesterTabArray);
    }
  }

  @override
  Widget build(BuildContext context)
  {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DefaultTabController(
        length: App_Session.loadedTabArray.length,
        animationDuration: const Duration(seconds: 0),
        child: Scaffold(
          body: TabBarView(
            children: [
              for(final tab in App_Session.loadedTabArray)
                if(tab['tabname'].toString().contains('DogList'))
                  const DogList(),
              for(final tab in App_Session.loadedTabArray)
                if(tab['tabname'].toString().contains('Request'))
                  const Requester(),
              for(final tab in App_Session.loadedTabArray)
                if(tab['tabname'].toString().contains('Settings'))
                  const Settings(),

          ]),
          bottomNavigationBar: SafeArea(
            child: TabBar(
              tabs: [
                if(App_Session.loadedTabArray.length==3)
                  Tab(child: Image.asset('assets/images/playstore.png',color: Colors.black,),),
                Tab(child: Image.asset('assets/images/request.png',color: Colors.black,height: 30,width: 30,),),
                Tab(child: Icon(Icons.settings,color: Colors.black,),),
              ],
            ),
          ),

        ),
      ),
    );
  }
}