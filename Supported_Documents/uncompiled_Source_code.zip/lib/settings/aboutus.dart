import 'package:flutter/material.dart';

class AboutUs extends StatefulWidget {
  const AboutUs({Key? key}) : super(key: key);

  @override
  State<AboutUs> createState() => _AboutUsState();
}

class _AboutUsState extends State<AboutUs>
{
  List aboutUsTableList = [];

  @override
  initState(){
    super.initState();
    defaultData();
  }

  defaultData(){
    Map<String, dynamic> data1 = Map<String, dynamic>();
    data1['title'] = 'What is this project?';
    data1['description'] ="This is a research project which aims at the development of mobile application. "
        "The goal of the project is to create an application that dog owners may use to track their pets"
        " health.The application will provide monitoring of dogs that are in the grasp of any type of sickness related to arthritis and require medical attention. "
        "arthritis can be as uncomfortable for our dogs as it is in humans. However, there are ways of managing the disease to ease your pet"
        " s pain.The goal of this research is to create an app to track dogs'"
        " health, to increase awareness among the users for their respective pets, to learn about app development, "
        "and to give practical understanding of its designing processes.";
    aboutUsTableList.add(data1);

    Map<String, dynamic> data2 = Map<String, dynamic>();
    data2['title'] = 'Who is conducting this research?';
    data2['description'] ="I am a MSc student at the University of Strathclyde and this research forms part of my MSc."
    "My supervisor is Professor Roma Maguire (roma.maguire@strath.ac.uk)."
    "I also undertake occasional work as a volunteer but I am conducting this research as a MSc student and will not be able to offer any advice.";
    aboutUsTableList.add(data2);

    Map<String, dynamic> data3 = Map<String, dynamic>();
    data3['title'] = "Who can I contact for further information?";
    data3['description'] = "For further information about the research or your interview data, please contact:\n"
    "Pardeep Kumar\n"
    "University of Strathclyde\n"
    "pardeep-kumar.2021@uni.strath.ac.uk\n"
    "If you have concerns/questions about the research you would like to discuss with someone else at the University, please contact:\n\n"
    "Roma Maguire\n"
    "University of Strathclyde\n"
    "roma.maguire@strath.ac.uk";
    aboutUsTableList.add(data2);
  }

  @override
  Widget build(BuildContext context)
  {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Container(
              color: Color.fromRGBO(90, 53, 190, 1),
              height: 64,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    child: IconButton(
                      icon: Icon(Icons.arrow_back, color: Colors.white),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ),
                  Text(
                    'About App',
                    style: TextStyle(fontSize: 22,color: Colors.white),
                  ),
                  Container(
                    height: 40,
                    width: 40,
                  )
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(top: 20,left: 10),
              height: 40,
              child: Row(
                children: [
                  Text('Name :',style: TextStyle(fontSize: 20),),
                  Text(' Pradeep Kumar',style: TextStyle(fontSize: 20),),

                ],
              ),
            ),
            Expanded(
                child: aboutTableview(context))
          ],
        ),
      ),
    );
  }
  Widget aboutTableview(BuildContext context){
    return ListView.builder(
        itemBuilder: aboutUsTableViewCell,
        itemCount: aboutUsTableList.length,
      );
  }

  Widget aboutUsTableViewCell(BuildContext context, int index){
    return Column(
      children: [
        Container(
        margin: EdgeInsets.only(top: 20,left: 10,bottom: 5),
        height: 30,
        width: MediaQuery.of(context).size.width,
        child: Text(aboutUsTableList[index]['title'],style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
      ),
        if(index!=2)
          Container(
        margin: EdgeInsets.only(top: 5,left: 10,right: 10,bottom: 5),
        child: Text(aboutUsTableList[index]['description'],style: TextStyle(fontSize: 20),),
        ),
        if(index==2)
          Container(
            margin: EdgeInsets.only(top: 5,left: 10,right: 10,bottom: 5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
              Text('For further information about the research or your interview data, please contact:',style: TextStyle(fontSize: 20),),
              Text('\n\nPardeep Kumar',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
              Text('University of Strathclyde',style: TextStyle(fontSize: 20),),
              Text('pardeep-kumar.2021@uni.strath.ac.uk',style: TextStyle(fontSize: 20,color: Colors.blueAccent),),
              Text('If you have concerns/questions about the research you would like to discuss with someone else at the University, please contact:',style: TextStyle(fontSize: 20),),
              Text(' ',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
              Text('Roma Maguire',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
              Text('University of Strathclyde',style: TextStyle(fontSize: 20),),
              Text('roma.maguire@strath.ac.uk',style: TextStyle(fontSize: 20,color: Colors.blueAccent),),
            ],
            ),
          )
    ],
    );
  }
}
