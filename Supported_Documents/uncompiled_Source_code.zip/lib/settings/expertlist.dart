import 'dart:async';
import 'package:dogcare/frameworks/engine/app_engine.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../frameworks/engine/app_session.dart';
import '../frameworks/managers/progress_manager.dart';
import '../main.dart';

class ExpertList extends StatefulWidget {
  const ExpertList({Key? key}) : super(key: key);

  @override
  State<ExpertList> createState() => _ExpertListState();
}

class _ExpertListState extends State<ExpertList> implements Interface_API_Response_From_Engine_To_UI
{
  List expertListArray = [];
  List nearByListArray = [];
  late BuildContext buildContext;

  @override
  void initState() {
    super.initState();
    expertListArray.clear();
    nearByListArray.clear();
    MyApp.appEngine.hardwareManager.getMyCurrentLocation();
    Timer(const Duration(milliseconds: 500), () async
    {
      expertListRequest();
    });
  }

  @override
  Widget build(BuildContext context)
  {
    buildContext = context;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            appBar(context),
            expertNearByButton(context),
            Expanded(
              child: Container(
                margin: EdgeInsets.only(top: 20,left: 10,right: 10),
                child: expertListView(context),
              ),
            ),
          ],
        ),
      ),
    );
  }
  Widget appBar(BuildContext context){
    return Container(
      color: Color.fromRGBO(90, 53, 190, 1),
      height: 64,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: IconButton(
              icon:
              Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ),
          Text(
            'Expert List',
            style: TextStyle(fontSize: 22,color: Colors.white),
          ),
          Container(
            height: 40,
            width: 40,
          )
        ],
      ),
    );
  }

  Widget expertNearByButton(BuildContext context){
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 20, left: 10),
          child: InkWell(
            onTap: () {
              setState(() {
                expertListArray.clear();
                nearByListArray.clear();
                expertListRequest();
              });
            },
            child: Card(
              color: expertListArray.isNotEmpty?Color.fromRGBO(90, 53, 190, 1):Color.fromRGBO(230, 229, 240, 1),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Container(
                width: 155,
                height: 40,
                child: Center(
                  child: Text(
                    "In House",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20.0,
                      color: expertListArray.isEmpty?Color.fromRGBO(90, 53, 190, 1):Color.fromRGBO(230, 229, 240, 1),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 20, right: 10),
          child: InkWell(
            onTap: () {
              setState(() {
                expertListArray.clear();
                nearByListArray.clear();
                googleApiRequest();
              });
            },
            child: Card(
              color: nearByListArray.isNotEmpty?Color.fromRGBO(90, 53, 190, 1):Color.fromRGBO(230, 229, 240, 1),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Container(
                width: 155,
                height: 40,
                child: Center(
                  child: Text(
                    "Near By",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20.0,
                      color: nearByListArray.isEmpty?Color.fromRGBO(90, 53, 190, 1):Color.fromRGBO(230, 229, 240, 1),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget expertListView(BuildContext context)
  {
    return ListView.builder(
      itemCount: expertListArray.isNotEmpty?expertListArray.length:nearByListArray.length,
      itemBuilder: expertListArray.isNotEmpty?expertAdapter:nearByAdapter,
    );
  }

  Widget expertAdapter(BuildContext context, int index) {
    return Stack(
      children: [
        Card(
          shape: RoundedRectangleBorder(
            side: BorderSide(
              color: Colors.grey,
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          elevation: 10,
          shadowColor: Colors.grey,
          child: Container(
            margin: EdgeInsets.only(left: 10,top: 10,bottom: 10,right: 5),
            //height: 70,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        expertListArray[index]['firstname'].toString() + expertListArray[index]['lastname'].toString(),
                        style: TextStyle(fontSize: 20),
                      ),
                      Text(
                        expertListArray[index]['email'].toString(),
                        style: TextStyle(fontSize: 17),
                      )
                    ],
                  ),
                ),
                /*InkWell(
                  onTap: () {
                    _launchURLFromExpert(index);
                  },
                  child: Card(
                    color: Color.fromRGBO(230, 229, 240, 1),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Container(
                      width: 60,
                      height: 30,
                      child: const Padding(
                        padding: EdgeInsets.only(top: 5.0),
                        child: Text(
                          "Go",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 20.0,
                            color: Colors.blue,
                            //color: Color.fromRGBO(88, 148, 239, 1),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),*/
              ],
            ),
          ),
        )
      ],
    );
  }

  Widget nearByAdapter(BuildContext context, int index) {
    return Container(
      margin: EdgeInsets.only(top: 10, left: 15, right: 15),
      decoration: BoxDecoration(
          border: Border.all(
            color: Colors.grey,
            width: 3.0,
          ),
          shape: BoxShape.rectangle,
          borderRadius: BorderRadius.all(Radius.circular(10))),
      child: Column(
        children: [
          Container(
            margin: EdgeInsets.only(left: 5, right: 5, top: 5),
            width: MediaQuery.of(context).size.width,
            child: Text(
              nearByListArray[index]['vicinity'].toString(),
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              textAlign: TextAlign.start,
            ),
          ),
          Container(
            margin: EdgeInsets.only(left: 5, right: 5, top: 5),
            width: MediaQuery.of(context).size.width,
            child: Text(
              nearByListArray[index]['name'].toString(),
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.start,
            ),
          ),
          Container(
            margin: EdgeInsets.only(left: 5, right: 5, top: 5),
            width: MediaQuery.of(context).size.width,
            child: Text(
                'Distance: ' +
                    MyApp.appEngine.getDistanceBetween(
                        nearByListArray[index]['geometry']['location']['lat']
                            .toString(),
                        nearByListArray[index]['geometry']['location']['lng']
                            .toString()) +
                    ', ',
                style: TextStyle(fontSize: 16)),
          ),
          Container(
            margin: EdgeInsets.all(5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                InkWell(
                  onTap: () {
                    _launchURLFromGoogle(index);
                  },
                  child: Card(
                    color: Color.fromRGBO(230, 229, 240, 1),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Container(
                      width: 80,
                      height: 30,
                      child: const Padding(
                        padding: EdgeInsets.only(top: 5.0),
                        child: Text(
                          "Go",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 20.0,
                            color: Colors.blue,
                            //color: Color.fromRGBO(88, 148, 239, 1),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      'Open : ',
                      style: TextStyle(fontSize: 18),
                      textAlign: TextAlign.end,
                    ),
                    Text(
                      nearByListArray[index]['opening_hours']['open_now']
                          .toString() ==
                          'false'
                          ? 'No  '
                          : 'Yes  ',
                      style: TextStyle(fontSize: 18),
                      textAlign: TextAlign.end,
                    ),

                  ],
                ),
              ],
            ),
          ),

        ],
      ),
    );
  }

  void _launchURLFromExpert(int index) async
  {
    String url = 'https://maps.google.com/maps?saddr='+MyApp.appEngine.hardwareManager.myCurrentLatitude.toString()+','+MyApp.appEngine.hardwareManager.myCurrentLongitude.toString()+'&daddr='+expertListArray[index]['latitude'].toString()+','+expertListArray[index]['longitude'].toString();
    if (await canLaunch(url)) {
      await launchUrl(Uri.parse(url));
    } else {
      throw 'Could not launch $url';
    }
  }

  void _launchURLFromGoogle(int index) async
  {
    // const url = 'https://maps.google.com/maps?saddr=lat,long&daddr=lat,long';
    String url = 'https://maps.google.com/maps?saddr='+MyApp.appEngine.hardwareManager.myCurrentLatitude.toString()+','+MyApp.appEngine.hardwareManager.myCurrentLongitude.toString()+'&daddr='+nearByListArray[index]['geometry']['location']['lat'].toString()+','+nearByListArray[index]['geometry']['location']['lat'].toString();
    //                             .toString()';
    if (await canLaunch(url)) {
      await launchUrl(Uri.parse(url));
    } else {
      throw 'Could not launch $url';
    }
  }

  void expertListRequest() async
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    {
      ProgressManager.showAlertDialog(buildContext, "Loading...");
      Map<String, dynamic> requestData = Map<String, dynamic>();

      requestData["user_id"] = App_Session.userId;

      MyApp.appEngine.api_Request(requestData, "", "ExpertList");
    }
  }

  void googleApiRequest() async {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    {
      ProgressManager.showAlertDialog(buildContext, "Loading...");
      Map<String, dynamic> requestData = Map<String, dynamic>();

      String appendedUrl = "location=" +
          MyApp.appEngine.hardwareManager.myCurrentLatitude.toString() +
          "%2C" +
          MyApp.appEngine.hardwareManager.myCurrentLongitude.toString();
      MyApp.appEngine.api_Request(requestData, appendedUrl, "GoogleApi");
    }
  }


  @override
  Future<void> api_Response_To_UI(
      Map<String, dynamic> responseDictionary, String apiName) async
  {
    if (apiName.compareTo("ExpertList") == 0)
    {
      if (responseDictionary['status'] == '200')
      {
        setState(() {
          expertListArray = responseDictionary['data'];
        });
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
      }
      else
      {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
      }
    }
    else if (apiName.compareTo("GoogleApi") == 0)
    {
      if (responseDictionary['status'] == 'OK')
      {
        setState(() {
          nearByListArray = responseDictionary['results'];
        });
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, 'Loaded.', 2, 1);
      }
      else
      {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 2, 1);
      }
    }

  }

  @override
  void api_Response_Error(String apiName, response) {
    ProgressManager.showAlertDialogWithAutoDismiss(
        buildContext, 'No vet found near your location.', 2, 1);

  }
}
