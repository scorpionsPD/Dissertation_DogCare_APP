import 'package:dogcare/frameworks/constant.dart';
import 'package:dogcare/frameworks/engine/app_session.dart';
import 'package:dogcare/settings/aboutus.dart';
import 'package:dogcare/settings/dogshealthrecord.dart';
import 'package:dogcare/settings/expertlist.dart';
import 'package:dogcare/settings/privacypolicy.dart';
import 'package:dogcare/settings/shareapp.dart';
import 'package:dogcare/settings/ternandcondition.dart';
import 'package:dogcare/settings/userinfo.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../frameworks/authentication/login_page.dart';
import '../frameworks/maasss_helper.dart';
import '../frameworks/widget_helper.dart';
import '../main.dart';
import '../tabbarcontroler.dart';

class Settings extends StatefulWidget {
  const Settings({Key? key}) : super(key: key);

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> implements InterfaceAlertView{
  List settingsArray = [];
  late BuildContext _context;
  String shareMessage= 'Comming Soon...';
  bool  yesNoAlertViewFlag = false;

  @override
  void initState() {
    super.initState();
    defaultData();
  }

  void defaultData() {
    Map<String, dynamic> userDic1 = Map<String, dynamic>();
    userDic1['name'] = 'User Info';
    settingsArray.add(userDic1);

    Map<String, dynamic> userDic2 = Map<String, dynamic>();
    userDic2['name'] = 'Dogs past health records';
    if(App_Session.userTypes==userTypePetUser){
      settingsArray.add(userDic2);
    }

    Map<String, dynamic> userDic5 = Map<String, dynamic>();
    userDic5['name'] = 'About App';
    settingsArray.add(userDic5);

    Map<String, dynamic> userDic6 = Map<String, dynamic>();
    userDic6['name'] = 'Share app';
    settingsArray.add(userDic6);

    Map<String, dynamic> userDic7 = Map<String, dynamic>();
    userDic7['name'] = 'List of experts';
    if(App_Session.userTypes==userTypePetUser){
      settingsArray.add(userDic7);
    }

  }

  @override
  Widget build(BuildContext context) {
    _context = context;
    return Scaffold(
      body: SafeArea(
        child: Stack(children: [
          Column(
            children: [
              Container(
                color: Color.fromRGBO(90, 53, 190, 1),
                height: 64,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: 40,
                      width: 40,
                    ),
                    Text(
                      'Settings',
                      style: TextStyle(fontSize: 22,color: Colors.white),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 10.0, top: 10),
                      child: Container(
                        height: 40,
                        width: 40,
                        child: IconButton(
                          icon: const Icon(Icons.logout, color: Colors.white),
                          onPressed: (){
                            setState(() {
                              MyApp.appEngine.maasssWidgetHelper.interfaceAlertView = this;
                              yesNoAlertViewFlag = true;
                            });

                          },
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  margin: EdgeInsets.only(left: 10,right: 10,top: 20),
                  child: settingsListView(context),
                ),
              )
            ],
          ),
          if(yesNoAlertViewFlag)
            MyApp.appEngine.maasssWidgetHelper.alertViewButtonAndMessage(context, 'Logout', 'Do you want to logout now?', 'Yes', 'No')

        ],),

      ),
    );
  }

  Widget settingsListView(BuildContext context) {
    return ListView.separated(
      itemCount: settingsArray.length,
      separatorBuilder: (context, index) {
        return Divider(height: 1,);
      },
      itemBuilder: adapter,
    );
  }

  Widget adapter(BuildContext context, int index) {
    return Stack(
      children: [
        GestureDetector(
          child: Card(
            shape: RoundedRectangleBorder(
              side: BorderSide(
                color: Colors.grey,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            elevation: 10,
            shadowColor: Colors.grey,
            child: Container(
              height: 60,
              child: Padding(
                padding: const EdgeInsets.only(left: 8.0,right: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      settingsArray[index]['name'],
                      style: TextStyle(fontSize: 20),
                    ),
                    Container(
                      width: 40,
                      child: IconButton(
                        icon: Icon(Icons.navigate_next,size: 30,), onPressed: () {},
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          onTap: () {
            tabForCreateListItems(index);
            //Navigator.push(context, MaterialPageRoute(builder: (context) => DogDetail()));
          },
        )
      ],
    );
  }

  @override
  void alertViewButtonClicked(String buttonName)
  {
    if(buttonName=='Yes'){
      maasss_Helper_RemoveInternalFile('settings.txt');
      Navigator.of(_context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_context) => Login()),
              (Route<dynamic> route) => false);
      setState(() {
        yesNoAlertViewFlag = false;
      });
    }
    else if(buttonName=='No'){
      setState(() {
        yesNoAlertViewFlag = false;
      });
    }
  }

  tabForCreateListItems(int index) {
    if (settingsArray[index]['name'] == 'User Info') {
      Navigator.push(
          _context, MaterialPageRoute(builder: (context) => UserInfo()));
    } else if (settingsArray[index]['name'] == 'Dogs past health records') {
      Navigator.push(
          _context, MaterialPageRoute(builder: (context) => DogsHealthRecord()));
    } else if (settingsArray[index]['name'] == 'Privacy policy') {
      Navigator.push(
          _context, MaterialPageRoute(builder: (context) => PrivacyPolicy()));
    } else if (settingsArray[index]['name'] == 'Terms and condition') {
      Navigator.push(_context,
          MaterialPageRoute(builder: (context) => TermAndCondition()));
    } else if (settingsArray[index]['name'] == 'About us') {
      Navigator.push(
          _context, MaterialPageRoute(builder: (context) => AboutUs()));
    } else if (settingsArray[index]['name'] == 'Share app') {
      shareDownloadedCode();
    } else if (settingsArray[index]['name'] == 'List of experts') {
      Navigator.push(
          _context, MaterialPageRoute(builder: (context) => ExpertList()));
    }

  }

  Future<void> shareDownloadedCode() async
  {
    await Share.share(shareMessage);
  }
}
