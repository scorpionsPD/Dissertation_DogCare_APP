import 'package:flutter/material.dart';
import 'package:flutter_animator/widgets/fading_entrances/fade_in_down.dart';

import '../frameworks/engine/app_session.dart';
import '../main.dart';

class ShareApp extends StatefulWidget {
  const ShareApp({Key? key}) : super(key: key);

  @override
  State<ShareApp> createState() => _ShareAppState();
}

class _ShareAppState extends State<ShareApp> {
  TextEditingController codeTextFormEdit = new TextEditingController();
  String shareCode = 'Generate';
  String shareMessage = '';
  late BuildContext buildContext;

  @override
  void initState() {
    super.initState();

  }


  @override
  Widget build(BuildContext context) {
    buildContext = context;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            appBar(context),
            shareAppBtn(context),
            containt(context),
          ],
        ),
      ),
    );
  }

  Widget appBar(BuildContext context){
    return Container(
      color: Color.fromRGBO(90, 53, 190, 1),
      height: 64,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ),
          Text(
            'Share App',
            style: TextStyle(fontSize: 22,color: Colors.white),
          ),
          Container(
            height: 40,
            width: 40,
          )
        ],
      ),
    );
  }
  Widget shareAppBtn(BuildContext context)
  {
    return Row(
      children: [
        Stack(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 10.0,top: 10),
              child: Container(
                height: 60,
                width: 230,
                child: Card(
                  elevation: 25,
                  shadowColor: Colors.black,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15.0)),
                  child: Column(
                    children: [
                      Padding(
                        padding:
                        EdgeInsets.only( left: 20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children:  [
                            FadeInDown(
                              child: Container(
                                margin: const EdgeInsets.only(
                                    top: 10),
                                child: const Text(
                                  'Share App',
                                  style: TextStyle(
                                      fontSize: 25,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              width: 240,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(

                  ),
                ],
              ),
            ),

          ],

        ),

      ],
    );
  }
  Widget containt (BuildContext context)
  {
    return Container(
      width: MediaQuery.of(context).size.width-10,
      height: 285,


      // height: MediaQuery.of(context).size.width,
      // width: MediaQuery.of(context).size.width,
      child: Padding(
        padding: const EdgeInsets.only(left: 20.0,right: 20,top: 25),
        child: Column(
          children:  [
            Text('Please Share this App',
              textAlign: TextAlign.justify,style: const TextStyle(fontSize:18,color: Colors.grey),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 25.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children:  [
                  const Text('Your Code:',style:TextStyle(fontSize: 20,color: Colors.purple,fontWeight: FontWeight.bold),),
                  GestureDetector(
                      child: Container(
                        height: 45,
                        width: 180,
                        //  color: Colors.purple,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(50.0),
                          color: Colors.purple[100]?.withOpacity(0.7),
                        ),
                        child:  Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text(shareCode,textAlign: TextAlign.center,style: const TextStyle(fontSize: 25,fontWeight: FontWeight.bold),),
                        ),
                      ),
                      onTap:()
                      {
                        //createShareCodeRequest();
                      }
                  ),
                ],
              ),
            ),
            entercodesubmitcode(context)
          ],
        ),
      ),
    );
  }
  Widget entercodesubmitcode (BuildContext context)
  {
    return Padding(
      padding: const EdgeInsets.only(
          top: 10),
      child: InkWell(
        onTap: () {
          //registerUserRequest();
        },
        child: Card(
          color: Color.fromRGBO(230, 229, 240, 1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Container(
            width: 180,
            height: 50,
            child: const Padding(
              padding: EdgeInsets.only(top: 15.0),
              child: Text(
                "Share App",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20.0,
                  color: Color.fromRGBO(90, 53, 190, 1),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }


}
