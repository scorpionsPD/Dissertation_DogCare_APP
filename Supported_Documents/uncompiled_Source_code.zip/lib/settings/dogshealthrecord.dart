import 'dart:async';
import 'dart:convert';
import 'package:dogcare/frameworks/engine/app_engine.dart';
import 'package:flutter/material.dart';
import 'package:marquee/marquee.dart';
import '../frameworks/constant.dart';
import '../frameworks/engine/app_session.dart';
import '../frameworks/managers/progress_manager.dart';
import '../main.dart';

class DogsHealthRecord extends StatefulWidget {

  @override
  State<DogsHealthRecord> createState() => _DogsHealthRecordState();
}

class _DogsHealthRecordState extends State<DogsHealthRecord> implements Interface_API_Response_From_Engine_To_UI{

  List resultSymptomArray =[];
  List fetchConcludeHistoryArray = [];
  List dogListViewArray = [];
  List<String> dogListForDropDownMenu = [];
  int selectedIndex = 0;
  int dogSelectedIndex = 0;

  late BuildContext buildContext;
  bool cellExpendedFlag = false;

  String dropDownValue='Pet Owner';

  @override
  void initState()
  {
    super.initState();
    Timer(const Duration(milliseconds: 500), () async {
      dogNameListRequest();
    });
  }

  @override
  Widget build(BuildContext context)
  {
    buildContext = context;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            appbar(context),
            if(dogListViewArray.isNotEmpty)
              topContaint(context),
            if(fetchConcludeHistoryArray.isNotEmpty)
              Container(
                margin: EdgeInsets.only(top: 5),
              height: 30,
              width: MediaQuery.of(context).size.width,
              child: levelDescriptionDisplay(context),
            ),
            dogSymptomsListView(context),
          ],
        ),
      ),

    );
  }

  Widget appbar(BuildContext context)
  {
    return Container(
      color: Color.fromRGBO(90, 53, 190, 1),
      height: 64,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.of(context).pop(),
          ),
          Spacer(),
          Text(
            'Dog Health Record',
            style: TextStyle(fontSize: 22, color: Colors.white),
          ),
          Spacer(),

          // Useless code
        ],
      ),
    );
  }

  Widget topContaint(BuildContext context)
  {
    return Column(
      children: [
        Row(
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Text(dogListViewArray[dogSelectedIndex]['pat_name'],
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
                margin: EdgeInsets.only(left: 10),
                height: 70,
                width: 70,
                child: Image.network('http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/uploads/pets/'+'/'+ MyApp.appEngine.getSinglePetImage(dogListViewArray[dogSelectedIndex]['pet_images']),
                  height: 80,
                  width: 100,
                  fit: BoxFit.fill,)
            ),
            if(dogListForDropDownMenu.length>0)
              DropdownButton(
                value: dropDownValue,
                icon: Icon(Icons.keyboard_arrow_down),
                items:dogListForDropDownMenu.map((String items)
                {
                  return DropdownMenuItem(
                      value: items,
                      child: Text(items)
                  );
                }
                ).toList(),
                onChanged: (newValue)
                {
                  setState(()
                  {
                    dropDownValue = newValue.toString();
                    for(int i =0; i<dogListForDropDownMenu.length;i++){
                      if(dropDownValue.contains(dogListForDropDownMenu[i].toString())){
                        dogSelectedIndex = i;
                        break;
                      }
                    }
                    fetchConcludeHistoryRequest();
                  });
                },

              ),
          ],
        ),
      ],
    );
  }

  Widget dogSymptomsListView(BuildContext context)
  {
    return Container(
      height: MediaQuery.of(context).size.height-300,
      child: ListView.builder(
        itemCount: fetchConcludeHistoryArray.length,
        itemBuilder: adapter,
      ),
    );
  }

  Widget adapter(BuildContext context, int index)
  {
    return Container(
      margin: EdgeInsets.only(top: 10,left: 10,right: 10),
      decoration: BoxDecoration(
          border: Border.all(color: Colors.grey, width: 3.0,),
          shape: BoxShape.rectangle,
          borderRadius: BorderRadius.all(Radius.circular(10))
      ),
      child: Column(
        children: [
          Container(
            margin: EdgeInsets.only(left: 10,right: 50,top: 5),
            width: MediaQuery.of(context).size.width,
            child: Text(fetchConcludeHistoryArray[index]['created_date'].toString(),style: TextStyle(fontSize: 18),textAlign: TextAlign.start,),
          ),
          Container(
            margin: EdgeInsets.only(left: 10,top: 5),
            width: MediaQuery.of(context).size.width,
            child: Text(fetchConcludeHistoryArray[index]['request'].toString(),
              style: TextStyle(
                  fontSize: 18,
                  color: Colors.black
              ),textAlign: TextAlign.start,),
          ),
          if(cellExpendedFlag && selectedIndex == index)
            Container(
                height: double.parse((20+(55*resultSymptomArray.length)).toString()),
                color: Colors.purple[50],
                child: moreDogSymptomsListView(context)),
          Container(
            margin: EdgeInsets.all(5),
            width: MediaQuery.of(context).size.width,
            child: GestureDetector(
              child: Text((cellExpendedFlag == true && selectedIndex == index)?'Less...':'More...',style: TextStyle(
                  fontSize: 18,
                  color: Colors.purple ),
                textAlign: TextAlign.right,
              ),
              onTap: (){
                setState(()
                {
                  if(selectedIndex==index && cellExpendedFlag==true){
                    cellExpendedFlag = false;
                    resultSymptomArray.clear();
                  }
                  else{
                    cellExpendedFlag = true;
                    resultSymptomArray.clear();
                    resultSymptomArray.addAll(jsonDecode(fetchConcludeHistoryArray[index]['symptom_levels'].toString()));
                  }
                  selectedIndex = index;
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget moreDogSymptomsListView(BuildContext context)
  {
    return ListView.builder(
      physics:  NeverScrollableScrollPhysics(),
      itemCount: resultSymptomArray.length,
      itemBuilder: adapter1,
    );
  }

  Widget adapter1(BuildContext context, int index)
  {
    return Container(
      margin: EdgeInsets.only(top: 10,),
      child: Column(
        children: [
          Container(
            margin: EdgeInsets.only(left: 10,top: 5),
            child: Column(
              children: [
                Text('Symptom: ' +resultSymptomArray[index]['symptoms'].toString()),
                Text('Level: '+resultSymptomArray[index]['level'].toString()),
              ],
            ),
          ),
        ],
      ),
    );
  }


  /// marquee
  Widget levelDescriptionDisplay(BuildContext context) {
    return Marquee(
      text: levelsInfoForMarque,
      style: const TextStyle(color: Colors.black, fontSize: 20),
      scrollAxis: Axis.horizontal,
      blankSpace: 20,
      velocity: 80.0,
      showFadingOnlyWhenScrolling: false,
      fadingEdgeStartFraction: 0.1,
      fadingEdgeEndFraction: 0.1,
      startPadding: 20.0,
      //decelerationDuration: Duration(milliseconds: 500),
      decelerationCurve: Curves.easeOut,
    );
  }

  void dogNameListRequest() async
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    {
      //ProgressManager.showAlertDialog(buildContext, "Loading...");
      Map<String, dynamic> requestData = Map<String, dynamic>();
      requestData["user_id"] = App_Session.userId;
      MyApp.appEngine.api_Request(requestData, "", "FetchAllPetByUser");
    }
  }

  void fetchConcludeHistoryRequest() async
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    {
      ProgressManager.showAlertDialog(buildContext, "Loading...");
      Map<String, dynamic> requestData = Map<String, dynamic>();

      requestData["user_id"] = App_Session.userId;
      requestData["pet_id"] = dogListViewArray[dogSelectedIndex]['pet_id'].toString();
      MyApp.appEngine.api_Request(requestData, "", "FetchConcludeHistory");
    }
  }

  @override
  Future<void> api_Response_To_UI(
      Map<String, dynamic> responseDictionary, String apiName) async {
    if (apiName.compareTo("FetchAllPetByUser") == 0) {
      if (responseDictionary['status'] == '200') {

        setState(() {
          dogListViewArray = responseDictionary['data'];
          dogSelectedIndex = 0;
          for(int i=0;i<dogListViewArray.length;i++){
            dogListForDropDownMenu.add(dogListViewArray[i]['pat_name']);
          }
          dropDownValue = dogListForDropDownMenu[0].toString();
        });
        fetchConcludeHistoryRequest();
      }
      else {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 2, 1);
      }
    }

    else if (apiName.compareTo("FetchConcludeHistory") == 0)
    {
      if (responseDictionary['status'] == '200')
      {
        setState(() {
          fetchConcludeHistoryArray = responseDictionary['data'];
        });
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
      }
      else
      {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
      }
    }
  }

  @override
  void api_Response_Error(String apiName, response) {}

}