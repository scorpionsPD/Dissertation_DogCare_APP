import 'dart:async';

import 'package:dogcare/frameworks/authentication/change_password_page.dart';
import 'package:dogcare/frameworks/engine/app_engine.dart';
import 'package:dogcare/frameworks/engine/app_session.dart';
import 'package:flutter/material.dart';

import '../frameworks/managers/progress_manager.dart';
import '../frameworks/widget_helper.dart';
import '../main.dart';

class UserInfo extends StatefulWidget {
  const UserInfo({Key? key}) : super(key: key);

  @override
  State<UserInfo> createState() => _UserInfoState();
}

class _UserInfoState extends State<UserInfo> implements Interface_API_Response_From_Engine_To_UI,InterfaceAlertView{
  TextEditingController firstnameTextEdit = new TextEditingController();
  TextEditingController lastnameTextEdit = new TextEditingController();
  TextEditingController emailTextEdit = new TextEditingController();
  TextEditingController passTextEdit = new TextEditingController();
  TextEditingController addressTextEdit = new TextEditingController();

  late BuildContext buildContext;
  bool  yesNoAlertViewFlag = false;

  @override
  void initState() {
    super.initState();
    firstnameTextEdit.text = App_Session.firstName.toString();
    lastnameTextEdit.text = App_Session.lastName.toString();
    emailTextEdit.text = App_Session.email.toString();
    addressTextEdit.text = App_Session.address.toString();
    Timer(const Duration(milliseconds: 500), () async
    {
      //updateProfileListRequest();
    });
  }

  @override
  Widget build(BuildContext context) {
    buildContext = context;
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Stack(children: [
          Column(
            children: [
              Container(
                color: Color.fromRGBO(90, 53, 190, 1),
                height: 64,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      child: IconButton(
                        icon: Icon(Icons.arrow_back, color: Colors.white),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                    ),
                    Text(
                      'My Info',
                      style: TextStyle(fontSize: 22,color: Colors.white),
                    ),
                    Container(
                      height: 40,
                      width: 40,
                    )
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 20.0),
                child: Container(
                  height: 130,
                  child:  ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(25)),
                    child: Image.asset('assets/images/dummyprofilepic.png'),),
                ),
              ),
              Container(
                height: MediaQuery.of(context).size.height-(MediaQuery.of(context).size.height-300),
                child: SingleChildScrollView(
                  reverse: true,
                  padding: EdgeInsets.only(bottom: bottom),
                  child: Column(
                    children: [
                      Padding(
                        padding:
                        const EdgeInsets.only(left: 20.0, right: 20.0,top: 10),
                        child: TextFormField(
                          controller: firstnameTextEdit,
                          keyboardType: TextInputType.text,
                          validator: (val) {
                            return val!.isEmpty
                                ? 'Please enter firstname'
                                : null;
                          },
                          decoration: InputDecoration(
                            labelText: "First Name",
                            labelStyle: TextStyle(
                                color: Colors.black),
                          ),
                          onChanged: (newValue){
                            setState(() {
                              firstnameTextEdit.text = App_Session.firstName;
                            });
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, right: 20.0),
                        child: Stack(
                          children: [
                            Container(
                              child: TextFormField(
                                controller: lastnameTextEdit,
                                keyboardType: TextInputType.text,
                                validator: (val) {
                                  return val!.isEmpty
                                      ? 'Please enter last name'
                                      : null;
                                },
                                decoration: InputDecoration(
                                  labelText: "Last Name",
                                  labelStyle:
                                  TextStyle(color: Colors.black),
                                ),
                              ),
                            )],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, right: 20.0),
                        child: Stack(
                          children: [
                            Container(
                              child: TextFormField(
                                controller: emailTextEdit,
                                validator: (val) {
                                  return val!.isEmpty ? 'Please enter email' : null;
                                },
                                decoration: InputDecoration(
                                  labelText: 'Email Id',
                                  labelStyle:
                                  TextStyle(color: const Color(0xFF424242)),
                                ),
                              ),
                            )],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, right: 20.0),
                        child: Stack(
                          children: [
                            TextFormField(
                              controller: passTextEdit,
                              readOnly: true,
                              validator: (val) {
                                return val!.isEmpty
                                    ? 'Please enter password'
                                    : null;
                              },
                              decoration: InputDecoration(
                                labelText: 'Password',
                                labelStyle:
                                TextStyle(color: const Color(0xFF424242),
                                ),
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                GestureDetector(
                                  child: Container(
                                    margin: EdgeInsets.only(top: 15),
                                    height: 30,
                                    width: 90,
                                    decoration: BoxDecoration(
                                        shape: BoxShape.rectangle,
                                        border: Border.all(color: Colors.black),
                                        borderRadius: BorderRadius.all(Radius.circular(7))
                                    ),
                                    child: Center(child: Text('Change',style: TextStyle(fontSize: 20),)),
                                  ),
                                  onTap: (){
                                    Navigator.push(
                                        buildContext, MaterialPageRoute(builder: (context) => ChangePassword()));
                                  },
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 20.0, right: 20.0),
                        child: Stack(
                          children: [
                            Container(
                              child: TextFormField(
                                controller: addressTextEdit,
                                validator: (val) {
                                  return val!.isEmpty ? 'Please enter address' : null;
                                },
                                decoration: InputDecoration(
                                  labelText: "address",
                                  labelStyle: TextStyle(color: Colors.black),
                                ),
                              ),
                            )],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 20,left: 20),
                height: 40,
                child: Row(
                  children: [
                    Text('Number of Dogs : ',style: TextStyle(fontSize: 20)),
                    Text(App_Session.numberOfDogs.toString(),style: TextStyle(fontSize: 20)),
                  ],
                ),
              ),
            ],
          ),
          if(yesNoAlertViewFlag)
            MyApp.appEngine.maasssWidgetHelper.alertViewButtonAndMessage(context, 'User Profile', 'Do you want to update your profile?', 'Yes', 'No')
        ],
        ),

      ),
      bottomNavigationBar:InkWell(
        onTap: () {
          updateProfileListRequest();

        },
        child: Card(
          color: Color.fromRGBO(230, 229, 240, 1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Container(
            width: 180,
            height: 50,
            child: const Padding(
              padding: EdgeInsets.only(top: 10.0),
              child: Text(
                "Update",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20.0,
                  color: Color.fromRGBO(90, 53, 190, 1),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /*yesNoAlertView(BuildContext context) {
    return showDialog(
      context: context,
      builder: (BuildContext context){
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Align(
            alignment: Alignment.center,
            child: Container(
              height: 150,
              width: 280,
              decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.all(Radius.circular(12))),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 15.0),
                    child: Text(
                      'Do you want to Update?',
                      style: TextStyle(
                          color: Colors.white, fontSize: 19,decoration: TextDecoration.none),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 32.0),
                    child: Column(
                      children: [
                        Container(
                          height: 1,
                          width: 278,
                          color: Colors.white,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            GestureDetector(
                                child: Text(
                                  "Yes",
                                  style: TextStyle(color: Colors.blue,fontSize: 18,decoration: TextDecoration.none),
                                ),
                                onTap: () {
                                  updateProfileListRequest();
                                                             }
                                                             ),
                            Container(
                              height:75,
                              width: 1,
                              color: Colors.white,
                            ),
                            GestureDetector(
                                child: Text(
                                  "No",
                                  style: TextStyle(color: Colors.blue,fontSize: 18,decoration: TextDecoration.none),
                                ),
                                onTap: () {
                                  Navigator.of(context).pop();
                                }),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );

      },
    );
  }*/

  @override
  void alertViewButtonClicked(String buttonName)
  {
    if(buttonName=='Yes'){

      MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
      ProgressManager.showAlertDialog(buildContext, "Loading...");
      Map<String, dynamic> requestData = Map<String, dynamic>();
      requestData["user_id"] = App_Session.userId;
      requestData["firstname"] = firstnameTextEdit.text;
      requestData["lastname"] = lastnameTextEdit.text;
      requestData["address"] = addressTextEdit.text;

      MyApp.appEngine.api_Request(requestData, "", "UpdateProfile");
      setState(() {
        yesNoAlertViewFlag = false;
      });
    }
    else if(buttonName=='No'){
      setState(() {
        yesNoAlertViewFlag = false;
      });
    }
  }

  void updateProfileListRequest()
  {
    if (firstnameTextEdit.text.length <= 0) {
      ProgressManager.showAlertDialogWithAutoDismiss(
          buildContext, "Please enter firstname.", 2, 0);
    } else if (lastnameTextEdit.text.length <= 0) {
      ProgressManager.showAlertDialogWithAutoDismiss(
          buildContext, "Please enter lastname.", 2, 0);
    } else if (addressTextEdit.text.length <= 0) {
      ProgressManager.showAlertDialogWithAutoDismiss(
          buildContext, "Please enter address.", 2, 0);
    }
    else {
      MyApp.appEngine.maasssWidgetHelper.interfaceAlertView = this;
      setState(() {
        yesNoAlertViewFlag = true;
      });
    }

  }

  @override
  Future<void> api_Response_To_UI(
      Map<String, dynamic> responseDictionary, String apiName) async
  {
    if (apiName.compareTo("UpdateProfile") == 0)
    {
      if (responseDictionary['status'] == '200')
      {
        setState(() {
          App_Session.firstName = firstnameTextEdit.text;
          App_Session.lastName = lastnameTextEdit.text;
          App_Session.address = addressTextEdit.text;
        });
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
      }
      else
      {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
      }
    }
  }

  @override
  void api_Response_Error(String apiName, response) {
  }
}
