import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:dogcare/frameworks/engine/app_engine.dart';
import 'package:dogcare/request/createrequest.dart';
import 'package:dogcare/request/reply.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../frameworks/constant.dart';
import '../frameworks/engine/app_session.dart';
import '../frameworks/managers/progress_manager.dart';
import '../home/symptoms.dart';
import '../main.dart';

class Requester extends StatefulWidget {
  const Requester({Key? key}) : super(key: key);

  @override
  State<Requester> createState() => _RequesterState();
}

class _RequesterState extends State<Requester> implements Interface_API_Response_From_Engine_To_UI{
  List<dynamic> symptomAndConcludeRecordArray = [];
  List systemAndPicturesChatArray = [];
  List resultSymptomArray =[];
  List moreResultSymptomArray =[];
  List dogListViewArray = [];
  List petImageDetailArray = [];
  List<String> dogListForDropDownMenu = [];
  List listOfMyDogsRequestReply = [];
  List symptomsImageList = [];
  int selectedIndex = 0;
  late BuildContext buildContext;
  bool cellExpendedFlag = false;
  String dropDownValue='Pet Owner';
  late ScrollController _scrollController;
  int scrollingIndex=0;
  int deletedImageIndex = -1;
  bool fullPageHorizontalImage = false;

  @override
  void initState()
  {
    super.initState();
    Timer(const Duration(milliseconds: 500), () async {
      if(App_Session.userTypes==userTypePetUser){
        dogNameListRequest();
      }
      else{
        allRequests();
      }
    });
    _scrollController = ScrollController();

  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context)
  {
    buildContext = context;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                appbar(context),
                if(dogListViewArray.isNotEmpty)
                  topContaint(context),
                //if(App_Session.userTypes==UserTypePetUser)
                  dogSymptomsChatListView(context),
                if(App_Session.userTypes==userTypePetUser)
                  bottomButton(context),
              ],
            ),
            if(fullPageHorizontalImage==true)
              Container(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                color:Colors.black87,
                child: Column(children: [
                  IconButton(
                      icon: const Icon(
                        Icons.cancel,
                        color: Colors.red,
                        size: 50,
                      ),
                      onPressed: () {
                        setState(() {
                          fullPageHorizontalImage = !fullPageHorizontalImage;
                        });
                      }),
                  Spacer(),
                  Center(child: petImageHorizontalScrollListView(context)),
                  Spacer(),
                ],),

              )
          ],
        ),
      ),

    );
  }

  Widget appbar(BuildContext context)
  {
    return Container(
      color: Color.fromRGBO(90, 53, 190, 1),
      height: 64,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Spacer(),
          Text(App_Session.userTypes==userTypePetUser?'Request':'All Request',style: TextStyle(fontSize: 22, color: Colors.white)),
          Spacer(),

        ],
      ),
    );
  }

  Widget topContaint(BuildContext context)
  {
    return Column(
      children: [
        Row(
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Text(dogListViewArray[selectedIndex]['pat_name'],
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
                margin: EdgeInsets.only(left: 10),
                height: 70,
                width: 70,
                child: Image.network('http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/uploads/pets/'+'/'+ MyApp.appEngine.getSinglePetImage(dogListViewArray[0]['pet_images']),
                  height: 80,
                  width: 100,
                  fit: BoxFit.fill,)
            ),
            if(dogListForDropDownMenu.length>0)
              DropdownButton(
                value: dropDownValue,
                icon: Icon(Icons.keyboard_arrow_down),
                items:dogListForDropDownMenu.map((String items)
                {
                  return DropdownMenuItem(
                      value: items,
                      child: Text(items)
                  );
                }
                ).toList(),
                onChanged: (newValue){
                  setState(() {
                    dropDownValue = newValue.toString();
                    for(int i =0; i<dogListForDropDownMenu.length;i++)
                    {
                      if(dropDownValue.contains(dogListForDropDownMenu[i].toString())){
                        selectedIndex = i;
                        ProgressManager.showAlertDialog(buildContext, "Loading...");
                        myDogListRequests();
                        break;
                      }
                    }
                  });
                },

              ),
          ],
        ),
      ],
    );
  }

  Widget bottomButton(BuildContext context)
  {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.only(top:5,left: 20),
          child: InkWell(
            onTap: () {
              CreateRequest createRequest = CreateRequest();
              createRequest.dogDetail = dogListViewArray[selectedIndex];
              Navigator.push(
                  buildContext, MaterialPageRoute(builder: (context) => createRequest));
            },
            child: Card(
              color: Color.fromRGBO(230, 229, 240, 1),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Container(
                width: 180,
                height: 40,
                child: Center(
                  child: Text(
                    "Create Request",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20.0,
                      color: Color.fromRGBO(90, 53, 190, 1),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void scrollToBottom() {
    final bottomOffset = _scrollController.position.maxScrollExtent;
    _scrollController.animateTo(
      bottomOffset,
      duration: Duration(milliseconds: 1000),
      curve: Curves.easeInOut,
    );
  }

  Widget dogSymptomsChatListView(BuildContext context)
  {
    return Expanded(child: ListView.builder(
      reverse: false,
      controller: _scrollController,
      itemCount: listOfMyDogsRequestReply.length,
      itemBuilder: adapterChatList,
    ),);
  }

  Widget adapterChatList(BuildContext context, int index)
  {
    return Container(
      margin: EdgeInsets.only(top: 10,left: 10,right: 10),
      decoration: BoxDecoration(
          shape: BoxShape.rectangle,
          borderRadius: BorderRadius.all(Radius.circular(19)),
          border: Border.all(color: Colors.black)
      ),
     child: Column(
       children: [
         Padding(
           padding: App_Session.userTypes==userTypePetUser?const EdgeInsets.only(left:100.0):const EdgeInsets.only(right:100.0),
           child: bubbleRight(context,index),
         ),
         if(int.parse(listOfMyDogsRequestReply[index]['expert_id'].toString())>0)
          Padding(
            padding: App_Session.userTypes==userTypePetUser?const EdgeInsets.only(right:100.0):const EdgeInsets.only(left:100.0),
            child: bubbleLeft(context, index),
          )
       ],
     ),
    );
  }

  Widget bubbleLeft(BuildContext context,int index){
    return Row(
      mainAxisAlignment: App_Session.userTypes==userTypePetUser?MainAxisAlignment.start:MainAxisAlignment.end,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Flexible(
          child: Padding(
            padding: const EdgeInsets.only(left: 5.0,right: 5),
            child: Container(
              padding: const EdgeInsets.all(15),
              margin: const EdgeInsets.only(bottom: 5),
              decoration: BoxDecoration(
                color: Colors.indigo.shade100,
                borderRadius: const BorderRadius.all(
                    Radius.circular(19)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                Text(
                  'Replied By: '+listOfMyDogsRequestReply[index]['expert_name'],
                  style: TextStyle(color: Colors.black, fontSize: 20,fontWeight: FontWeight.bold),
                ),
                Text(
                  listOfMyDogsRequestReply[index]['expert_reply'],
                  style: TextStyle(color: Colors.black, fontSize: 15),
                ),
              ],
              ),
            ),
          ),
        ),
        // CustomPaint(painter: Triangle(Colors.indigo.shade600)),
      ],
    );
  }
  Widget bubbleRight(BuildContext context, int index)
  {
    return Row(
      mainAxisAlignment: App_Session.userTypes==userTypePetUser?MainAxisAlignment.end:MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Flexible(
          child: Padding(
            padding: const EdgeInsets.only(right: 5.0,top: 5,left: 5),
            child: Container(
              padding: const EdgeInsets.all(15),
              margin: const EdgeInsets.only(bottom: 5),
              decoration: BoxDecoration(
                color: Colors.indigo.shade600,
                borderRadius: const BorderRadius.all(
                  Radius.circular(19))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                const Text(
                'Request: ',
                style: TextStyle(color: Colors.white,
                    fontSize: 20,fontWeight: FontWeight.bold),
              ),
                Text(
                  listOfMyDogsRequestReply[index]['request'],
                  style: TextStyle(color: Colors.white, fontSize: 15),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child:
                  InkWell(
                    onTap: () {
                      Symptoms symptoms = Symptoms();
                      symptoms.requestDetail = listOfMyDogsRequestReply[index];
                      Navigator.push(
                          buildContext, MaterialPageRoute(builder: (context) => symptoms));
                      },
                    child: Card(
                      color: const Color.fromRGBO(230, 229, 240, 1),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5.0),
                      ),
                      child: Container(
                        width: MediaQuery.of(context).size.width-120,
                        height: 30,
                        child: const Text(
                          "Symptoms",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 20.0,
                            color: Color.fromRGBO(90, 53, 190, 1),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                  if(listOfMyDogsRequestReply[index]['attachment_list'].toString().isNotEmpty)
                  GestureDetector(
                    child: Container(
                      width: MediaQuery.of(context).size.width-120,
                      child: Image.network(applyServer+'dog_care/uploads/symptom_attachments/'+ MyApp.appEngine.getSinglePetImage(listOfMyDogsRequestReply[index]['attachment_list']),
                      fit: BoxFit.cover,
                      ),
                    ),
                    onTap: (){
                      setState(() {
                        getAllPetImage(listOfMyDogsRequestReply[index]['attachment_list']);
                        fullPageHorizontalImage = !fullPageHorizontalImage;
                      });

                    },
                  ),
                if(App_Session.userTypes==userTypePetExpert)
                  Padding(
                  padding: const EdgeInsets.only(top: 5),
                  child: InkWell(
                    onTap: () {
                      Reply reply = Reply();
                      reply.petRequest = listOfMyDogsRequestReply[index];
                      Navigator.push(
                          buildContext, MaterialPageRoute(builder: (context) => reply));
                    },
                    child: Card(
                      color: Color.fromRGBO(230, 229, 240, 1),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      child: Center(
                        child: Container(
                          width: 110,
                          height: 30,
                          child: const Center(
                            child: Text(
                              "Reply",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 20.0,
                                color: Color.fromRGBO(90, 53, 190, 1),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
              ),
            ),
          ),
        ),
        // CustomPaint(painter: Triangle(Colors.indigo.shade600)),
      ],
    );
  }

  void getAllPetImage(String petImages){
    symptomsImageList.clear();
    final splitImageArray = petImages.split(',');
    symptomsImageList.addAll(splitImageArray);
  }

  Widget petImageHorizontalScrollListView(BuildContext context)
  {
    return SizedBox(
         height: MediaQuery.of(context).size.width,
          width: MediaQuery.of(context).size.width,
      child:ListView.builder(
    itemCount: symptomsImageList.length,
    scrollDirection: Axis.horizontal,
    itemBuilder: adapter,
  ));
  }

  Widget adapter(BuildContext context, int index) {
    return Stack(
      children: [
        Container(
          height: MediaQuery.of(context).size.width,
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(shape: BoxShape.rectangle),
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: GestureDetector(
                child: Image.network(applyServer+'dog_care/uploads/symptom_attachments/'+ symptomsImageList[index],
                  fit: BoxFit.cover,
                ),
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _showImageDeleteAlertDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(
              "Are you sure you want to delete?",
              style: TextStyle(color: Colors.blue),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: [
                  Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      setState(() {
                        listOfMyDogsRequestReply.removeAt(deletedImageIndex);
                        Navigator.of(context).pop();
                      });
                    },
                    title: Text("Delete"),
                    leading: Icon(
                      Icons.delete,
                      color: Colors.blue,
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      Navigator.of(context).pop();
                      deletedImageIndex = -1;
                    },
                    title: Text("Cancel"),
                    leading: Icon(
                      Icons.cancel,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }


  void dogNameListRequest() async
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    ProgressManager.showAlertDialog(buildContext, "Loading...");
    Map<String, dynamic> requestData = Map<String, dynamic>();
    requestData["user_id"] = App_Session.userId;
    MyApp.appEngine.api_Request(requestData, "", "FetchAllPetByUser");
  }

  void myDogListRequests() async
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    Map<String, dynamic> requestData = Map<String, dynamic>();
    requestData["user_id"] = App_Session.userId;
    requestData["pet_id"] = dogListViewArray[selectedIndex]['pet_id'];

    //ListOfAllRequests
    MyApp.appEngine.api_Request(requestData, "", "ListOfMyDogRequests");

  }

  void allRequests() async
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    ProgressManager.showAlertDialog(buildContext, "Loading...");
    Map<String, dynamic> requestData = Map<String, dynamic>();
    requestData["user_id"] = App_Session.userId;
    MyApp.appEngine.api_Request(requestData, "", "ListOfAllRequests");

  }

  @override
  Future<void> api_Response_To_UI(
      Map<String, dynamic> responseDictionary, String apiName) async
  {
    if (apiName.compareTo("FetchAllPetByUser") == 0)
    {
      if (responseDictionary['status'] == '200')
      {

        setState(() {
          dogListViewArray = responseDictionary['data'];
          selectedIndex = 0;
          for(int i=0;i<dogListViewArray.length;i++){
            dogListForDropDownMenu.add(dogListViewArray[i]['pat_name']);
          }
          dropDownValue = dogListForDropDownMenu[0].toString();
          myDogListRequests();

        });

      } else {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 2, 1);
      }
    }
    else if(apiName.compareTo("ListOfMyDogRequests")==0 || apiName.compareTo("ListOfAllRequests")==0)
    {
      if (responseDictionary['status'] == '200') {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
        setState(() {
          listOfMyDogsRequestReply = responseDictionary['data'];
        });

      } else {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 2, 1);
      }
    }
  }

  @override
  void api_Response_Error(String apiName, response) {}

}
