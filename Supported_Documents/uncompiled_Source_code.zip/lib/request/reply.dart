import 'package:dogcare/frameworks/engine/app_engine.dart';
import 'package:dogcare/frameworks/engine/app_session.dart';
import 'package:flutter/material.dart';

import '../frameworks/managers/progress_manager.dart';
import '../frameworks/widget_helper.dart';
import '../home/symptoms.dart';
import '../main.dart';

class Reply extends StatefulWidget {
  //const Reply({Key? key}) : super(key: key);

  var petRequest = Map<String,dynamic>();

  @override
  State<Reply> createState() => _ReplyState();
}

class _ReplyState extends State<Reply> implements Interface_API_Response_From_Engine_To_UI,InterfaceAlertView{
  late BuildContext buildContext;
  TextEditingController messageTextEdit = TextEditingController();
  List imageArray =[];
  bool  yesNoAlertViewFlag = false;

  @override
  void initState() {
    super.initState();
    getAllPetSymptomsImage(widget.petRequest['attachment_list']);
  }

  @override
  Widget build(BuildContext context) {
    buildContext = context;
    return Scaffold(
      body: SafeArea(
        child: Stack(children: [
          Column(
            children: [
              appbar(context),
              replyHere(context),
              Padding(
                padding: const EdgeInsets.only(left: 10,right: 10.0,top: 10),
                child: Container(
                  decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                      border: Border.all(color: Colors.black)),
                  child: Column(
                    children: [
                      middleContaint(context),
                      if(imageArray.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Container(
                            height: 300,
                            child: petImageDetailListView(context),
                          ),
                        ),

                    ],
                  ),
                ),
              ),
              symtomsButton(context),
            ],
          ),
          if(yesNoAlertViewFlag)
            MyApp.appEngine.maasssWidgetHelper.alertViewButtonAndMessage(context, 'Reply', 'Do you want to reply on this request?', 'Yes', 'No')
        ],
        ),

      ),
      bottomNavigationBar: BottomAppBar(

        child: Padding(
          padding: const EdgeInsets.only(left: 10,right: 10,
              top: 10,bottom: 10),
          child: InkWell(
            onTap: () {
              expertReplyRequest();
            },
            child: Card(
              color: Color.fromRGBO(230, 229, 240, 1),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Container(
                width: 140,
                height: 50,
                child: const Padding(
                  padding: EdgeInsets.only(top: 15.0),
                  child: Text(
                    "Submit",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20.0,
                      color: Color.fromRGBO(90, 53, 190, 1),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget appbar(BuildContext context) {
    return Container(
      color: Color.fromRGBO(90, 53, 190, 1),
      height: 64,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.of(context).pop(),
          ),
          Spacer(),
          Text(
            'Reply',
            style: TextStyle(fontSize: 22, color: Colors.white),
          ),
          Spacer(),

          // Useless code
        ],
      ),
    );
  }

  Widget replyHere(BuildContext context){
    return Padding(
      padding: const EdgeInsets.only(left: 10.0,right: 10,top: 10),
      child: Container(
        height: 100,
        child: TextFormField(
          minLines: null,
          maxLines: null,
          expands: true,
          maxLength: 400,
          //keyboardType: TextInputType.multiline,
          keyboardType: TextInputType.text,
          controller: messageTextEdit,
          validator: (val) {
            return val!.isEmpty ? 'Please enter message' : null;
          },
          decoration: const InputDecoration(
            labelText: "Reply here...",
            enabledBorder: OutlineInputBorder(
              //borderRadius: BorderRadius.all(Radius.circular(30)),
              borderSide: BorderSide(
                color: Colors.grey,
                width: 2.0,
              ),
            ),
            labelStyle: TextStyle(
              color: Colors.black,
            ),

          ),
        ),
      ),
    );
  }

  Widget middleContaint(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 15,left: 10,right: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Request to : ',
            style: TextStyle(fontSize: 22,fontWeight: FontWeight.bold),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: Container(
              //height: 120,
              child: Expanded(
                child: Text(
                   widget.petRequest['request'],textAlign:TextAlign.justify,
                  style: TextStyle(fontSize: 20),
                ),
              ),
            ),
          ),


        ],
      ),
    );
  }

  Widget symtomsButton(BuildContext context){
    return   Padding(
      padding: const EdgeInsets.only(top: 20, left: 20,bottom: 10),
      child: InkWell(
        onTap: () {
          Symptoms symptoms = Symptoms();
          symptoms.requestDetail = widget.petRequest;
          Navigator.push(
              buildContext, MaterialPageRoute(builder: (context) => symptoms));
        },
        child: Card(
          color: Color.fromRGBO(230, 229, 240, 1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Container(
            width: 130,
            height: 40,
            child: const Center(
              child: Text(
                "Symptoms",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20.0,
                  color: Color.fromRGBO(90, 53, 190, 1),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget petImageDetailListView(BuildContext context)
  {
    return ListView.builder(
      itemCount: imageArray.length,
      scrollDirection: Axis.horizontal,
      itemBuilder: adapter,
    );
  }

  Widget adapter(BuildContext context, int index)
  {
    return Padding(
      padding: const EdgeInsets.only(left: 10,right: 10,),
      child: Center(
        child: Container(
          height: 260,
          width: MediaQuery.of(context).size.width-10,
          child: Image.network('http://159.203.183.64/Live/API/CorePHPAPIS/dog_care/uploads/symptom_attachments/'+ imageArray[index],
            fit: BoxFit.cover,),
        ),
      ),
    );
  }

  @override
  void alertViewButtonClicked(String buttonName)
  {
    if(buttonName=='Yes'){
      Map<String, dynamic> requestData = Map<String, dynamic>();
      ProgressManager.showAlertDialog(buildContext, "Loading...");
      requestData["expert_reply"] = messageTextEdit.text;
      requestData["request_id"] = widget.petRequest['id'];
      requestData["expert_id"] = App_Session.userId;
      requestData["expert_name"] = App_Session.firstName;

      MyApp.appEngine.api_Request(requestData, "", "ExpertReply");
      setState(() {
        yesNoAlertViewFlag = false;
      });
    }
    else if(buttonName=='No'){
      setState(() {
        yesNoAlertViewFlag = false;
      });
    }
  }

  void getAllPetSymptomsImage(String petSymptomsImages)
  {
    if(petSymptomsImages.length>5){
      final splitImageArray = petSymptomsImages.split(',');

      imageArray.addAll(splitImageArray);
    }
  }


  void expertReplyRequest() async
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    if(messageTextEdit.text.isEmpty){
      ProgressManager.showAlertDialogWithAutoDismiss(
          buildContext, "Please enter reply.", 1, 0);
    }
    else{

      setState(() {
        MyApp.appEngine.maasssWidgetHelper.interfaceAlertView = this;
        yesNoAlertViewFlag = true;
      });
    }
  }

  @override
  Future<void> api_Response_To_UI(
      Map<String, dynamic> responseDictionary, String apiName) async
  {
    if (apiName.compareTo("ExpertReply") == 0)
    {
      if (responseDictionary['status'] == '200')
      {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
        Navigator.of(context).pop(true);
      }
      else
      {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 1, 1);
      }
    }
  }

  @override
  void api_Response_Error(String apiName, response) {
  }
}
