import 'dart:async';
import 'dart:io';

import 'package:dogcare/frameworks/engine/app_engine.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../frameworks/engine/app_profile.dart';
import '../frameworks/engine/app_session.dart';
import '../frameworks/managers/progress_manager.dart';
import '../frameworks/widget_helper.dart';
import '../home/conclusion.dart';
import '../home/conclusion_history.dart';
import '../home/symptoms.dart';
import '../main.dart';

class InterfaceCreateRequest
{
  void refereshPageRequest() {
  }
}

class CreateRequest extends StatefulWidget
{
  //const CreateRequest({Key? key}) : super(key: key);
  InterfaceCreateRequest interfaceCreateRequest = InterfaceCreateRequest();

  Map<String, dynamic> dogDetail = Map<String, dynamic>();

  @override
  State<CreateRequest> createState() => _CreateRequestState();
}

class _CreateRequestState extends State<CreateRequest> implements Interface_API_Response_From_Engine_To_UI,InterfaceAlertView,SelectedSymptomsInterface
{
  TextEditingController messageTextEdit = TextEditingController();
  late BuildContext buildContext;

  String dropDownValue='Pet Owner';
  List dogNameArray = [];
  List<String> dogListForDropDownMenu = [];
  int selectedIndex = 0;
  int deletedImageIndex = -1;
  List<PickedFile> createRequestImageArray = [];
  bool  yesNoAlertViewFlag = false;


  Map<String,dynamic> selectedSymptomsDic = Map<String,dynamic>();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    buildContext = context;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child:Stack(
          children: [
            Column(
            children: [
              appbar(context),
              middleContainet(context),
              submitButton(context),
            ],
          ),
            if(yesNoAlertViewFlag)
              MyApp.appEngine.maasssWidgetHelper.alertViewButtonAndMessage(context, 'Request', 'Do you want to create request?', 'Yes', 'No'),
          ],
        ),

      ),
    );
  }

  Widget appbar(BuildContext context)
  {
    return Container(
      color: Color.fromRGBO(90, 53, 190, 1),
      height: 64,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.of(context).pop(),
          ),
          Spacer(),
          Text(
            'Create Request',
            style: TextStyle(fontSize: 22, color: Colors.white),
          ),
          Spacer(flex: 2,),
        ],
      ),
    );
  }

  Widget middleContainet(BuildContext context){
    return Column(
      children: [
        if(widget.dogDetail.isNotEmpty)
          Container(
            margin: EdgeInsets.only(top: 15,left: 15,right: 15),
            height: 50,
            decoration: BoxDecoration(
                shape: BoxShape.rectangle,
                border: Border.all(color: Colors.black)
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 8.0),
                  child: Text(widget.dogDetail['pat_name'],style: TextStyle(fontSize: 20),),
                ),
              ],
            ),
          ),
        Padding(
          padding: const EdgeInsets.only(left: 15.0,right: 15,top: 15),
          child: Container(
            height: 93,
            child: TextFormField(
              minLines: null,
              maxLines: null,
              expands: true,
              maxLength: 400,
              //keyboardType: TextInputType.multiline,
              keyboardType: TextInputType.text,
              controller: messageTextEdit,
              validator: (val) {
                return val!.isEmpty ? 'Please enter message' : null;
              },
              decoration: InputDecoration(
                labelText: "Message",
                enabledBorder: OutlineInputBorder(
                  //borderRadius: BorderRadius.all(Radius.circular(30)),
                  borderSide: BorderSide(
                    color: Colors.black,
                    width: 2.0,
                  ),
                ),
                labelStyle: TextStyle(
                  color: Colors.black,
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.black),
                ),
              ),
            ),
          ),
        ),

          if(createRequestImageArray.isNotEmpty)
            Padding(
          padding: const EdgeInsets.only(top: 15.0),
          child: Container(
            height: 260,
            width: MediaQuery.of(context).size.width-30,
            color: Colors.white,
            child: petImageDetailListView(context),
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.only(top:10,left: 10),
              child: InkWell(
                onTap: () {
                  Symptoms symptoms = Symptoms();
                  symptoms.petDetail = widget.dogDetail;
                  symptoms.callFromRequest = 1;
                  symptoms.selectedSymptomsInterface = this;
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => symptoms));
                },
                child: Card(
                  color: Color.fromRGBO(230, 229, 240, 1),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Container(
                    width: 160,
                    height: 40,
                    child: Center(
                      child: Text(
                        "Track Symptoms",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20.0,
                          color: Color.fromRGBO(90, 53, 190, 1),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10,right: 10),
              child: InkWell(
                onTap: () {
                  _showCameraDialog(context);
                  },
                child: Card(
                  color: Color.fromRGBO(230, 229, 240, 1),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Container(
                    width: 140,
                    height: 40,
                    child: Center(
                      child: Text(
                        "Add Picture",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20.0,
                          color: Color.fromRGBO(90, 53, 190, 1),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget submitButton(BuildContext context){
    return Padding(
      padding: const EdgeInsets.only(
          top: 15),
      child: InkWell(
        onTap: () {
          createReplyRequest();
        },
        child: Card(
          color: Color.fromRGBO(230, 229, 240, 1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Container(
            width: 180,
            height: 50,
            child: const Padding(
              padding: EdgeInsets.only(top: 15.0),
              child: Text(
                "Submit",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20.0,
                  color: Color.fromRGBO(90, 53, 190, 1),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  _showCameraDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(
              "Choose option",
              style: TextStyle(color: Colors.blue),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: [
                  Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      _openGallery(context);
                    },
                    title: Text("Gallery"),
                    leading: Icon(
                      Icons.account_box,
                      color: Colors.blue,
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      _openCamera(context);
                    },
                    title: Text("Camera"),
                    leading: Icon(
                      Icons.camera,
                      color: Colors.blue,
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      _openCamera(context);
                    },
                    title: Text("Files"),
                    leading: Icon(
                      Icons.file_copy_sharp,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  void _openGallery(BuildContext context) async {
    final pickedFileGallery = await ImagePicker().getImage(
      source: ImageSource.gallery,
    );
    setState(() {
      createRequestImageArray.add(pickedFileGallery!);
    });
  }

  void _openCamera(BuildContext context) async {
    final pickedFileCamera = await ImagePicker().getImage(
      source: ImageSource.camera,
    );
    setState(() {
      createRequestImageArray.add(pickedFileCamera!);
    });
  }

  Widget petImageDetailListView(BuildContext context) {
    return ListView.builder(
      itemCount: createRequestImageArray.length,
      scrollDirection: Axis.horizontal,
      itemBuilder: adapter,
    );
  }

  Widget adapter(BuildContext context, int index) {
    return Stack(
      children: [
        Container(
          height: 260,
          width: 260,
          decoration: BoxDecoration(shape: BoxShape.circle),
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: GestureDetector(
              child: createRequestImageArray.length>0?Image.file(
                  File(createRequestImageArray[index].path), fit: BoxFit.cover):const Text("Take your dog photos.",style: TextStyle(fontSize: 24.0),),
            ),
          ),
        ),
        Positioned(
          top: -8,
          right: -8,
          child: IconButton(
              icon: Icon(
                Icons.cancel,
                color: Colors.red,
              ),
              onPressed: () {
                _showImageDeleteAlertDialog(context);
                deletedImageIndex = index;
              }),
        )
      ],
    );
  }

  Future<void> _showImageDeleteAlertDialog(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(
              "Are you sure you want to delete?",
              style: TextStyle(color: Colors.blue),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: [
                  Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      setState(() {
                        createRequestImageArray.removeAt(deletedImageIndex);
                        Navigator.of(context).pop();
                      });
                    },
                    title: Text("Delete"),
                    leading: Icon(
                      Icons.delete,
                      color: Colors.blue,
                    ),
                  ),
                  Divider(
                    height: 1,
                    color: Colors.blue,
                  ),
                  ListTile(
                    onTap: () {
                      Navigator.of(context).pop();
                      deletedImageIndex = -1;
                    },
                    title: Text("Cancel"),
                    leading: Icon(
                      Icons.cancel,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }


  @override
  void alertViewButtonClicked(String buttonName)
  {
    if(buttonName=='Yes'){
      sendRequest();
      setState(() {
        yesNoAlertViewFlag = false;
      });
    }
    else if(buttonName=='No'){
      setState(() {
        yesNoAlertViewFlag = false;
      });
    }
  }

  @override
  void selectedSymptomsAndVet(Map<String,dynamic> selectedDic)
  {
    selectedSymptomsDic = selectedDic;
  }


  void createReplyRequest()
  {
    MyApp.appEngine.interface_API_Response_From_Engine_To_UI = this;
    if(selectedSymptomsDic.isEmpty){
      ProgressManager.showAlertDialogWithAutoDismiss(buildContext, 'Please select symptoms before created request.', 2, 0);
    }
    else if(messageTextEdit.text.isEmpty){
      ProgressManager.showAlertDialogWithAutoDismiss(buildContext, 'Please enter request message.', 2, 0);
    }
    else if(createRequestImageArray.isEmpty){
      ProgressManager.showAlertDialogWithAutoDismiss(buildContext, "Please take your dog's photos", 2, 0);
    }
    else{

      MyApp.appEngine.maasssWidgetHelper.interfaceAlertView = this;
      setState(() {
        yesNoAlertViewFlag = true;
      });
    }
  }

  void sendRequest() async
  {
    ProgressManager.showAlertDialog(buildContext, 'Loading...');

    Map<String, dynamic> requestData = Map<String, dynamic>();
    requestData["user_id"] = App_Session.userId.toString();
    requestData["pet_id"] = widget.dogDetail['pet_id'].toString();
    requestData["request"] = messageTextEdit.text;
    requestData["symptom_levels"] = selectedSymptomsDic['selected_symptom'].toString();
    requestData["vet_id"] = selectedSymptomsDic['vet_id'].toString();

    File zipFilepath =
        await AppProfile.createZipOfFiles(createRequestImageArray);

    List<int> fileBytes = zipFilepath.readAsBytesSync();
    MyApp.appEngine.apiRequestForFileUpload(
        zipFilepath.path, requestData, 'CreateRequest', fileBytes);
  }

  @override
  Future<void> api_Response_To_UI(
      Map<String, dynamic> responseDictionary, String apiName) async
  {
    if (apiName.compareTo("CreateRequest") == 0)
    {
      if (responseDictionary["status"] == '200') {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, 'Request successfully created.', 2, 1);
        Navigator.pop(buildContext,true);

      } else {
        ProgressManager.showAlertDialogWithAutoDismiss(
            buildContext, responseDictionary["message"], 2, 1);
      }
    }
  }

  @override
  void api_Response_Error(String apiName, response) {

  }


}
